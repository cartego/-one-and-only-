import { useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Instagram, X } from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';
import type { GalleryCategory } from '../types';

const GALLERY_CATEGORIES: Array<'All' | GalleryCategory> = [
  'All',
  'Food',
  'Restaurant',
  'Interior',
  'Outdoor Seating',
  'Special Moments',
];

export function GalleryPage() {
  const { galleryImages, settings } = useRestaurant();
  const [selectedCategory, setSelectedCategory] = useState<'All' | GalleryCategory>('All');
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null);

  const filtered = useMemo(() => {
    if (selectedCategory === 'All') return galleryImages;
    return galleryImages.filter((g) => g.category === selectedCategory);
  }, [galleryImages, selectedCategory]);

  useEffect(() => {
    if (lightboxIdx === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setLightboxIdx(null);
      if (e.key === 'ArrowRight') setLightboxIdx((i) => (i === null ? null : (i + 1) % filtered.length));
      if (e.key === 'ArrowLeft') {
        setLightboxIdx((i) => (i === null ? null : (i - 1 + filtered.length) % filtered.length));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [lightboxIdx, filtered.length]);

  const activePhoto = lightboxIdx !== null ? filtered[lightboxIdx] : null;

  return (
    <div className="min-h-screen bg-[#100D0B] pb-24 pt-28 text-[#F5EFE4]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col justify-between gap-6 border-b border-[#D8AE70]/20 pb-10 md:flex-row md:items-end">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#D8AE70]">
              Visual Stories
            </p>
            <h1 className="mt-3 font-serif text-5xl font-semibold text-[#F5EFE4] sm:text-6xl">
              Gallery &amp; Moments
            </h1>
            <p className="mt-3 max-w-2xl text-base text-[#BDB2A3]">
              A look inside {settings.restaurantName} — our pure vegetarian dishes, warm dining
              rooms, and evening outdoor courtyard in Keshkal.
            </p>
          </div>

          <a
            href={settings.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2.5 border border-[#D8AE70]/40 bg-[#191411] px-5 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#F2D3A0] transition-colors hover:border-[#D8AE70] hover:bg-[#D8AE70] hover:text-[#100D0B] whitespace-nowrap shrink-0"
          >
            <Instagram className="h-4 w-4" />
            <span>Follow {settings.instagramHandle}</span>
          </a>
        </div>

        {/* Category Tabs */}
        <div className="mt-8 flex flex-wrap gap-2">
          {GALLERY_CATEGORIES.map((cat) => {
            const active = selectedCategory === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  setSelectedCategory(cat);
                  setLightboxIdx(null);
                }}
                className={`border px-4 py-2 text-xs font-semibold uppercase tracking-[0.14em] transition-colors whitespace-nowrap ${
                  active
                    ? 'border-[#D8AE70] bg-[#D8AE70] text-[#100D0B]'
                    : 'border-[#D8AE70]/20 bg-[#191411] text-[#BDB2A3] hover:border-[#D8AE70]/50 hover:text-[#F5EFE4]'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* Masonry-style Responsive Grid */}
        {filtered.length === 0 ? (
          <div className="mt-12 border border-[#D8AE70]/20 bg-[#191411] p-12 text-center">
            <p className="font-serif text-2xl text-[#F5EFE4]">No photographs in this category yet</p>
            <p className="mt-2 text-sm text-[#BDB2A3]">
              Restaurant administrators can upload new photography directly from the Admin Dashboard.
            </p>
          </div>
        ) : (
          <div className="mt-10 columns-1 gap-6 space-y-6 sm:columns-2 lg:columns-3">
            {filtered.map((item, idx) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setLightboxIdx(idx)}
                className="group relative block w-full break-inside-avoid overflow-hidden border border-[#D8AE70]/20 bg-[#191411] text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D8AE70]"
              >
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#100D0B]/90 via-[#100D0B]/15 to-transparent opacity-80 transition-opacity group-hover:opacity-100" />
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#D8AE70]">
                    {item.category}
                  </p>
                  <h2 className="mt-1 font-serif text-2xl font-semibold text-[#F5EFE4]">
                    {item.title}
                  </h2>
                  {item.caption && (
                    <p className="mt-1 line-clamp-2 text-xs text-[#BDB2A3]">{item.caption}</p>
                  )}
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Full-Screen Touch-Friendly Lightbox */}
      {activePhoto && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={activePhoto.title}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4"
        >
          <button
            type="button"
            onClick={() => setLightboxIdx(null)}
            aria-label="Close lightbox"
            className="absolute right-4 top-4 z-20 inline-flex h-11 w-11 items-center justify-center border border-[#D8AE70]/40 bg-[#191411] text-[#F5EFE4] hover:border-[#D8AE70]"
          >
            <X className="h-5 w-5" />
          </button>

          {filtered.length > 1 && (
            <>
              <button
                type="button"
                onClick={() =>
                  setLightboxIdx((i) => (i === null ? null : (i - 1 + filtered.length) % filtered.length))
                }
                aria-label="Previous image"
                className="absolute left-3 top-1/2 z-20 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center border border-[#D8AE70]/40 bg-[#191411]/90 text-[#F5EFE4] hover:border-[#D8AE70] sm:left-6"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={() =>
                  setLightboxIdx((i) => (i === null ? null : (i + 1) % filtered.length))
                }
                aria-label="Next image"
                className="absolute right-3 top-1/2 z-20 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center border border-[#D8AE70]/40 bg-[#191411]/90 text-[#F5EFE4] hover:border-[#D8AE70] sm:right-6"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </>
          )}

          <div className="relative max-h-[88vh] max-w-5xl text-center">
            <img
              src={activePhoto.imageUrl}
              alt={activePhoto.title}
              referrerPolicy="no-referrer"
              className="mx-auto max-h-[75vh] w-auto border border-[#D8AE70]/30 object-contain"
            />
            <div className="mt-4">
              <p className="text-xs uppercase tracking-[0.18em] text-[#D8AE70]">
                {activePhoto.category}
              </p>
              <h3 className="mt-1 font-serif text-2xl text-[#F5EFE4]">{activePhoto.title}</h3>
              {activePhoto.caption && (
                <p className="mt-1 text-sm text-[#BDB2A3]">{activePhoto.caption}</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
