import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const _targetPointer = new THREE.Vector2(0, 0);

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function createGlowParticleTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(32, 32, 2, 32, 32, 30);
    grad.addColorStop(0, 'rgba(242, 211, 160, 1)');
    grad.addColorStop(0.35, 'rgba(216, 174, 112, 0.55)');
    grad.addColorStop(1, 'rgba(216, 174, 112, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 64, 64);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function HeroCanvas() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [contextLost, setContextLost] = useState(false);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) return;

    const isSoftwareGl = detectSoftwareWebGL();
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      return;
    }

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x100d0b, 0.045);

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 0.2, 9.5);

    // Studio environment reflection for brushed brass filigree
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTarget = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmremGenerator.dispose();

    // Warm key + cool subtle hemisphere + golden rim
    const hemiLight = new THREE.HemisphereLight(0xf2d3a0, 0x191411, 0.7);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xffdfa8, 1.8);
    keyLight.position.set(4, 5, 6);
    scene.add(keyLight);

    const rimLight = new THREE.PointLight(0xd8ae70, 2.5, 22);
    rimLight.position.set(-4, -2, 4);
    scene.add(rimLight);

    // Composite 5-part sculptural brushed-brass orbital filigree group
    const brassGroup = new THREE.Group();
    brassGroup.position.set(2.2, 0.1, -1.8);

    const brushedGold = new THREE.MeshStandardMaterial({
      color: 0xd8ae70,
      metalness: 0.9,
      roughness: 0.22,
      transparent: true,
      opacity: 0.34,
    });
    const champagneAccent = new THREE.MeshStandardMaterial({
      color: 0xf2d3a0,
      metalness: 0.85,
      roughness: 0.48,
      transparent: true,
      opacity: 0.22,
    });

    const ringOuter = new THREE.Mesh(new THREE.TorusGeometry(2.65, 0.022, 16, 96), brushedGold);
    const ringMid = new THREE.Mesh(new THREE.TorusGeometry(2.15, 0.015, 16, 84), champagneAccent);
    ringMid.rotation.x = Math.PI / 3.5;
    ringMid.rotation.y = Math.PI / 6;

    const ringInner = new THREE.Mesh(new THREE.TorusGeometry(1.55, 0.02, 16, 72), brushedGold);
    ringInner.rotation.y = -Math.PI / 4;

    const finialTop = new THREE.Mesh(new THREE.OctahedronGeometry(0.11, 0), brushedGold);
    finialTop.position.set(0, 2.65, 0);

    const finialBottom = new THREE.Mesh(new THREE.OctahedronGeometry(0.08, 0), champagneAccent);
    finialBottom.position.set(0, -2.65, 0);

    brassGroup.add(ringOuter, ringMid, ringInner, finialTop, finialBottom);
    scene.add(brassGroup);

    // Floating warm golden spice/candlelight particles
    const isNarrow = width < 768;
    const particleCount = isNarrow ? 75 : 140;
    const positions = new Float32Array(particleCount * 3);
    const speeds = new Float32Array(particleCount);
    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 16;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 9;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 7;
      speeds[i] = 0.12 + Math.random() * 0.24;
    }
    const particleGeo = new THREE.BufferGeometry();
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleTex = createGlowParticleTexture();
    const particleMat = new THREE.PointsMaterial({
      size: 0.19,
      map: particleTex,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const handlePointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      _targetPointer.x = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      _targetPointer.y = -((e.clientY - rect.top) / rect.height - 0.5) * 2;
    };

    window.addEventListener('pointermove', handlePointerMove, { passive: true });

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    const onContextLost = (e: Event) => {
      e.preventDefault();
      setContextLost(true);
    };
    const onContextRestored = () => {
      setContextLost(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', onContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', onContextRestored);

    let frameId = 0;
    let disposed = false;
    const clock = new THREE.Clock();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync?.(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      if (!sync) {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.08);
      const elapsed = clock.getElapsedTime();

      camera.position.x = THREE.MathUtils.damp(camera.position.x, _targetPointer.x * 0.45, 3.2, dt);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, 0.2 + _targetPointer.y * 0.28, 3.2, dt);
      camera.lookAt(0, 0, 0);

      brassGroup.rotation.y = elapsed * 0.14 + _targetPointer.x * 0.25;
      brassGroup.rotation.x = Math.sin(elapsed * 0.22) * 0.12 + _targetPointer.y * 0.15;
      ringMid.rotation.z += dt * 0.12;
      ringInner.rotation.x -= dt * 0.09;

      const posAttr = particleGeo.getAttribute('position') as THREE.BufferAttribute;
      for (let i = 0; i < particleCount; i++) {
        let y = posAttr.getY(i) + speeds[i] * dt;
        if (y > 4.6) y = -4.6;
        posAttr.setY(i, y);
      }
      posAttr.needsUpdate = true;
      particles.rotation.y = elapsed * 0.025;

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onContextRestored);

      ringOuter.geometry.dispose();
      ringMid.geometry.dispose();
      ringInner.geometry.dispose();
      finialTop.geometry.dispose();
      finialBottom.geometry.dispose();
      brushedGold.dispose();
      champagneAccent.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      particleTex.dispose();
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  if (contextLost) return null;

  return (
    <div
      ref={mountRef}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 z-[2] overflow-hidden"
    />
  );
}
