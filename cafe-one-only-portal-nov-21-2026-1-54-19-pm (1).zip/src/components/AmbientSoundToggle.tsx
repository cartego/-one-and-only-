import { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

export function AmbientSoundToggle() {
  const [enabled, setEnabled] = useState(false);
  const ctxRef = useRef<AudioContext | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);

  const stopAudio = () => {
    if (masterGainRef.current && ctxRef.current) {
      const now = ctxRef.current.currentTime;
      masterGainRef.current.gain.cancelScheduledValues(now);
      masterGainRef.current.gain.setTargetAtTime(0.0001, now, 0.15);
    }
    window.setTimeout(() => {
      if (ctxRef.current) {
        void ctxRef.current.close();
        ctxRef.current = null;
        masterGainRef.current = null;
      }
    }, 300);
  };

  const startAudio = () => {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    const ctx = new AudioCtx();
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.0001, ctx.currentTime);
    masterGain.gain.exponentialRampToValueAtTime(0.045, ctx.currentTime + 1.2);

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(520, ctx.currentTime);

    filter.connect(masterGain);
    masterGain.connect(ctx.destination);

    // Warm acoustic chord tones (D2, A2, F#3, A3) — peaceful evening lounge drone
    const freqs = [146.83, 220.0, 293.66, 369.99];
    freqs.forEach((f, idx) => {
      const osc = ctx.createOscillator();
      osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(f, ctx.currentTime);

      const oscGain = ctx.createGain();
      oscGain.gain.setValueAtTime(idx === 0 ? 0.4 : 0.18, ctx.currentTime);

      osc.connect(oscGain);
      oscGain.connect(filter);
      osc.start();
    });

    ctxRef.current = ctx;
    masterGainRef.current = masterGain;
  };

  const handleToggle = () => {
    if (enabled) {
      stopAudio();
      setEnabled(false);
    } else {
      startAudio();
      setEnabled(true);
    }
  };

  useEffect(() => {
    return () => {
      if (ctxRef.current) {
        void ctxRef.current.close();
      }
    };
  }, []);

  return (
    <button
      type="button"
      onClick={handleToggle}
      aria-label={enabled ? 'Mute ambient cafe atmosphere sound' : 'Play subtle ambient cafe atmosphere sound'}
      className="inline-flex items-center gap-2 border border-[#D8AE70]/25 bg-[#191411] px-3.5 py-2 text-xs font-medium tracking-wider text-[#F5EFE4] transition-colors duration-200 hover:border-[#D8AE70] hover:text-[#F2D3A0] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D8AE70]"
    >
      {enabled ? <Volume2 className="h-3.5 w-3.5 text-[#D8AE70]" /> : <VolumeX className="h-3.5 w-3.5 text-[#BDB2A3]" />}
      <span className="whitespace-nowrap">{enabled ? 'Sound On' : 'Atmosphere Sound'}</span>
    </button>
  );
}
