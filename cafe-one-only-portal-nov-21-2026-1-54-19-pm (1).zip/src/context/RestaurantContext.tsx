import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { CartItem, Category, GalleryImage, MenuItem, RestaurantSettings } from '../types';

interface RestaurantContextValue {
  currentPath: string;
  navigate: (path: string) => void;
  categories: Category[];
  menuItems: MenuItem[];
  galleryImages: GalleryImage[];
  settings: RestaurantSettings;
  hasAdmin: boolean;
  loading: boolean;
  error: string | null;
  refreshBootstrap: () => Promise<void>;
  cart: CartItem[];
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  addToCart: (item: MenuItem, quantity?: number, customization?: string) => void;
  updateCartQuantity: (menuItemId: string, customization: string | undefined, delta: number) => void;
  removeFromCart: (menuItemId: string, customization?: string) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  hasUnpricedInCart: boolean;
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const DEFAULT_SETTINGS: RestaurantSettings = {
  restaurantName: 'Cafe One & Only',
  restaurantType: 'Pure Vegetarian Café and Restaurant',
  phone: '+91 87706 15846',
  whatsappNumber: '918770615846',
  address: '05 Depot, Borgaon Road, Garka, Keshkal, Chhattisgarh 494331, India',
  googlePlusCode: '3H8M+F8X',
  instagramUrl: 'https://www.instagram.com/reel/Df9gS50PkWb/?evlk=MWRjOXVtcTd1YW11aw==',
  instagramHandle: '@one_and_only___iu',
  openingHours: 'To be confirmed',
  averageSpend: '₹200–₹400 per person',
  rating: '4.3',
  reviewCount: 216,
  taxRatePercent: 0,
  deliveryFee: 0,
  freeDeliveryThreshold: 0,
  deliveryEnabled: true,
  dineInEnabled: true,
  takeawayEnabled: true,
  upiId: '',
  paymentProviderName: 'To be configured',
  paymentGatewayEnabled: false,
  reservationTimeSlots: [
    '12:00 PM',
    '01:30 PM',
    '03:00 PM',
    '05:30 PM',
    '07:00 PM',
    '08:30 PM',
    '09:30 PM',
  ],
  maxGuestsPerBooking: 20,
  backendMode: 'local-persistent',
};

const PAGE_SEO: Record<string, { title: string; description: string }> = {
  '/': {
    title: 'Cafe One & Only — Pure Vegetarian Café & Restaurant in Keshkal',
    description:
      'Pure vegetarian family café and restaurant at 05 Depot, Borgaon Road, Garka, Keshkal, Chhattisgarh. Dine-in, takeaway, delivery, and table reservations.',
  },
  '/menu': {
    title: 'Menu — Cafe One & Only, Keshkal (100% Pure Vegetarian)',
    description:
      'Explore pure vegetarian starters, snacks, Pav Bhaji, Chole Kulche, Jini Dosa, Thalis, noodles, tea, coffee, and chillers at Cafe One & Only Keshkal.',
  },
  '/about': {
    title: 'About Us — Cafe One & Only, Keshkal',
    description:
      'Discover Cafe One & Only: a warm, family-friendly pure vegetarian restaurant with outdoor seating in Keshkal, welcoming locals and Bastar travellers.',
  },
  '/gallery': {
    title: 'Gallery — Cafe One & Only, Keshkal',
    description:
      'View food photography, indoor dining ambiance, and outdoor courtyard seating at Cafe One & Only in Keshkal, Chhattisgarh.',
  },
  '/reservations': {
    title: 'Reserve a Table — Cafe One & Only, Keshkal',
    description:
      'Request a table reservation for family dining, group gatherings, or celebrations at Cafe One & Only in Keshkal.',
  },
  '/contact': {
    title: 'Contact & Directions — Cafe One & Only, Keshkal',
    description:
      'Visit Cafe One & Only at 05 Depot, Borgaon Road, Garka, Keshkal, Chhattisgarh 494331 (Plus Code: 3H8M+F8X) or call +91 87706 15846.',
  },
  '/checkout': {
    title: 'Order Checkout — Cafe One & Only, Keshkal',
    description:
      'Complete your dine-in, takeaway, or delivery order from Cafe One & Only via online request or WhatsApp.',
  },
  '/admin': {
    title: 'Restaurant Administration — Cafe One & Only',
    description: 'Protected restaurant management console for Cafe One & Only.',
  },
};

const CART_STORAGE_KEY = 'cafe_one_only_cart_v1';

const RestaurantContext = createContext<RestaurantContextValue | null>(null);

export function RestaurantProvider({ children }: { children: React.ReactNode }) {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    const p = window.location.pathname || '/';
    return p.length > 1 && p.endsWith('/') ? p.slice(0, -1) : p;
  });

  const [categories, setCategories] = useState<Category[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [galleryImages, setGalleryImages] = useState<GalleryImage[]>([]);
  const [settings, setSettings] = useState<RestaurantSettings>(DEFAULT_SETTINGS);
  const [hasAdmin, setHasAdmin] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      if (saved) return JSON.parse(saved) as CartItem[];
    } catch {
      // Ignore storage errors
    }
    return [];
  });
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = window.setTimeout(() => setToastMessage(null), 2600);
    return () => window.clearTimeout(timer);
  }, [toastMessage]);

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch {
      // Ignore
    }
  }, [cart]);

  const refreshBootstrap = useCallback(async () => {
    try {
      setError(null);
      const res = await fetch('/api/bootstrap');
      if (!res.ok) throw new Error('Unable to load restaurant data.');
      const data = (await res.json()) as {
        categories: Category[];
        menuItems: MenuItem[];
        galleryImages: GalleryImage[];
        settings: RestaurantSettings;
        hasAdmin: boolean;
      };
      setCategories(data.categories || []);
      setMenuItems(data.menuItems || []);
      setGalleryImages(data.galleryImages || []);
      setSettings(data.settings || DEFAULT_SETTINGS);
      setHasAdmin(Boolean(data.hasAdmin));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Network error loading restaurant data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshBootstrap();
  }, [refreshBootstrap]);

  useEffect(() => {
    const onPopState = () => {
      const p = window.location.pathname || '/';
      setCurrentPath(p.length > 1 && p.endsWith('/') ? p.slice(0, -1) : p);
      window.scrollTo({ top: 0, behavior: 'auto' });
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    const seo = PAGE_SEO[currentPath] || PAGE_SEO['/'];
    document.title = seo.title;
    const desc = document.querySelector('meta[name="description"]');
    if (desc) desc.setAttribute('content', seo.description);
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.setAttribute('content', seo.title);
  }, [currentPath]);

  const navigate = useCallback(
    (path: string) => {
      const normalized = path.length > 1 && path.endsWith('/') ? path.slice(0, -1) : path;
      if (normalized !== currentPath) {
        window.history.pushState({}, '', normalized);
        setCurrentPath(normalized);
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    [currentPath],
  );

  const addToCart = useCallback(
    (item: MenuItem, quantity = 1, customization?: string) => {
      if (!item.isAvailable) {
        showToast(`${item.name} is currently unavailable.`);
        return;
      }
      setCart((prev) => {
        const existingIdx = prev.findIndex(
          (c) => c.menuItem.id === item.id && c.customization === customization,
        );
        if (existingIdx > -1) {
          const updated = [...prev];
          updated[existingIdx] = {
            ...updated[existingIdx],
            quantity: updated[existingIdx].quantity + quantity,
          };
          return updated;
        }
        return [...prev, { menuItem: item, quantity, customization }];
      });
      showToast(`Added ${item.name} to your order`);
    },
    [showToast],
  );

  const updateCartQuantity = useCallback(
    (menuItemId: string, customization: string | undefined, delta: number) => {
      setCart((prev) =>
        prev
          .map((c) => {
            if (c.menuItem.id === menuItemId && c.customization === customization) {
              return { ...c, quantity: c.quantity + delta };
            }
            return c;
          })
          .filter((c) => c.quantity > 0),
      );
    },
    [],
  );

  const removeFromCart = useCallback((menuItemId: string, customization?: string) => {
    setCart((prev) =>
      prev.filter((c) => !(c.menuItem.id === menuItemId && c.customization === customization)),
    );
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const cartCount = useMemo(() => cart.reduce((sum, item) => sum + item.quantity, 0), [cart]);

  const cartSubtotal = useMemo(
    () =>
      cart.reduce(
        (sum, item) => sum + (item.menuItem.price !== null ? item.menuItem.price * item.quantity : 0),
        0,
      ),
    [cart],
  );

  const hasUnpricedInCart = useMemo(
    () => cart.some((item) => item.menuItem.price === null),
    [cart],
  );

  const value: RestaurantContextValue = {
    currentPath,
    navigate,
    categories,
    menuItems,
    galleryImages,
    settings,
    hasAdmin,
    loading,
    error,
    refreshBootstrap,
    cart,
    isCartOpen,
    setIsCartOpen,
    addToCart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartCount,
    cartSubtotal,
    hasUnpricedInCart,
    toastMessage,
    showToast,
  };

  return <RestaurantContext.Provider value={value}>{children}</RestaurantContext.Provider>;
}

export function useRestaurant(): RestaurantContextValue {
  const ctx = useContext(RestaurantContext);
  if (!ctx) throw new Error('useRestaurant must be used within RestaurantProvider');
  return ctx;
}
