import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type {
  Category,
  ContactMessage,
  GalleryImage,
  MenuItem,
  OrderRecord,
  ReservationRecord,
  RestaurantSettings,
} from '../src/types.ts';

export interface AdminUserRecord {
  id: string;
  email: string;
  name: string;
  role: 'admin';
  passwordHash: string;
  salt: string;
  createdAt: string;
  recoveryTokenHash?: string;
  recoveryExpiresAt?: number;
}

export interface PaymentTransactionRecord {
  id: string;
  orderId: string;
  orderNumber: string;
  provider: string;
  method: string;
  amount: number;
  status: string;
  reference: string;
  createdAt: string;
}

export interface DatabaseState {
  users: AdminUserRecord[];
  categories: Category[];
  menuItems: MenuItem[];
  orders: OrderRecord[];
  reservations: ReservationRecord[];
  galleryImages: GalleryImage[];
  contactMessages: ContactMessage[];
  paymentTransactions: PaymentTransactionRecord[];
  settings: RestaurantSettings;
}

const DATA_DIR = path.resolve(process.cwd(), '.data');
const DB_FILE = path.join(DATA_DIR, 'cafe-one-and-only.json');
export const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');

export function hashPassword(password: string, existingSalt?: string): { hash: string; salt: string } {
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, storedHash: string, salt: string): boolean {
  const derived = crypto.scryptSync(password, salt, 64);
  const storedBuf = Buffer.from(storedHash, 'hex');
  if (derived.length !== storedBuf.length) return false;
  return crypto.timingSafeEqual(derived, storedBuf);
}

function createInitialState(): DatabaseState {
  const now = new Date().toISOString();
  const hasSupabase = Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY);

  const categories: Category[] = [
    { id: 'cat-starters', name: 'Starters', sortOrder: 1 },
    { id: 'cat-snacks', name: 'Snacks', sortOrder: 2 },
    { id: 'cat-south-indian', name: 'South Indian', sortOrder: 3 },
    { id: 'cat-main-course', name: 'Main Course', sortOrder: 4 },
    { id: 'cat-chinese', name: 'Chinese', sortOrder: 5 },
    { id: 'cat-beverages', name: 'Beverages', sortOrder: 6 },
    { id: 'cat-tea-coffee', name: 'Tea and Coffee', sortOrder: 7 },
    { id: 'cat-special', name: 'Special Dishes', sortOrder: 8 },
  ];

  const menuItems: MenuItem[] = [
    {
      id: 'dish-crispy-corn',
      name: 'Crispy Corn',
      description: 'Golden crunchy sweet corn tossed with crisp bell peppers, aromatic spices, and fresh herbs.',
      price: null,
      categoryId: 'cat-starters',
      categoryName: 'Starters',
      imageUrl: '/src/assets/images/dish_crispy_corn_1795248975205.jpg',
      isVegetarian: true,
      isVeganFriendly: true,
      isAvailable: true,
      isFeatured: true,
      prepTimeMinutes: null,
      customizations: ['Regular Spice', 'Mild Spice'],
    },
    {
      id: 'dish-pav-bhaji',
      name: 'Pav Bhaji',
      description: 'Slow-simmered spiced vegetable bhaji served warm with toasted buttered pav, onions, and fresh lime.',
      price: null,
      categoryId: 'cat-snacks',
      categoryName: 'Snacks',
      imageUrl: '/src/assets/images/dish_pav_bhaji_1795248972765.jpg',
      isVegetarian: true,
      isVeganFriendly: false,
      isAvailable: true,
      isFeatured: true,
      prepTimeMinutes: null,
      customizations: ['Classic', 'Extra Butter', 'Less Spicy'],
    },
    {
      id: 'dish-chole-kulche',
      name: 'Chole Kulche',
      description: 'Hearty spiced chickpea curry paired with soft, golden-charred kulchas and tangy accompaniments.',
      price: null,
      categoryId: 'cat-snacks',
      categoryName: 'Snacks',
      imageUrl: '/src/assets/images/dish_chole_kulche_1795248972416.jpg',
      isVegetarian: true,
      isVeganFriendly: false,
      isAvailable: true,
      isFeatured: true,
      prepTimeMinutes: null,
    },
    {
      id: 'dish-jini-dosa',
      name: 'Jini Dosa',
      description: 'Crisp golden dosa rolled with savoury mixed vegetables, aromatic sauces, and melted cheese, served with chutneys and sambar.',
      price: null,
      categoryId: 'cat-south-indian',
      categoryName: 'South Indian',
      imageUrl: '/src/assets/images/dish_jini_dosa_1795248972194.jpg',
      isVegetarian: true,
      isVeganFriendly: false,
      isAvailable: true,
      isFeatured: true,
      prepTimeMinutes: null,
    },
    {
      id: 'dish-veg-noodles',
      name: 'Vegetarian Instant Noodles',
      description: 'Steaming hot vegetarian noodles tossed with crisp garden vegetables and savoury house seasoning.',
      price: null,
      categoryId: 'cat-chinese',
      categoryName: 'Chinese',
      imageUrl: '/src/assets/images/dish_veg_noodles_1795248973578.jpg',
      isVegetarian: true,
      isVeganFriendly: true,
      isAvailable: true,
      isFeatured: true,
      prepTimeMinutes: null,
      customizations: ['Regular', 'Mild', 'Spicy'],
    },
    {
      id: 'dish-cheese-balls',
      name: 'Cheese Balls',
      description: 'Crisp herb-seasoned golden cheese bites with a warm molten centre, served alongside house dip.',
      price: null,
      categoryId: 'cat-starters',
      categoryName: 'Starters',
      imageUrl: '/src/assets/images/dish_cheese_balls_veg_1795249060519.jpg',
      isVegetarian: true,
      isVeganFriendly: false,
      isAvailable: true,
      isFeatured: true,
      prepTimeMinutes: null,
    },
    {
      id: 'dish-cheesy-potato-basket',
      name: 'Cheesy Potato Basket',
      description: 'Crispy woven potato nest filled with melted cheese, sweet corn, and fresh herbs.',
      price: null,
      categoryId: 'cat-special',
      categoryName: 'Special Dishes',
      imageUrl: '/src/assets/images/dish_cheese_balls_veg_1795249060519.jpg',
      isVegetarian: true,
      isVeganFriendly: false,
      isAvailable: true,
      isFeatured: false,
      prepTimeMinutes: null,
    },
    {
      id: 'dish-thalis',
      name: 'Thalis',
      description: 'Wholesome pure vegetarian Indian thali featuring seasonal curries, dal, rice, freshly made rotis, raita, and sweet.',
      price: null,
      categoryId: 'cat-main-course',
      categoryName: 'Main Course',
      imageUrl: '/src/assets/images/dish_veg_thali_1795248973066.jpg',
      isVegetarian: true,
      isVeganFriendly: false,
      isAvailable: true,
      isFeatured: true,
      prepTimeMinutes: null,
    },
    {
      id: 'dish-tea-coffee',
      name: 'Tea and Coffee',
      description: 'Freshly brewed masala chai and aromatic hot or cold coffee prepared to order.',
      price: null,
      categoryId: 'cat-tea-coffee',
      categoryName: 'Tea and Coffee',
      imageUrl: '/src/assets/images/beverage_chai_chillers_1795248973170.jpg',
      isVegetarian: true,
      isVeganFriendly: false,
      isAvailable: true,
      isFeatured: false,
      prepTimeMinutes: null,
      customizations: ['Masala Tea', 'Hot Coffee', 'Cold Coffee'],
    },
    {
      id: 'dish-flavoured-chillers',
      name: 'Flavoured Chillers',
      description: 'Refreshing chilled café coolers crafted to pair with savoury snacks and warm afternoons.',
      price: null,
      categoryId: 'cat-beverages',
      categoryName: 'Beverages',
      imageUrl: '/src/assets/images/beverage_chai_chillers_1795248973170.jpg',
      isVegetarian: true,
      isVeganFriendly: true,
      isAvailable: true,
      isFeatured: false,
      prepTimeMinutes: null,
    },
  ];

  const galleryImages: GalleryImage[] = [
    {
      id: 'gal-1',
      title: 'Signature Vegetarian Spread',
      caption: 'Pure vegetarian flavours served warm for family and group dining.',
      category: 'Food',
      imageUrl: '/src/assets/images/hero_vegetarian_feast_1795248972135.jpg',
      createdAt: now,
    },
    {
      id: 'gal-2',
      title: 'Warm Dining Room',
      caption: 'Welcoming indoor seating designed for unhurried family meals.',
      category: 'Interior',
      imageUrl: '/src/assets/images/cafe_interior_ambiance_1795248972739.jpg',
      createdAt: now,
    },
    {
      id: 'gal-3',
      title: 'Evening Courtyard Seating',
      caption: 'Open-air courtyard atmosphere at Cafe One & Only in Keshkal.',
      category: 'Outdoor Seating',
      imageUrl: '/src/assets/images/outdoor_garden_dining_1795248993021.jpg',
      createdAt: now,
    },
    {
      id: 'gal-4',
      title: 'Royal Vegetarian Thali',
      caption: 'Traditional pure vegetarian thali prepared fresh to order.',
      category: 'Food',
      imageUrl: '/src/assets/images/dish_veg_thali_1795248973066.jpg',
      createdAt: now,
    },
    {
      id: 'gal-5',
      title: 'Pav Bhaji & Toasted Pav',
      caption: 'Popular café snack served piping hot with melting butter.',
      category: 'Food',
      imageUrl: '/src/assets/images/dish_pav_bhaji_1795248972765.jpg',
      createdAt: now,
    },
    {
      id: 'gal-6',
      title: 'Jini Dosa & Chutneys',
      caption: 'Crisp rolled South Indian fusion specialty.',
      category: 'Food',
      imageUrl: '/src/assets/images/dish_jini_dosa_1795248972194.jpg',
      createdAt: now,
    },
    {
      id: 'gal-7',
      title: 'Tea, Coffee & Chillers',
      caption: 'Brewed chai, coffee, and refreshing coolers for travellers and locals.',
      category: 'Restaurant',
      imageUrl: '/src/assets/images/beverage_chai_chillers_1795248973170.jpg',
      createdAt: now,
    },
    {
      id: 'gal-8',
      title: 'Group & Family Celebrations',
      caption: 'Warm hospitality for parties, birthdays, and Bastar travellers.',
      category: 'Special Moments',
      imageUrl: '/src/assets/images/dish_cheese_balls_veg_1795249060519.jpg',
      createdAt: now,
    },
  ];

  const users: AdminUserRecord[] = [];
  if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
    const { hash, salt } = hashPassword(process.env.ADMIN_PASSWORD);
    users.push({
      id: 'admin-env-1',
      email: process.env.ADMIN_EMAIL.trim().toLowerCase(),
      name: 'Restaurant Administrator',
      role: 'admin',
      passwordHash: hash,
      salt,
      createdAt: now,
    });
  }

  return {
    users,
    categories,
    menuItems,
    orders: [],
    reservations: [],
    galleryImages,
    contactMessages: [],
    paymentTransactions: [],
    settings: {
      restaurantName: 'Cafe One & Only',
      restaurantType: 'Pure Vegetarian Café and Restaurant',
      phone: '+91 87706 15846',
      whatsappNumber: '918770615846',
      address: '05 Depot, Borgaon Road, Garka, Keshkal, Chhattisgarh 494331, India',
      googlePlusCode: '3H8M+F8X',
      instagramUrl: 'https://www.instagram.com/reel/Df9gS50PkWb/?evlk=MWRjOXVtcTd1YW11aw==',
      instagramHandle: '@one_and_only___iu',
      openingHours: 'To be confirmed',
      averageSpend: '₹200–₹400 per person',
      rating: '4.3',
      reviewCount: 216,
      taxRatePercent: 0,
      deliveryFee: 0,
      freeDeliveryThreshold: 0,
      deliveryEnabled: true,
      dineInEnabled: true,
      takeawayEnabled: true,
      upiId: '',
      paymentProviderName: 'To be configured',
      paymentGatewayEnabled: false,
      reservationTimeSlots: [
        '12:00 PM',
        '01:30 PM',
        '03:00 PM',
        '05:30 PM',
        '07:00 PM',
        '08:30 PM',
        '09:30 PM',
      ],
      maxGuestsPerBooking: 20,
      backendMode: hasSupabase ? 'supabase-configured' : 'local-persistent',
    },
  };
}

let cachedState: DatabaseState | null = null;

export function ensureStorageDirectories(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
}

export function loadDb(): DatabaseState {
  if (cachedState) return cachedState;
  ensureStorageDirectories();
  if (fs.existsSync(DB_FILE)) {
    try {
      const raw = fs.readFileSync(DB_FILE, 'utf8');
      const parsed = JSON.parse(raw) as DatabaseState;
      cachedState = parsed;
      return cachedState;
    } catch {
      // Corrupt or unreadable file fallback
    }
  }
  const initial = createInitialState();
  saveDb(initial);
  return initial;
}

export function saveDb(nextState: DatabaseState): void {
  ensureStorageDirectories();
  cachedState = nextState;
  const tmpFile = `${DB_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(nextState, null, 2), 'utf8');
  fs.renameSync(tmpFile, DB_FILE);
}
