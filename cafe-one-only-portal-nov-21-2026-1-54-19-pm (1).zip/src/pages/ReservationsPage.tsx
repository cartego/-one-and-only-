import { useState } from 'react';
import { Calendar, Clock, MessageCircle, ShieldAlert, Users } from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';
import type { ReservationRecord } from '../types';

export function ReservationsPage() {
  const { settings } = useRestaurant();
  const todayStr = new Date().toISOString().slice(0, 10);

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [reservationDate, setReservationDate] = useState(todayStr);
  const [reservationTime, setReservationTime] = useState(
    settings.reservationTimeSlots[0] || '07:00 PM',
  );
  const [guestCount, setGuestCount] = useState(4);
  const [specialRequests, setSpecialRequests] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [createdReservation, setCreatedReservation] = useState<ReservationRecord | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (customerName.trim().length < 2) {
      setError('Please enter your name.');
      return;
    }
    if (!/^[+\d\s()-]{8,18}$/.test(customerPhone.trim())) {
      setError('Please enter a valid mobile number.');
      return;
    }
    if (reservationDate < todayStr) {
      setError('Please select today or a future date.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: customerName.trim(),
          customerPhone: customerPhone.trim(),
          customerEmail: customerEmail.trim(),
          reservationDate,
          reservationTime,
          guestCount,
          specialRequests: specialRequests.trim(),
        }),
      });
      const data = (await res.json()) as { reservation?: ReservationRecord; error?: string };
      if (!res.ok || !data.reservation) {
        throw new Error(data.error || 'Could not submit reservation request.');
      }
      setCreatedReservation(data.reservation);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to submit reservation.');
    } finally {
      setSubmitting(false);
    }
  };

  const buildWhatsAppInquiry = (r: ReservationRecord) => {
    const msg = [
      `*Table Reservation Request — ${settings.restaurantName}*`,
      `Reference: ${r.referenceCode}`,
      `Guest: ${r.customerName} (${r.customerPhone})`,
      `Date: ${r.reservationDate}`,
      `Time Slot: ${r.reservationTime}`,
      `Guests: ${r.guestCount}`,
      r.specialRequests ? `Notes: ${r.specialRequests}` : null,
      '',
      'Please confirm table availability.',
    ]
      .filter((l): l is string => l !== null)
      .join('\n');
    return `https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent(msg)}`;
  };

  return (
    <div className="min-h-screen bg-[#100D0B] pb-24 pt-28 text-[#F5EFE4]">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl border-b border-[#D8AE70]/20 pb-10">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#D8AE70]">
            Family Dining &amp; Group Gatherings
          </p>
          <h1 className="mt-3 font-serif text-5xl font-semibold text-[#F5EFE4] sm:text-6xl">
            Request a Table Reservation
          </h1>
          <p className="mt-4 text-base leading-relaxed text-[#BDB2A3]">
            Reserve your spot for family dinners, outdoor courtyard seating, or group and party
            arrangements at {settings.restaurantName}. All reservation requests remain pending until
            confirmed by our hospitality desk.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-10 lg:grid-cols-12">
          {/* Left: Form or Pending Receipt */}
          <div className="lg:col-span-7">
            {createdReservation ? (
              <div className="border border-[#D8AE70]/35 bg-[#191411] p-8 sm:p-10">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#D8AE70]">
                  Request Logged · Status: {createdReservation.status} Approval
                </p>
                <h2 className="mt-2 font-serif text-4xl font-semibold text-[#F5EFE4]">
                  Thank You, {createdReservation.customerName}
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-[#BDB2A3]">
                  Your table request has been received. Our team will review seating availability
                  and confirm your reservation via phone or WhatsApp.
                </p>

                <div className="mt-6 grid grid-cols-2 gap-4 border-y border-[#D8AE70]/20 py-5 text-sm">
                  <div>
                    <p className="text-xs uppercase tracking-[0.14em] text-[#BDB2A3]">
                      Reference Number
                    </p>
                    <p className="mt-1 font-mono text-base font-semibold text-[#F2D3A0]">
                      {createdReservation.referenceCode}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-[0.14em] text-[#BDB2A3]">
                      Current Status
                    </p>
                    <p className="mt-1 font-semibold text-[#D8AE70]">
                      Pending Restaurant Approval
                    </p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-[0.14em] text-[#BDB2A3]">Date &amp; Time</p>
                    <p className="tabular-nums mt-1 text-[#F5EFE4]">
                      {createdReservation.reservationDate} · {createdReservation.reservationTime}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-[0.14em] text-[#BDB2A3]">Party Size</p>
                    <p className="tabular-nums mt-1 text-[#F5EFE4]">
                      {createdReservation.guestCount} Guests
                    </p>
                  </div>
                </div>

                <div className="mt-8 flex flex-wrap gap-4">
                  <a
                    href={buildWhatsAppInquiry(createdReservation)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2.5 bg-[#D8AE70] px-6 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-[#100D0B] hover:bg-[#F2D3A0]"
                  >
                    <MessageCircle className="h-4 w-4" />
                    <span>Follow Up on WhatsApp</span>
                  </a>
                  <button
                    type="button"
                    onClick={() => setCreatedReservation(null)}
                    className="border border-[#D8AE70]/40 px-6 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-[#F5EFE4] hover:border-[#D8AE70]"
                  >
                    New Request
                  </button>
                </div>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="space-y-6 border border-[#D8AE70]/20 bg-[#191411] p-6 sm:p-9"
              >
                {error && (
                  <div className="flex items-start gap-3 border border-red-500/40 bg-red-950/30 p-4 text-sm text-red-200">
                    <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="res-name"
                      className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                    >
                      Full Name *
                    </label>
                    <input
                      id="res-name"
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Guest name"
                      className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="res-phone"
                      className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                    >
                      Phone Number *
                    </label>
                    <input
                      id="res-phone"
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="+91 98XXXXXXXX"
                      className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="res-email"
                    className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                  >
                    Email Address (Optional)
                  </label>
                  <input
                    id="res-email"
                    type="email"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
                  <div>
                    <label
                      htmlFor="res-date"
                      className="mb-1.5 flex items-center gap-1.5 text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                    >
                      <Calendar className="h-3.5 w-3.5 text-[#D8AE70]" />
                      <span>Date *</span>
                    </label>
                    <input
                      id="res-date"
                      type="date"
                      min={todayStr}
                      required
                      value={reservationDate}
                      onChange={(e) => setReservationDate(e.target.value)}
                      className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="res-time"
                      className="mb-1.5 flex items-center gap-1.5 text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                    >
                      <Clock className="h-3.5 w-3.5 text-[#D8AE70]" />
                      <span>Time Slot *</span>
                    </label>
                    <select
                      id="res-time"
                      value={reservationTime}
                      onChange={(e) => setReservationTime(e.target.value)}
                      className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                    >
                      {settings.reservationTimeSlots.map((slot) => (
                        <option key={slot} value={slot}>
                          {slot}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="res-guests"
                      className="mb-1.5 flex items-center gap-1.5 text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                    >
                      <Users className="h-3.5 w-3.5 text-[#D8AE70]" />
                      <span>Guests *</span>
                    </label>
                    <input
                      id="res-guests"
                      type="number"
                      min={1}
                      max={settings.maxGuestsPerBooking}
                      required
                      value={guestCount}
                      onChange={(e) => setGuestCount(Number(e.target.value))}
                      className="tabular-nums w-full border border-[#D8AE70]/25 bg-[#100D0B] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="res-notes"
                    className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                  >
                    Special Requests / Seating Preference
                  </label>
                  <textarea
                    id="res-notes"
                    rows={3}
                    value={specialRequests}
                    onChange={(e) => setSpecialRequests(e.target.value)}
                    placeholder="Outdoor courtyard table, family celebration, birthday arrangement..."
                    className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-[#D8AE70] py-4 text-xs font-semibold uppercase tracking-[0.16em] text-[#100D0B] transition-colors hover:bg-[#F2D3A0] disabled:opacity-60"
                >
                  {submitting ? 'Submitting Request...' : 'Submit Reservation Request'}
                </button>
              </form>
            )}
          </div>

          {/* Right: Dining & Party Info */}
          <aside className="space-y-6 lg:col-span-5">
            <div className="overflow-hidden border border-[#D8AE70]/25 bg-[#191411]">
              <img
                src="/src/assets/images/outdoor_garden_dining_1795248993021.jpg"
                alt="Outdoor family dining tables at Cafe One & Only"
                referrerPolicy="no-referrer"
                className="aspect-[4/3] w-full object-cover"
              />
              <div className="p-7">
                <h2 className="font-serif text-2xl font-semibold text-[#F5EFE4]">
                  Group Dining &amp; Celebrations
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-[#BDB2A3]">
                  Hosting a birthday, family get-together, or traveller group meal? Mention your
                  occasion in Special Requests or call us directly at{' '}
                  <a
                    href={`tel:${settings.phone.replace(/\s+/g, '')}`}
                    className="text-[#F2D3A0] underline underline-offset-4"
                  >
                    {settings.phone}
                  </a>
                  .
                </p>
                <div className="mt-5 border-t border-[#D8AE70]/15 pt-4 text-xs text-[#BDB2A3]">
                  <p>Opening Hours: {settings.openingHours}</p>
                  <p className="mt-1">Location: {settings.address}</p>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
