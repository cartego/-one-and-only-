import { useEffect, useState } from 'react';
import { Menu, ShoppingBag, X } from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';

const NAV_ITEMS = [
  { label: 'Home', path: '/' },
  { label: 'Menu', path: '/menu' },
  { label: 'About', path: '/about' },
  { label: 'Gallery', path: '/gallery' },
  { label: 'Reservations', path: '/reservations' },
  { label: 'Contact', path: '/contact' },
];

export function Header() {
  const { currentPath, navigate, cartCount, setIsCartOpen, settings } = useRestaurant();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 36);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNav = (path: string) => {
    setMobileOpen(false);
    navigate(path);
  };

  if (currentPath === '/admin') {
    return null;
  }

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-40 transition-colors duration-300 ${
          scrolled || currentPath !== '/'
            ? 'border-b border-[#D8AE70]/20 bg-[#100D0B]/95 backdrop-blur-md'
            : 'bg-gradient-to-b from-[#100D0B]/85 to-transparent'
        }`}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:h-20 sm:px-6 lg:px-8">
          {/* Zone 1: Brand Wordmark */}
          <button
            type="button"
            onClick={() => handleNav('/')}
            className="font-serif text-xl font-semibold tracking-[0.08em] text-[#F5EFE4] transition-colors hover:text-[#F2D3A0] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D8AE70] sm:text-2xl whitespace-nowrap shrink-0"
          >
            {settings.restaurantName}
          </button>

          {/* Zone 2: Clean Typography Nav Links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden items-center gap-6 lg:flex xl:gap-8"
          >
            {NAV_ITEMS.map((item) => {
              const active = currentPath === item.path;
              return (
                <button
                  key={item.path}
                  type="button"
                  onClick={() => handleNav(item.path)}
                  className={`group relative py-1 text-sm font-medium tracking-wide transition-colors duration-200 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D8AE70] ${
                    active ? 'text-[#D8AE70]' : 'text-[#F5EFE4]/85 hover:text-[#F2D3A0]'
                  }`}
                >
                  {item.label}
                  <span
                    className={`absolute inset-x-0 -bottom-0.5 h-[1px] origin-left bg-[#D8AE70] transition-transform duration-300 ${
                      active ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
                    }`}
                  />
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Cart + Primary Action + Mobile Menu Trigger */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setIsCartOpen(true)}
              aria-label={`Open shopping cart with ${cartCount} items`}
              className="relative inline-flex h-10 w-10 items-center justify-center border border-[#D8AE70]/25 bg-[#191411]/80 text-[#F5EFE4] transition-colors duration-200 hover:border-[#D8AE70] hover:text-[#F2D3A0] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D8AE70]"
            >
              <ShoppingBag className="h-4 w-4" />
              {cartCount > 0 && (
                <span className="tabular-nums absolute -right-1.5 -top-1.5 flex h-5 min-w-[20px] items-center justify-center bg-[#D8AE70] px-1 text-[11px] font-semibold text-[#100D0B]">
                  {cartCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => handleNav('/menu')}
              className="hidden sm:inline-flex items-center justify-center border border-[#D8AE70] bg-[#D8AE70] px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#100D0B] transition-all duration-200 hover:bg-[#F2D3A0] hover:border-[#F2D3A0] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F2D3A0]"
            >
              Order Now
            </button>

            <button
              type="button"
              onClick={() => setMobileOpen((v) => !v)}
              aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileOpen}
              className="inline-flex h-10 w-10 items-center justify-center border border-[#D8AE70]/25 bg-[#191411] text-[#F5EFE4] lg:hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D8AE70]"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      <div
        className={`fixed inset-0 z-50 bg-[#100D0B]/95 backdrop-blur-lg transition-opacity duration-300 lg:hidden ${
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex h-full flex-col justify-between px-6 py-6">
          <div className="flex items-center justify-between border-b border-[#D8AE70]/20 pb-4">
            <span className="font-serif text-2xl font-semibold tracking-wider text-[#F5EFE4]">
              {settings.restaurantName}
            </span>
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              aria-label="Close mobile navigation"
              className="inline-flex h-11 w-11 items-center justify-center border border-[#D8AE70]/30 text-[#F5EFE4]"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <nav aria-label="Mobile Navigation" className="flex flex-col gap-2 py-6">
            {NAV_ITEMS.map((item, idx) => {
              const active = currentPath === item.path;
              return (
                <button
                  key={item.path}
                  type="button"
                  onClick={() => handleNav(item.path)}
                  className={`flex items-center justify-between border-b border-[#D8AE70]/10 py-3.5 text-left font-serif text-3xl tracking-wide transition-colors ${
                    active ? 'text-[#D8AE70]' : 'text-[#F5EFE4] hover:text-[#F2D3A0]'
                  }`}
                >
                  <span>{item.label}</span>
                  <span className="font-mono text-xs text-[#BDB2A3]/70">
                    0{idx + 1}
                  </span>
                </button>
              );
            })}
          </nav>

          <div className="space-y-3 border-t border-[#D8AE70]/20 pt-5">
            <button
              type="button"
              onClick={() => handleNav('/menu')}
              className="flex w-full items-center justify-center bg-[#D8AE70] py-3.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#100D0B]"
            >
              Order Now
            </button>
            <button
              type="button"
              onClick={() => handleNav('/reservations')}
              className="flex w-full items-center justify-center border border-[#D8AE70]/40 py-3.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#F5EFE4]"
            >
              Reserve Your Table
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
