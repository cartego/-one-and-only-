import { ArrowUpRight, Instagram, MapPin, MessageCircle, Phone } from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';
import { AmbientSoundToggle } from './AmbientSoundToggle';

export function Footer() {
  const { currentPath, navigate, settings } = useRestaurant();

  if (currentPath === '/admin') {
    return null;
  }

  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `${settings.googlePlusCode} ${settings.address}`,
  )}`;
  const whatsappUrl = `https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent(
    `Hello ${settings.restaurantName}, I would like to inquire about dining / ordering.`,
  )}`;

  return (
    <footer className="border-t border-[#D8AE70]/20 bg-[#0C0908] text-[#BDB2A3]">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand Column */}
          <div className="space-y-4">
            <h2 className="font-serif text-3xl font-semibold tracking-wide text-[#F5EFE4]">
              {settings.restaurantName}
            </h2>
            <p className="text-sm leading-relaxed text-[#BDB2A3]">
              {settings.restaurantType}. Thoughtfully prepared vegetarian dishes served in a warm,
              family-friendly setting in Keshkal.
            </p>
            <div className="pt-2">
              <AmbientSoundToggle />
            </div>
          </div>

          {/* Visit & Contact */}
          <div className="space-y-4">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#D8AE70]">
              Location &amp; Contact
            </p>
            <div className="space-y-3 text-sm leading-relaxed">
              <div className="flex items-start gap-2.5">
                <MapPin className="mt-1 h-4 w-4 shrink-0 text-[#D8AE70]" />
                <span>
                  {settings.address}
                  <span className="mt-1 block font-mono text-xs text-[#D8AE70]/90">
                    Plus Code: {settings.googlePlusCode}
                  </span>
                </span>
              </div>
              <a
                href={`tel:${settings.phone.replace(/\s+/g, '')}`}
                className="flex items-center gap-2.5 text-[#F5EFE4] transition-colors hover:text-[#D8AE70]"
              >
                <Phone className="h-4 w-4 shrink-0 text-[#D8AE70]" />
                <span className="tabular-nums">{settings.phone}</span>
              </a>
              <a
                href={settings.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 text-[#F5EFE4] transition-colors hover:text-[#D8AE70]"
              >
                <Instagram className="h-4 w-4 shrink-0 text-[#D8AE70]" />
                <span>{settings.instagramHandle}</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#D8AE70]">
              Explore
            </p>
            <ul className="grid grid-cols-2 gap-y-2.5 text-sm">
              {[
                { label: 'Home', path: '/' },
                { label: 'Menu', path: '/menu' },
                { label: 'About', path: '/about' },
                { label: 'Gallery', path: '/gallery' },
                { label: 'Reservations', path: '/reservations' },
                { label: 'Contact', path: '/contact' },
              ].map((link) => (
                <li key={link.path}>
                  <button
                    type="button"
                    onClick={() => navigate(link.path)}
                    className="transition-colors hover:text-[#F2D3A0]"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Hours & Quick Actions */}
          <div className="space-y-4">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#D8AE70]">
              Opening Hours &amp; Actions
            </p>
            <div className="text-sm">
              <p className="text-[#F5EFE4]">Hours: {settings.openingHours}</p>
              <p className="mt-1 text-xs text-[#BDB2A3]/80">
                Average Spend: {settings.averageSpend}
              </p>
            </div>
            <div className="flex flex-col gap-2.5 pt-1">
              <a
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-between border border-[#D8AE70]/30 bg-[#191411] px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.12em] text-[#F5EFE4] transition-colors hover:border-[#D8AE70] hover:text-[#F2D3A0]"
              >
                <span>Get Directions</span>
                <ArrowUpRight className="h-3.5 w-3.5 text-[#D8AE70]" />
              </a>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-between border border-[#D8AE70]/30 bg-[#191411] px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.12em] text-[#F5EFE4] transition-colors hover:border-[#D8AE70] hover:text-[#F2D3A0]"
              >
                <span>WhatsApp Desk</span>
                <MessageCircle className="h-3.5 w-3.5 text-[#D8AE70]" />
              </a>
            </div>
          </div>
        </div>

        <div className="luxury-divider my-10" />

        <div className="flex flex-col items-start justify-between gap-4 text-xs text-[#BDB2A3]/75 sm:flex-row sm:items-center">
          <p>
            &copy; {new Date().getFullYear()} {settings.restaurantName}. Keshkal, Chhattisgarh, India.
          </p>
          <div className="flex items-center gap-4">
            <span>Pure Vegetarian Dining</span>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => navigate('/admin')}
              className="transition-colors hover:text-[#D8AE70]"
            >
              Staff Portal
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
