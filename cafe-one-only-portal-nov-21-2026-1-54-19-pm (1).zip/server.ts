import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import dotenv from 'dotenv';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import {
  UPLOADS_DIR,
  ensureStorageDirectories,
  hashPassword,
  loadDb,
  saveDb,
  verifyPassword,
} from './server/db.ts';
import type {
  GalleryCategory,
  OrderItemRecord,
  OrderRecord,
  OrderStatus,
  OrderType,
  PaymentMethod,
  PaymentStatus,
  ReservationRecord,
  ReservationStatus,
} from './src/types.ts';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const SESSION_SECRET =
  process.env.ADMIN_SESSION_SECRET ||
  crypto.createHash('sha256').update(`cafe-one-only-${process.cwd()}`).digest('hex');

const VALID_ORDER_STATUSES: OrderStatus[] = [
  'Pending',
  'Accepted',
  'Preparing',
  'Ready',
  'Completed',
  'Cancelled',
];

const VALID_RESERVATION_STATUSES: ReservationStatus[] = ['Pending', 'Approved', 'Rejected'];
const VALID_GALLERY_CATEGORIES: GalleryCategory[] = [
  'Food',
  'Restaurant',
  'Interior',
  'Outdoor Seating',
  'Special Moments',
];

interface SessionPayload {
  userId: string;
  email: string;
  role: 'admin';
  exp: number;
}

function signSessionToken(payload: SessionPayload): string {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}

function verifySessionToken(token: string | undefined): SessionPayload | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [body, sig] = parts;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as SessionPayload;
    if (!parsed || parsed.role !== 'admin' || parsed.exp < Date.now()) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx > -1) {
      const k = part.slice(0, idx).trim();
      const v = decodeURIComponent(part.slice(idx + 1).trim());
      result[k] = v;
    }
  }
  return result;
}

function extractAdminSession(req: express.Request): SessionPayload | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7).trim();
    const verified = verifySessionToken(token);
    if (verified) return verified;
  }
  const cookies = parseCookies(req.headers.cookie);
  return verifySessionToken(cookies['cafe_admin_session']);
}

function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction): void {
  const session = extractAdminSession(req);
  if (!session) {
    res.status(401).json({ error: 'Administrator authentication required.' });
    return;
  }
  const db = loadDb();
  const user = db.users.find((u) => u.id === session.userId && u.email === session.email);
  if (!user) {
    res.status(401).json({ error: 'Session no longer valid.' });
    return;
  }
  next();
}

function generateOrderNumber(): string {
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const rand = crypto.randomBytes(2).toString('hex').toUpperCase();
  return `ORD-${ymd}-${rand}`;
}

function generateReservationCode(): string {
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const rand = crypto.randomBytes(2).toString('hex').toUpperCase();
  return `RES-${ymd}-${rand}`;
}

async function startServer(): Promise<void> {
  ensureStorageDirectories();
  loadDb();

  const app = express();
  app.use(express.json({ limit: '6mb' }));
  app.use('/uploads', express.static(UPLOADS_DIR));

  // Health
  app.get('/api/health', (_req, res) => {
    const db = loadDb();
    res.json({
      ok: true,
      backendMode: db.settings.backendMode,
      hasAdmin: db.users.length > 0,
    });
  });

  // Public bootstrap data
  app.get('/api/bootstrap', (_req, res) => {
    const db = loadDb();
    res.json({
      categories: [...db.categories].sort((a, b) => a.sortOrder - b.sortOrder),
      menuItems: db.menuItems,
      galleryImages: db.galleryImages,
      settings: db.settings,
      hasAdmin: db.users.length > 0,
    });
  });

  // Create order (server computes authoritative totals)
  app.post('/api/orders', (req, res) => {
    const db = loadDb();
    const body = req.body as {
      customerName?: string;
      customerPhone?: string;
      orderType?: OrderType;
      deliveryAddress?: string;
      specialInstructions?: string;
      paymentMethod?: PaymentMethod;
      paymentReference?: string;
      items?: Array<{ menuItemId: string; quantity: number; customization?: string }>;
    };

    const customerName = (body.customerName || '').trim();
    const customerPhone = (body.customerPhone || '').trim();
    const orderType = body.orderType;
    const deliveryAddress = (body.deliveryAddress || '').trim();
    const specialInstructions = (body.specialInstructions || '').trim();
    const paymentMethod = body.paymentMethod || 'Cash / Pay at Restaurant';
    const paymentReference = (body.paymentReference || '').trim();

    if (customerName.length < 2) {
      res.status(400).json({ error: 'Please enter your full name.' });
      return;
    }
    if (!/^[+\d\s()-]{8,18}$/.test(customerPhone)) {
      res.status(400).json({ error: 'Please enter a valid mobile number.' });
      return;
    }
    if (!orderType || !['Dine-in', 'Takeaway', 'Delivery'].includes(orderType)) {
      res.status(400).json({ error: 'Please choose a valid order type.' });
      return;
    }
    if (orderType === 'Delivery' && !db.settings.deliveryEnabled) {
      res.status(400).json({ error: 'Delivery is currently paused by the restaurant.' });
      return;
    }
    if (orderType === 'Delivery' && deliveryAddress.length < 6) {
      res.status(400).json({ error: 'Please provide a complete delivery address.' });
      return;
    }
    if (!Array.isArray(body.items) || body.items.length === 0) {
      res.status(400).json({ error: 'Your cart is empty.' });
      return;
    }

    if (paymentMethod === 'Online Gateway' && !db.settings.paymentGatewayEnabled) {
      res.status(400).json({
        error: 'Online payment gateway is not yet configured. Please choose Cash/Pay at Restaurant, UPI, or WhatsApp ordering.',
      });
      return;
    }

    const resolvedItems: OrderItemRecord[] = [];
    let subtotal = 0;
    let hasUnpricedItems = false;

    for (const reqItem of body.items) {
      const dish = db.menuItems.find((m) => m.id === reqItem.menuItemId);
      if (!dish) {
        res.status(400).json({ error: 'One or more selected dishes are no longer on the menu.' });
        return;
      }
      if (!dish.isAvailable) {
        res.status(400).json({ error: `${dish.name} is currently unavailable.` });
        return;
      }
      const qty = Math.max(1, Math.min(50, Math.floor(Number(reqItem.quantity) || 1)));
      if (dish.price === null) {
        hasUnpricedItems = true;
      } else {
        subtotal += dish.price * qty;
      }
      resolvedItems.push({
        id: crypto.randomUUID(),
        menuItemId: dish.id,
        name: dish.name,
        unitPrice: dish.price,
        quantity: qty,
        customization: reqItem.customization ? String(reqItem.customization).slice(0, 80) : undefined,
      });
    }

    const taxAmount = Number(((subtotal * (db.settings.taxRatePercent || 0)) / 100).toFixed(2));
    let deliveryCharge = 0;
    if (orderType === 'Delivery' && db.settings.deliveryFee > 0) {
      if (db.settings.freeDeliveryThreshold > 0 && subtotal >= db.settings.freeDeliveryThreshold) {
        deliveryCharge = 0;
      } else {
        deliveryCharge = db.settings.deliveryFee;
      }
    }
    const totalAmount = Number((subtotal + taxAmount + deliveryCharge).toFixed(2));

    // Never mark UPI or Online Gateway as Verified from client payload alone
    let paymentStatus: PaymentStatus = 'Pending';
    if (paymentMethod === 'UPI') {
      paymentStatus = 'Verification Required';
    } else if (paymentMethod === 'Online Gateway') {
      paymentStatus = 'Pending';
    }

    const now = new Date().toISOString();
    const order: OrderRecord = {
      id: crypto.randomUUID(),
      orderNumber: generateOrderNumber(),
      customerName,
      customerPhone,
      orderType,
      deliveryAddress,
      specialInstructions,
      items: resolvedItems,
      subtotal,
      hasUnpricedItems,
      taxAmount,
      deliveryCharge,
      totalAmount,
      status: 'Pending',
      paymentMethod,
      paymentStatus,
      paymentReference: paymentReference || undefined,
      createdAt: now,
      updatedAt: now,
    };

    db.orders.unshift(order);
    db.paymentTransactions.unshift({
      id: crypto.randomUUID(),
      orderId: order.id,
      orderNumber: order.orderNumber,
      provider:
        paymentMethod === 'Online Gateway'
          ? db.settings.paymentProviderName
          : paymentMethod,
      method: paymentMethod,
      amount: totalAmount,
      status: paymentStatus,
      reference: paymentReference || 'Awaiting verification',
      createdAt: now,
    });
    saveDb(db);

    res.status(201).json({ order });
  });

  // Lookup order status (orderNumber + phone last 4 digits)
  app.get('/api/orders/:orderNumber', (req, res) => {
    const db = loadDb();
    const phoneDigits = String(req.query.phone4 || '').replace(/\D/g, '');
    const order = db.orders.find(
      (o) => o.orderNumber.toUpperCase() === req.params.orderNumber.toUpperCase(),
    );
    if (!order) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }
    const orderDigits = order.customerPhone.replace(/\D/g, '');
    if (phoneDigits && !orderDigits.endsWith(phoneDigits)) {
      res.status(403).json({ error: 'Phone verification did not match.' });
      return;
    }
    res.json({ order });
  });

  // Server-side payment verification hook (never returns success without provider signature/configuration)
  app.post('/api/payments/verify', (req, res) => {
    const db = loadDb();
    if (!db.settings.paymentGatewayEnabled) {
      res.status(503).json({
        verified: false,
        error: 'Online payment verification requires an active payment provider configuration in Admin Settings.',
      });
      return;
    }
    res.status(400).json({
      verified: false,
      error: 'Provider webhook/signature verification failed or missing signature.',
    });
  });

  // Table Reservations (Always created as Pending until approved by restaurant)
  app.post('/api/reservations', (req, res) => {
    const db = loadDb();
    const body = req.body as {
      customerName?: string;
      customerPhone?: string;
      customerEmail?: string;
      reservationDate?: string;
      reservationTime?: string;
      guestCount?: number;
      specialRequests?: string;
    };

    const customerName = (body.customerName || '').trim();
    const customerPhone = (body.customerPhone || '').trim();
    const customerEmail = (body.customerEmail || '').trim();
    const reservationDate = (body.reservationDate || '').trim();
    const reservationTime = (body.reservationTime || '').trim();
    const guestCount = Math.floor(Number(body.guestCount) || 0);
    const specialRequests = (body.specialRequests || '').trim();

    if (customerName.length < 2) {
      res.status(400).json({ error: 'Please enter your name.' });
      return;
    }
    if (!/^[+\d\s()-]{8,18}$/.test(customerPhone)) {
      res.status(400).json({ error: 'Please enter a valid phone number.' });
      return;
    }
    if (customerEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(reservationDate)) {
      res.status(400).json({ error: 'Please select a valid reservation date.' });
      return;
    }

    const todayStr = new Date().toISOString().slice(0, 10);
    if (reservationDate < todayStr) {
      res.status(400).json({ error: 'Past dates cannot be reserved. Please choose today or a future date.' });
      return;
    }

    if (!db.settings.reservationTimeSlots.includes(reservationTime)) {
      res.status(400).json({ error: 'Please select one of the available time slots.' });
      return;
    }
    if (guestCount < 1 || guestCount > db.settings.maxGuestsPerBooking) {
      res.status(400).json({
        error: `Guest count must be between 1 and ${db.settings.maxGuestsPerBooking}. For larger groups, please call us directly.`,
      });
      return;
    }

    const now = new Date().toISOString();
    const reservation: ReservationRecord = {
      id: crypto.randomUUID(),
      referenceCode: generateReservationCode(),
      customerName,
      customerPhone,
      customerEmail,
      reservationDate,
      reservationTime,
      guestCount,
      specialRequests,
      status: 'Pending',
      createdAt: now,
      updatedAt: now,
    };

    db.reservations.unshift(reservation);
    saveDb(db);

    res.status(201).json({ reservation });
  });

  // Contact Inquiry Form
  app.post('/api/contact', (req, res) => {
    const db = loadDb();
    const body = req.body as {
      name?: string;
      phone?: string;
      email?: string;
      subject?: string;
      message?: string;
    };

    const name = (body.name || '').trim();
    const phone = (body.phone || '').trim();
    const email = (body.email || '').trim();
    const subject = (body.subject || 'General Inquiry').trim();
    const message = (body.message || '').trim();

    if (name.length < 2) {
      res.status(400).json({ error: 'Please enter your name.' });
      return;
    }
    if (!/^[+\d\s()-]{8,18}$/.test(phone)) {
      res.status(400).json({ error: 'Please provide a valid phone number.' });
      return;
    }
    if (message.length < 5) {
      res.status(400).json({ error: 'Please enter your message.' });
      return;
    }

    const entry = {
      id: crypto.randomUUID(),
      name,
      phone,
      email,
      subject,
      message,
      createdAt: new Date().toISOString(),
    };
    db.contactMessages.unshift(entry);
    saveDb(db);

    res.status(201).json({ ok: true, id: entry.id });
  });

  // ---------------- ADMIN AUTH ----------------
  app.get('/api/admin/status', (req, res) => {
    const db = loadDb();
    const session = extractAdminSession(req);
    const validUser = session
      ? db.users.find((u) => u.id === session.userId && u.email === session.email)
      : null;

    res.json({
      hasAdmin: db.users.length > 0,
      authenticated: Boolean(validUser),
      adminEmail: validUser ? validUser.email : null,
      adminName: validUser ? validUser.name : null,
    });
  });

  // Initial one-time admin account setup (only when no admin user exists yet)
  app.post('/api/admin/setup', (req, res) => {
    const db = loadDb();
    if (db.users.length > 0) {
      res.status(403).json({ error: 'Administrator account already configured. Please sign in.' });
      return;
    }
    const body = req.body as { email?: string; password?: string; name?: string };
    const email = (body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const name = (body.name || 'Restaurant Administrator').trim();

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: 'Enter a valid administrator email.' });
      return;
    }
    if (password.length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters.' });
      return;
    }

    const { hash, salt } = hashPassword(password);
    const userId = crypto.randomUUID();
    db.users.push({
      id: userId,
      email,
      name,
      role: 'admin',
      passwordHash: hash,
      salt,
      createdAt: new Date().toISOString(),
    });
    saveDb(db);

    const token = signSessionToken({
      userId,
      email,
      role: 'admin',
      exp: Date.now() + 1000 * 60 * 60 * 12,
    });
    res.setHeader(
      'Set-Cookie',
      `cafe_admin_session=${encodeURIComponent(token)}; HttpOnly; Path=/; Max-Age=43200; SameSite=Lax`,
    );
    res.status(201).json({ token, email, name });
  });

  app.post('/api/admin/login', (req, res) => {
    const db = loadDb();
    const body = req.body as { email?: string; password?: string };
    const email = (body.email || '').trim().toLowerCase();
    const password = String(body.password || '');

    const user = db.users.find((u) => u.email === email);
    if (!user || !verifyPassword(password, user.passwordHash, user.salt)) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const token = signSessionToken({
      userId: user.id,
      email: user.email,
      role: 'admin',
      exp: Date.now() + 1000 * 60 * 60 * 12,
    });
    res.setHeader(
      'Set-Cookie',
      `cafe_admin_session=${encodeURIComponent(token)}; HttpOnly; Path=/; Max-Age=43200; SameSite=Lax`,
    );
    res.json({ token, email: user.email, name: user.name });
  });

  app.post('/api/admin/logout', (_req, res) => {
    res.setHeader('Set-Cookie', 'cafe_admin_session=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax');
    res.json({ ok: true });
  });

  app.post('/api/admin/recover', (req, res) => {
    const db = loadDb();
    const body = req.body as { email?: string; recoveryKey?: string; newPassword?: string };
    const email = (body.email || '').trim().toLowerCase();
    const recoveryKey = String(body.recoveryKey || '');
    const newPassword = String(body.newPassword || '');

    const configuredKey = process.env.ADMIN_RECOVERY_KEY;
    if (!configuredKey) {
      res.status(503).json({
        error:
          'Password recovery requires ADMIN_RECOVERY_KEY to be set in server environment variables.',
      });
      return;
    }
    const user = db.users.find((u) => u.email === email);
    if (!user || recoveryKey !== configuredKey) {
      res.status(403).json({ error: 'Invalid recovery credentials.' });
      return;
    }
    if (newPassword.length < 8) {
      res.status(400).json({ error: 'New password must be at least 8 characters.' });
      return;
    }
    const { hash, salt } = hashPassword(newPassword);
    user.passwordHash = hash;
    user.salt = salt;
    saveDb(db);
    res.json({ ok: true });
  });

  // ---------------- PROTECTED ADMIN DATA ROUTES ----------------
  app.get('/api/admin/overview', requireAdmin, (_req, res) => {
    const db = loadDb();
    const todayPrefix = new Date().toISOString().slice(0, 10);

    const todayOrders = db.orders.filter((o) => o.createdAt.startsWith(todayPrefix)).length;
    const pendingOrders = db.orders.filter((o) => o.status === 'Pending').length;
    const completedOrders = db.orders.filter((o) => o.status === 'Completed').length;
    const pendingReservations = db.reservations.filter((r) => r.status === 'Pending').length;

    const verifiedRevenue = db.orders
      .filter((o) => o.paymentStatus === 'Verified' || o.status === 'Completed')
      .reduce((acc, o) => acc + o.totalAmount, 0);

    const counts: Record<string, number> = {};
    for (const order of db.orders) {
      if (order.status === 'Cancelled') continue;
      for (const item of order.items) {
        counts[item.name] = (counts[item.name] || 0) + item.quantity;
      }
    }
    const popularDishes = Object.entries(counts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 6);

    res.json({
      stats: {
        totalOrders: db.orders.length,
        todayOrders,
        pendingOrders,
        completedOrders,
        totalReservations: db.reservations.length,
        pendingReservations,
        verifiedRevenue: Number(verifiedRevenue.toFixed(2)),
      },
      popularDishes,
      orders: db.orders,
      reservations: db.reservations,
      messages: db.contactMessages,
      settings: db.settings,
    });
  });

  // Categories CRUD
  app.post('/api/admin/categories', requireAdmin, (req, res) => {
    const db = loadDb();
    const name = String((req.body as { name?: string }).name || '').trim();
    if (name.length < 2) {
      res.status(400).json({ error: 'Category name is required.' });
      return;
    }
    if (db.categories.some((c) => c.name.toLowerCase() === name.toLowerCase())) {
      res.status(400).json({ error: 'Category already exists.' });
      return;
    }
    const cat = {
      id: `cat-${crypto.randomUUID().slice(0, 8)}`,
      name,
      sortOrder: db.categories.length + 1,
    };
    db.categories.push(cat);
    saveDb(db);
    res.status(201).json({ category: cat });
  });

  app.delete('/api/admin/categories/:id', requireAdmin, (req, res) => {
    const db = loadDb();
    const hasDishes = db.menuItems.some((m) => m.categoryId === req.params.id);
    if (hasDishes) {
      res.status(400).json({ error: 'Reassign or remove dishes in this category before deleting it.' });
      return;
    }
    db.categories = db.categories.filter((c) => c.id !== req.params.id);
    saveDb(db);
    res.json({ ok: true });
  });

  // Menu Items CRUD
  app.post('/api/admin/menu', requireAdmin, (req, res) => {
    const db = loadDb();
    const body = req.body as {
      name?: string;
      description?: string;
      price?: number | null | string;
      categoryId?: string;
      imageUrl?: string;
      isVeganFriendly?: boolean;
      isAvailable?: boolean;
      isFeatured?: boolean;
      prepTimeMinutes?: number | null | string;
      customizations?: string[];
    };

    const name = (body.name || '').trim();
    const description = (body.description || '').trim();
    const cat = db.categories.find((c) => c.id === body.categoryId);
    if (name.length < 2 || !cat) {
      res.status(400).json({ error: 'Dish name and valid category are required.' });
      return;
    }

    const parsedPrice =
      body.price === null || body.price === '' || body.price === undefined
        ? null
        : Number(body.price);
    if (parsedPrice !== null && (Number.isNaN(parsedPrice) || parsedPrice < 0)) {
      res.status(400).json({ error: 'Price must be a valid positive number or left blank.' });
      return;
    }

    const parsedPrep =
      body.prepTimeMinutes === null || body.prepTimeMinutes === '' || body.prepTimeMinutes === undefined
        ? null
        : Math.max(1, Math.floor(Number(body.prepTimeMinutes)));

    const item = {
      id: `dish-${crypto.randomUUID().slice(0, 8)}`,
      name,
      description: description || 'Freshly prepared pure vegetarian dish.',
      price: parsedPrice,
      categoryId: cat.id,
      categoryName: cat.name,
      imageUrl: (body.imageUrl || '/src/assets/images/dish_veg_thali_1795248973066.jpg').trim(),
      isVegetarian: true,
      isVeganFriendly: Boolean(body.isVeganFriendly),
      isAvailable: body.isAvailable !== false,
      isFeatured: Boolean(body.isFeatured),
      prepTimeMinutes: parsedPrep && !Number.isNaN(parsedPrep) ? parsedPrep : null,
      customizations: Array.isArray(body.customizations)
        ? body.customizations.map((s) => String(s).trim()).filter(Boolean)
        : undefined,
    };

    db.menuItems.push(item);
    saveDb(db);
    res.status(201).json({ item });
  });

  app.patch('/api/admin/menu/:id', requireAdmin, (req, res) => {
    const db = loadDb();
    const idx = db.menuItems.findIndex((m) => m.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'Dish not found.' });
      return;
    }
    const current = db.menuItems[idx];
    const body = req.body as Record<string, unknown>;

    if (typeof body.name === 'string' && body.name.trim().length >= 2) {
      current.name = body.name.trim();
    }
    if (typeof body.description === 'string') {
      current.description = body.description.trim();
    }
    if ('price' in body) {
      if (body.price === null || body.price === '') {
        current.price = null;
      } else {
        const p = Number(body.price);
        if (Number.isNaN(p) || p < 0) {
          res.status(400).json({ error: 'Invalid price value.' });
          return;
        }
        current.price = p;
      }
    }
    if (typeof body.categoryId === 'string') {
      const cat = db.categories.find((c) => c.id === body.categoryId);
      if (cat) {
        current.categoryId = cat.id;
        current.categoryName = cat.name;
      }
    }
    if (typeof body.imageUrl === 'string' && body.imageUrl.trim()) {
      current.imageUrl = body.imageUrl.trim();
    }
    if (typeof body.isAvailable === 'boolean') current.isAvailable = body.isAvailable;
    if (typeof body.isFeatured === 'boolean') current.isFeatured = body.isFeatured;
    if (typeof body.isVeganFriendly === 'boolean') current.isVeganFriendly = body.isVeganFriendly;
    if ('prepTimeMinutes' in body) {
      current.prepTimeMinutes =
        body.prepTimeMinutes === null || body.prepTimeMinutes === ''
          ? null
          : Math.max(1, Math.floor(Number(body.prepTimeMinutes)));
    }

    db.menuItems[idx] = current;
    saveDb(db);
    res.json({ item: current });
  });

  app.delete('/api/admin/menu/:id', requireAdmin, (req, res) => {
    const db = loadDb();
    db.menuItems = db.menuItems.filter((m) => m.id !== req.params.id);
    saveDb(db);
    res.json({ ok: true });
  });

  // Orders Management
  app.patch('/api/admin/orders/:id', requireAdmin, (req, res) => {
    const db = loadDb();
    const order = db.orders.find((o) => o.id === req.params.id);
    if (!order) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }
    const body = req.body as { status?: OrderStatus; paymentStatus?: PaymentStatus };
    if (body.status) {
      if (!VALID_ORDER_STATUSES.includes(body.status)) {
        res.status(400).json({ error: 'Invalid order status.' });
        return;
      }
      order.status = body.status;
    }
    if (body.paymentStatus) {
      if (!['Pending', 'Verification Required', 'Verified', 'Failed'].includes(body.paymentStatus)) {
        res.status(400).json({ error: 'Invalid payment status.' });
        return;
      }
      order.paymentStatus = body.paymentStatus;
      const tx = db.paymentTransactions.find((t) => t.orderId === order.id);
      if (tx) tx.status = body.paymentStatus;
    }
    order.updatedAt = new Date().toISOString();
    saveDb(db);
    res.json({ order });
  });

  // Reservations Management
  app.patch('/api/admin/reservations/:id', requireAdmin, (req, res) => {
    const db = loadDb();
    const reservation = db.reservations.find((r) => r.id === req.params.id);
    if (!reservation) {
      res.status(404).json({ error: 'Reservation not found.' });
      return;
    }
    const body = req.body as { status?: ReservationStatus; guestCount?: number };
    if (body.status) {
      if (!VALID_RESERVATION_STATUSES.includes(body.status)) {
        res.status(400).json({ error: 'Invalid reservation status.' });
        return;
      }
      reservation.status = body.status;
    }
    if (body.guestCount !== undefined) {
      reservation.guestCount = Math.max(1, Math.min(50, Math.floor(Number(body.guestCount) || 1)));
    }
    reservation.updatedAt = new Date().toISOString();
    saveDb(db);
    res.json({ reservation });
  });

  // Settings Management
  app.put('/api/admin/settings', requireAdmin, (req, res) => {
    const db = loadDb();
    const body = req.body as Partial<typeof db.settings>;
    const current = db.settings;

    if (typeof body.restaurantName === 'string' && body.restaurantName.trim()) {
      current.restaurantName = body.restaurantName.trim();
    }
    if (typeof body.phone === 'string' && body.phone.trim()) current.phone = body.phone.trim();
    if (typeof body.whatsappNumber === 'string' && body.whatsappNumber.trim()) {
      current.whatsappNumber = body.whatsappNumber.replace(/\D/g, '');
    }
    if (typeof body.address === 'string' && body.address.trim()) current.address = body.address.trim();
    if (typeof body.instagramUrl === 'string' && body.instagramUrl.trim()) {
      current.instagramUrl = body.instagramUrl.trim();
    }
    if (typeof body.openingHours === 'string') current.openingHours = body.openingHours.trim() || 'To be confirmed';
    if (typeof body.taxRatePercent === 'number' && body.taxRatePercent >= 0) {
      current.taxRatePercent = Math.min(28, body.taxRatePercent);
    }
    if (typeof body.deliveryFee === 'number' && body.deliveryFee >= 0) {
      current.deliveryFee = body.deliveryFee;
    }
    if (typeof body.freeDeliveryThreshold === 'number' && body.freeDeliveryThreshold >= 0) {
      current.freeDeliveryThreshold = body.freeDeliveryThreshold;
    }
    if (typeof body.deliveryEnabled === 'boolean') current.deliveryEnabled = body.deliveryEnabled;
    if (typeof body.dineInEnabled === 'boolean') current.dineInEnabled = body.dineInEnabled;
    if (typeof body.takeawayEnabled === 'boolean') current.takeawayEnabled = body.takeawayEnabled;
    if (typeof body.upiId === 'string') current.upiId = body.upiId.trim();
    if (typeof body.paymentProviderName === 'string') {
      current.paymentProviderName = body.paymentProviderName.trim() || 'To be configured';
    }
    if (typeof body.paymentGatewayEnabled === 'boolean') {
      current.paymentGatewayEnabled = body.paymentGatewayEnabled;
    }
    if (Array.isArray(body.reservationTimeSlots)) {
      current.reservationTimeSlots = body.reservationTimeSlots
        .map((s) => String(s).trim())
        .filter(Boolean);
    }
    if (typeof body.maxGuestsPerBooking === 'number' && body.maxGuestsPerBooking >= 1) {
      current.maxGuestsPerBooking = Math.min(100, Math.floor(body.maxGuestsPerBooking));
    }

    db.settings = current;
    saveDb(db);
    res.json({ settings: current });
  });

  // Gallery CRUD
  app.post('/api/admin/gallery', requireAdmin, (req, res) => {
    const db = loadDb();
    const body = req.body as {
      title?: string;
      caption?: string;
      category?: GalleryCategory;
      imageUrl?: string;
    };
    const title = (body.title || '').trim();
    const imageUrl = (body.imageUrl || '').trim();
    const category = body.category && VALID_GALLERY_CATEGORIES.includes(body.category)
      ? body.category
      : 'Restaurant';

    if (!title || !imageUrl) {
      res.status(400).json({ error: 'Title and image URL are required.' });
      return;
    }

    const item = {
      id: `gal-${crypto.randomUUID().slice(0, 8)}`,
      title,
      caption: (body.caption || '').trim(),
      category,
      imageUrl,
      createdAt: new Date().toISOString(),
    };
    db.galleryImages.unshift(item);
    saveDb(db);
    res.status(201).json({ item });
  });

  app.delete('/api/admin/gallery/:id', requireAdmin, (req, res) => {
    const db = loadDb();
    db.galleryImages = db.galleryImages.filter((g) => g.id !== req.params.id);
    saveDb(db);
    res.json({ ok: true });
  });

  // Secure image upload endpoint
  app.post('/api/admin/upload', requireAdmin, (req, res) => {
    const body = req.body as { dataUrl?: string; filename?: string };
    const dataUrl = String(body.dataUrl || '');
    const match = /^data:(image\/(?:jpeg|jpg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
    if (!match) {
      res.status(400).json({ error: 'Please upload a valid JPEG, PNG, or WebP image.' });
      return;
    }
    const mime = match[1];
    const buf = Buffer.from(match[2], 'base64');
    if (buf.length > 4 * 1024 * 1024) {
      res.status(400).json({ error: 'Image size must be under 4 MB.' });
      return;
    }
    const ext = mime === 'image/png' ? 'png' : mime === 'image/webp' ? 'webp' : 'jpg';
    const fileName = `${crypto.randomUUID()}.${ext}`;
    ensureStorageDirectories();
    fs.writeFileSync(path.join(UPLOADS_DIR, fileName), buf);
    res.status(201).json({ url: `/uploads/${fileName}` });
  });

  // Vite Dev Middleware or Static Production Build
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Cafe One & Only server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server startup error:', err);
  process.exit(1);
});
