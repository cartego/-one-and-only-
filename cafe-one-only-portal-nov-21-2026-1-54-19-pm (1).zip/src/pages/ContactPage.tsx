import { useState } from 'react';
import {
  ArrowUpRight,
  CheckCircle2,
  Instagram,
  MapPin,
  MessageCircle,
  Phone,
  ShieldAlert,
} from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';

export function ContactPage() {
  const { settings } = useRestaurant();

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('General Inquiry');
  const [message, setMessage] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  const mapsSearchUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `${settings.googlePlusCode} ${settings.address}`,
  )}`;
  const mapsEmbedUrl = `https://www.google.com/maps?q=${encodeURIComponent(
    `${settings.googlePlusCode} Keshkal Chhattisgarh 494331`,
  )}&output=embed`;
  const whatsappUrl = `https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent(
    `Hello ${settings.restaurantName}, I have a question regarding dining / reservations.`,
  )}`;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (name.trim().length < 2) {
      setError('Please enter your name.');
      return;
    }
    if (!/^[+\d\s()-]{8,18}$/.test(phone.trim())) {
      setError('Please enter a valid phone number.');
      return;
    }
    if (message.trim().length < 5) {
      setError('Please enter your message.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          phone: phone.trim(),
          email: email.trim(),
          subject,
          message: message.trim(),
        }),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (!res.ok || !data.ok) {
        throw new Error(data.error || 'Could not send message.');
      }
      setSent(true);
      setName('');
      setPhone('');
      setEmail('');
      setMessage('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to send message.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#100D0B] pb-24 pt-28 text-[#F5EFE4]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl border-b border-[#D8AE70]/20 pb-10">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#D8AE70]">
            Visit &amp; Connect
          </p>
          <h1 className="mt-3 font-serif text-5xl font-semibold text-[#F5EFE4] sm:text-6xl">
            Find Us in Keshkal
          </h1>
          <p className="mt-4 text-base text-[#BDB2A3]">
            Located on Borgaon Road in Garka, Keshkal — easy to reach for local families and
            travellers heading towards Bastar.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-10 lg:grid-cols-12">
          {/* Left: Location Card & Map */}
          <div className="space-y-6 lg:col-span-6">
            <div className="border border-[#D8AE70]/25 bg-[#191411] p-7 sm:p-8">
              <h2 className="font-serif text-3xl font-semibold text-[#F5EFE4]">
                {settings.restaurantName}
              </h2>
              <p className="mt-1 text-xs uppercase tracking-[0.16em] text-[#D8AE70]">
                {settings.restaurantType}
              </p>

              <div className="mt-6 space-y-4 text-sm text-[#BDB2A3]">
                <div className="flex items-start gap-3">
                  <MapPin className="mt-1 h-4 w-4 shrink-0 text-[#D8AE70]" />
                  <div>
                    <p className="text-[#F5EFE4]">{settings.address}</p>
                    <p className="mt-1 font-mono text-xs text-[#D8AE70]">
                      Google Plus Code: {settings.googlePlusCode}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Phone className="h-4 w-4 shrink-0 text-[#D8AE70]" />
                  <a
                    href={`tel:${settings.phone.replace(/\s+/g, '')}`}
                    className="tabular-nums text-[#F5EFE4] hover:text-[#D8AE70]"
                  >
                    {settings.phone}
                  </a>
                </div>

                <div className="flex items-center gap-3">
                  <Instagram className="h-4 w-4 shrink-0 text-[#D8AE70]" />
                  <a
                    href={settings.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#F5EFE4] hover:text-[#D8AE70]"
                  >
                    {settings.instagramHandle}
                  </a>
                </div>
              </div>

              <div className="mt-7 flex flex-wrap gap-3">
                <a
                  href={mapsSearchUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-[#D8AE70] px-5 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-[#100D0B] hover:bg-[#F2D3A0]"
                >
                  <span>Get Directions</span>
                  <ArrowUpRight className="h-4 w-4" />
                </a>
                <a
                  href={`tel:${settings.phone.replace(/\s+/g, '')}`}
                  className="inline-flex items-center gap-2 border border-[#D8AE70]/40 px-5 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-[#F5EFE4] hover:border-[#D8AE70]"
                >
                  <Phone className="h-3.5 w-3.5 text-[#D8AE70]" />
                  <span>Call Now</span>
                </a>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 border border-[#D8AE70]/40 px-5 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-[#F5EFE4] hover:border-[#D8AE70]"
                >
                  <MessageCircle className="h-3.5 w-3.5 text-[#D8AE70]" />
                  <span>WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Embedded Google Maps Search View (No fabricated lat/lng) */}
            <div className="overflow-hidden border border-[#D8AE70]/25 bg-[#191411]">
              <iframe
                title="Cafe One & Only Keshkal Location Map"
                src={mapsEmbedUrl}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-72 w-full border-0 grayscale contrast-125 invert-[0.92] hue-rotate-180"
              />
            </div>
          </div>

          {/* Right: Contact Form */}
          <div className="lg:col-span-6">
            <div className="border border-[#D8AE70]/25 bg-[#191411] p-7 sm:p-9">
              <h2 className="font-serif text-3xl font-semibold text-[#F5EFE4]">
                Send a Message
              </h2>
              <p className="mt-2 text-sm text-[#BDB2A3]">
                Questions about group dining, party bookings, or takeaway? Reach out directly.
              </p>

              {sent ? (
                <div className="mt-6 border border-emerald-500/35 bg-emerald-950/25 p-6">
                  <div className="flex items-center gap-2.5 text-emerald-300">
                    <CheckCircle2 className="h-5 w-5" />
                    <span className="font-serif text-2xl">Message Received</span>
                  </div>
                  <p className="mt-2 text-sm text-[#BDB2A3]">
                    Thank you for contacting {settings.restaurantName}. Our team will respond to
                    you shortly.
                  </p>
                  <button
                    type="button"
                    onClick={() => setSent(false)}
                    className="mt-5 border border-[#D8AE70]/40 px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#F5EFE4]"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="mt-6 space-y-5">
                  {error && (
                    <div className="flex items-start gap-3 border border-red-500/40 bg-red-950/30 p-4 text-sm text-red-200">
                      <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
                      <span>{error}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="contact-name"
                        className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                      >
                        Name *
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Your name"
                        className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="contact-phone"
                        className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                      >
                        Phone *
                      </label>
                      <input
                        id="contact-phone"
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+91 98XXXXXXXX"
                        className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="contact-email"
                        className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                      >
                        Email (Optional)
                      </label>
                      <input
                        id="contact-email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@example.com"
                        className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="contact-subject"
                        className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                      >
                        Topic
                      </label>
                      <select
                        id="contact-subject"
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                      >
                        <option value="General Inquiry">General Inquiry</option>
                        <option value="Parties & Events">Parties &amp; Events</option>
                        <option value="Group Dining">Group Dining</option>
                        <option value="Feedback">Feedback</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="contact-msg"
                      className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]"
                    >
                      Message *
                    </label>
                    <textarea
                      id="contact-msg"
                      rows={4}
                      required
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="How can our team assist you?"
                      className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full bg-[#D8AE70] py-4 text-xs font-semibold uppercase tracking-[0.16em] text-[#100D0B] transition-colors hover:bg-[#F2D3A0] disabled:opacity-60"
                  >
                    {submitting ? 'Sending...' : 'Send Message'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
