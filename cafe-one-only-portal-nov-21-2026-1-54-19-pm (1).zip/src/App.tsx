import { Preloader } from './components/Preloader';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { RestaurantProvider, useRestaurant } from './context/RestaurantContext';
import { HomePage } from './pages/HomePage';
import { MenuPage } from './pages/MenuPage';
import { AboutPage } from './pages/AboutPage';
import { GalleryPage } from './pages/GalleryPage';
import { ReservationsPage } from './pages/ReservationsPage';
import { ContactPage } from './pages/ContactPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { AdminPage } from './pages/AdminPage';

function AppRouter() {
  const { currentPath, toastMessage, navigate } = useRestaurant();

  const renderPage = () => {
    switch (currentPath) {
      case '/':
        return <HomePage />;
      case '/menu':
        return <MenuPage />;
      case '/about':
        return <AboutPage />;
      case '/gallery':
        return <GalleryPage />;
      case '/reservations':
        return <ReservationsPage />;
      case '/contact':
        return <ContactPage />;
      case '/checkout':
        return <CheckoutPage />;
      case '/admin':
        return <AdminPage />;
      default:
        return (
          <div className="flex min-h-[75vh] flex-col items-center justify-center bg-[#100D0B] px-4 pt-24 text-center text-[#F5EFE4]">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#D8AE70]">404</p>
            <h1 className="mt-2 font-serif text-5xl font-semibold">Page Not Found</h1>
            <p className="mt-3 text-sm text-[#BDB2A3]">
              The page you requested does not exist on Cafe One &amp; Only.
            </p>
            <button
              type="button"
              onClick={() => navigate('/')}
              className="mt-6 bg-[#D8AE70] px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#100D0B]"
            >
              Return Home
            </button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#100D0B] text-[#F5EFE4]">
      <Preloader />
      <Header />
      <main>{renderPage()}</main>
      <Footer />
      <CartDrawer />

      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 border border-[#D8AE70]/50 bg-[#191411] px-5 py-3 text-xs font-medium tracking-wide text-[#F2D3A0] shadow-xl"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <RestaurantProvider>
      <AppRouter />
    </RestaurantProvider>
  );
}
