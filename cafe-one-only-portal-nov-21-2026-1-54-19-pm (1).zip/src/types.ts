export type OrderType = 'Dine-in' | 'Takeaway' | 'Delivery';

export type OrderStatus =
  | 'Pending'
  | 'Accepted'
  | 'Preparing'
  | 'Ready'
  | 'Completed'
  | 'Cancelled';

export type PaymentMethod = 'Cash / Pay at Restaurant' | 'UPI' | 'Online Gateway';

export type PaymentStatus =
  | 'Pending'
  | 'Verification Required'
  | 'Verified'
  | 'Failed';

export type ReservationStatus = 'Pending' | 'Approved' | 'Rejected';

export type GalleryCategory =
  | 'Food'
  | 'Restaurant'
  | 'Interior'
  | 'Outdoor Seating'
  | 'Special Moments';

export interface Category {
  id: string;
  name: string;
  sortOrder: number;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number | null; // null = To be entered by administrator
  categoryId: string;
  categoryName: string;
  imageUrl: string;
  isVegetarian: boolean;
  isVeganFriendly: boolean;
  isAvailable: boolean;
  isFeatured: boolean;
  prepTimeMinutes: number | null;
  customizations?: string[];
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  customization?: string;
}

export interface OrderItemRecord {
  id: string;
  menuItemId: string;
  name: string;
  unitPrice: number | null;
  quantity: number;
  customization?: string;
}

export interface OrderRecord {
  id: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  orderType: OrderType;
  deliveryAddress: string;
  specialInstructions: string;
  items: OrderItemRecord[];
  subtotal: number;
  hasUnpricedItems: boolean;
  taxAmount: number;
  deliveryCharge: number;
  totalAmount: number;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  paymentReference?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ReservationRecord {
  id: string;
  referenceCode: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  reservationDate: string;
  reservationTime: string;
  guestCount: number;
  specialRequests: string;
  status: ReservationStatus;
  createdAt: string;
  updatedAt: string;
}

export interface GalleryImage {
  id: string;
  title: string;
  caption: string;
  category: GalleryCategory;
  imageUrl: string;
  createdAt: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
}

export interface RestaurantSettings {
  restaurantName: string;
  restaurantType: string;
  phone: string;
  whatsappNumber: string;
  address: string;
  googlePlusCode: string;
  instagramUrl: string;
  instagramHandle: string;
  openingHours: string;
  averageSpend: string;
  rating: string;
  reviewCount: number;
  taxRatePercent: number;
  deliveryFee: number;
  freeDeliveryThreshold: number;
  deliveryEnabled: boolean;
  dineInEnabled: boolean;
  takeawayEnabled: boolean;
  upiId: string;
  paymentProviderName: string;
  paymentGatewayEnabled: boolean;
  reservationTimeSlots: string[];
  maxGuestsPerBooking: number;
  backendMode: 'local-persistent' | 'supabase-configured';
}

export interface AdminOverviewPayload {
  stats: {
    totalOrders: number;
    todayOrders: number;
    pendingOrders: number;
    completedOrders: number;
    totalReservations: number;
    pendingReservations: number;
    verifiedRevenue: number;
  };
  popularDishes: Array<{ name: string; count: number }>;
  orders: OrderRecord[];
  reservations: ReservationRecord[];
  messages: ContactMessage[];
  settings: RestaurantSettings;
}
