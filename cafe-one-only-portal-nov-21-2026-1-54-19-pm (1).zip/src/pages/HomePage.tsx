import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  ArrowRight,
  Compass,
  Flame,
  HeartHandshake,
  Leaf,
  MapPin,
  Phone,
  Sparkles,
  Star,
} from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';
import { DishCard } from '../components/DishCard';
import { DishDepthShowcase } from '../components/DishDepthShowcase';
import { HeroCanvas } from '../components/HeroCanvas';

gsap.registerPlugin(ScrollTrigger);

const POPULAR_NAMES = [
  'Crispy Corn',
  'Pav Bhaji',
  'Chole Kulche',
  'Jini Dosa',
  'Vegetarian Instant Noodles',
  'Cheese Balls',
];

export function HomePage() {
  const { menuItems, settings, navigate } = useRestaurant();
  const rootRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced || !rootRef.current) return;

    const ctx = gsap.context(() => {
      gsap.from('.hero-stagger', {
        y: 26,
        opacity: 0,
        duration: 0.85,
        stagger: 0.12,
        ease: 'power3.out',
        clearProps: 'transform,opacity',
      });

      gsap.utils.toArray<HTMLElement>('.reveal-section').forEach((section) => {
        gsap.from(section, {
          y: 28,
          opacity: 0,
          duration: 0.8,
          ease: 'power2.out',
          clearProps: 'transform,opacity',
          scrollTrigger: {
            trigger: section,
            start: 'top 84%',
            once: true,
          },
        });
      });
    }, rootRef);

    return () => ctx.revert();
  }, []);

  const popularDishes = POPULAR_NAMES.map((name) =>
    menuItems.find((item) => item.name.toLowerCase() === name.toLowerCase()),
  ).filter((item): item is NonNullable<typeof item> => Boolean(item));

  const fallbackDishes =
    popularDishes.length > 0 ? popularDishes : menuItems.slice(0, 6);

  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `${settings.googlePlusCode} ${settings.address}`,
  )}`;

  return (
    <div ref={rootRef} className="bg-[#100D0B] text-[#F5EFE4]">
      {/* 1. CINEMATIC HERO */}
      <section className="relative flex min-h-screen items-center overflow-hidden pt-20">
        {/* Background Photography */}
        <div className="absolute inset-0 z-0 overflow-hidden">
          <img
            src="/src/assets/images/hero_vegetarian_feast_1795248972135.jpg"
            alt="Cafe One & Only pure vegetarian dining spread in Keshkal"
            referrerPolicy="no-referrer"
            className="h-full w-full scale-105 object-cover object-center transition-transform duration-[4000ms]"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#100D0B]/95 via-[#100D0B]/75 to-[#100D0B]/45" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#100D0B] via-transparent to-[#100D0B]/60" />
        </div>

        {/* Three.js Brass & Particle Depth Atmosphere */}
        <HeroCanvas />

        {/* Foreground Content */}
        <div className="relative z-10 mx-auto w-full max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="hero-stagger text-xs font-semibold uppercase tracking-[0.24em] text-[#D8AE70]">
              {settings.restaurantType} · Keshkal, Chhattisgarh
            </p>

            <h1 className="hero-stagger mt-5 font-serif text-5xl font-semibold leading-[1.06] tracking-tight text-[#F5EFE4] sm:text-6xl lg:text-7xl">
              Every Bite Tells a Delicious Story.
            </h1>

            <p className="hero-stagger mt-6 max-w-xl text-base leading-relaxed text-[#BDB2A3] sm:text-lg">
              Experience the flavours of pure vegetarian food in a warm, welcoming atmosphere at{' '}
              {settings.restaurantName}.
            </p>

            <div className="hero-stagger mt-9 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={() => navigate('/menu')}
                className="group inline-flex items-center gap-3 border border-[#D8AE70] bg-[#D8AE70] px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#100D0B] transition-all duration-200 hover:bg-[#F2D3A0] hover:border-[#F2D3A0]"
              >
                <span>Explore Menu</span>
                <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
              </button>

              <button
                type="button"
                onClick={() => navigate('/menu')}
                className="inline-flex items-center gap-3 border border-[#D8AE70]/50 bg-[#191411]/75 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#F5EFE4] transition-colors duration-200 hover:border-[#D8AE70] hover:text-[#F2D3A0]"
              >
                <span>Order Online</span>
              </button>
            </div>

            <div className="hero-stagger mt-12 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-[#D8AE70]/20 pt-6 text-xs text-[#BDB2A3]">
              <span className="tabular-nums text-[#F2D3A0]">
                {settings.rating} / 5 Rating · {settings.reviewCount} Reviews
              </span>
              <span aria-hidden="true">·</span>
              <span>{settings.averageSpend}</span>
              <span aria-hidden="true">·</span>
              <span>Dine-In, Takeaway &amp; Delivery</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. RESTAURANT HIGHLIGHTS */}
      <section className="reveal-section border-y border-[#D8AE70]/20 bg-[#191411] py-16 lg:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: Leaf,
                title: '100% Vegetarian',
                copy: 'Dedicated pure vegetarian kitchen with thoughtful vegan-friendly options for every guest.',
              },
              {
                icon: Flame,
                title: 'Freshly Prepared',
                copy: 'Every plate, snack, and beverage is prepared warm to order with attentive care.',
              },
              {
                icon: HeartHandshake,
                title: 'Family Friendly',
                copy: 'Relaxed indoor and outdoor seating tailored for families, groups, and celebrations.',
              },
              {
                icon: Sparkles,
                title: 'Memorable Dining',
                copy: 'Warm hospitality welcoming local Keshkal families as well as travellers passing through.',
              },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.title}
                  className="group border border-[#D8AE70]/20 bg-[#211A15] p-6 transition-all duration-300 hover:-translate-y-0.5 hover:border-[#D8AE70]/50"
                >
                  <Icon className="h-6 w-6 text-[#D8AE70] transition-transform duration-300 group-hover:scale-110" />
                  <h2 className="mt-5 font-serif text-2xl font-semibold text-[#F5EFE4]">
                    {item.title}
                  </h2>
                  <p className="mt-2 text-sm leading-relaxed text-[#BDB2A3]">{item.copy}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. POPULAR DISHES */}
      <section className="reveal-section py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-start justify-between gap-6 border-b border-[#D8AE70]/20 pb-8 md:flex-row md:items-end">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#D8AE70]">
                Guest Favourites
              </p>
              <h2 className="mt-2 font-serif text-4xl font-semibold text-[#F5EFE4] sm:text-5xl">
                Popular Vegetarian Specialties
              </h2>
            </div>

            <button
              type="button"
              onClick={() => navigate('/menu')}
              className="group inline-flex items-center gap-2.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#D8AE70] transition-colors hover:text-[#F2D3A0]"
            >
              <span>Explore Full Menu</span>
              <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
            </button>
          </div>

          <div className="mt-12 grid grid-cols-1 gap-7 md:grid-cols-2 lg:grid-cols-3">
            {fallbackDishes.map((dish) => (
              <DishCard key={dish.id} dish={dish} />
            ))}
          </div>
        </div>
      </section>

      {/* 4. 3D INTERACTIVE TASTING SPOTLIGHT */}
      <DishDepthShowcase />

      {/* 5. ABOUT & EXPERIENCE SPLIT SECTION */}
      <section className="reveal-section py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:col-span-6">
              <div className="overflow-hidden border border-[#D8AE70]/25 bg-[#191411]">
                <img
                  src="/src/assets/images/cafe_interior_ambiance_1795248972739.jpg"
                  alt="Warm indoor family dining room at Cafe One & Only"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="h-full min-h-[280px] w-full object-cover transition-transform duration-700 hover:scale-105"
                />
              </div>
              <div className="overflow-hidden border border-[#D8AE70]/25 bg-[#191411]">
                <img
                  src="/src/assets/images/outdoor_garden_dining_1795248993021.jpg"
                  alt="Evening outdoor garden courtyard seating at Cafe One & Only"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="h-full min-h-[280px] w-full object-cover transition-transform duration-700 hover:scale-105"
                />
              </div>
            </div>

            <div className="flex flex-col justify-center lg:col-span-6 lg:pl-6">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#D8AE70]">
                The Atmosphere
              </p>
              <h2 className="mt-3 font-serif text-4xl font-semibold leading-tight text-[#F5EFE4] sm:text-5xl">
                More Than a Meal. A Place to Create Memories.
              </h2>
              <p className="mt-5 text-base leading-relaxed text-[#BDB2A3]">
                At {settings.restaurantName}, dining is designed around comfort and togetherness.
                Whether you prefer our softly lit indoor café tables or evening breeze in our
                outdoor courtyard seating, every corner welcomes families, friends, group dining,
                and private celebrations.
              </p>

              <div className="mt-8 grid grid-cols-2 gap-6 border-y border-[#D8AE70]/20 py-6 text-sm">
                <div>
                  <p className="font-serif text-xl text-[#F5EFE4]">Indoor &amp; Outdoor</p>
                  <p className="mt-1 text-xs text-[#BDB2A3]">
                    Comfortable seating for casual teas, family dinners, and gatherings.
                  </p>
                </div>
                <div>
                  <p className="font-serif text-xl text-[#F5EFE4]">Parties &amp; Events</p>
                  <p className="mt-1 text-xs text-[#BDB2A3]">
                    Thoughtful arrangements for birthdays, group meals, and milestones.
                  </p>
                </div>
              </div>

              <div className="mt-8 flex flex-wrap gap-4">
                <button
                  type="button"
                  onClick={() => navigate('/about')}
                  className="border border-[#D8AE70] px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#F2D3A0] transition-colors hover:bg-[#D8AE70] hover:text-[#100D0B]"
                >
                  Our Story &amp; Space
                </button>
                <button
                  type="button"
                  onClick={() => navigate('/gallery')}
                  className="border border-[#D8AE70]/30 px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#F5EFE4] transition-colors hover:border-[#D8AE70]"
                >
                  View Gallery
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. TOURIST & BASTAR TRAVELLER SECTION */}
      <section className="reveal-section border-y border-[#D8AE70]/20 bg-[#191411] py-20 lg:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12">
            <div className="flex flex-col justify-center lg:col-span-6">
              <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.22em] text-[#D8AE70]">
                <Compass className="h-4 w-4" />
                <span>Travellers &amp; Road Journeys</span>
              </div>
              <h2 className="mt-3 font-serif text-4xl font-semibold leading-tight text-[#F5EFE4] sm:text-5xl">
                Your Delicious Stop on the Way to Bastar.
              </h2>
              <p className="mt-5 text-base leading-relaxed text-[#BDB2A3]">
                Travelling through Keshkal towards Bastar or Chitrakote Waterfalls? Pause for
                hygienic, freshly prepared pure vegetarian meals, warm chai, chilled beverages, and
                unhurried family hospitality right on Borgaon Road.
              </p>

              <div className="mt-7 space-y-2 border-l border-[#D8AE70]/35 pl-4 text-sm text-[#F5EFE4]">
                <p>{settings.address}</p>
                <p className="font-mono text-xs text-[#D8AE70]">
                  Google Plus Code: {settings.googlePlusCode}
                </p>
              </div>

              <div className="mt-8 flex flex-wrap gap-4">
                <a
                  href={mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2.5 bg-[#D8AE70] px-6 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-[#100D0B] transition-colors hover:bg-[#F2D3A0]"
                >
                  <MapPin className="h-4 w-4" />
                  <span>Get Directions</span>
                </a>
                <a
                  href={`tel:${settings.phone.replace(/\s+/g, '')}`}
                  className="inline-flex items-center gap-2.5 border border-[#D8AE70]/40 px-6 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-[#F5EFE4] transition-colors hover:border-[#D8AE70] hover:text-[#F2D3A0]"
                >
                  <Phone className="h-4 w-4 text-[#D8AE70]" />
                  <span>Call {settings.phone}</span>
                </a>
              </div>
            </div>

            <div className="overflow-hidden border border-[#D8AE70]/25 bg-[#100D0B] lg:col-span-6">
              <img
                src="/src/assets/images/dish_veg_thali_1795248973066.jpg"
                alt="Pure vegetarian Indian thali for families and Bastar travellers"
                loading="lazy"
                referrerPolicy="no-referrer"
                className="h-full min-h-[320px] w-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 7. GUEST RATING & VERIFIED RECOGNITION (ZERO INVENTED QUOTES) */}
      <section className="reveal-section py-20 lg:py-24">
        <div className="mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#D8AE70]">
            Guest Appreciation
          </p>
          <div className="mt-4 flex items-center justify-center gap-1.5 text-[#D8AE70]">
            {[0, 1, 2, 3, 4].map((i) => (
              <Star
                key={i}
                className={`h-5 w-5 ${i < 4 ? 'fill-[#D8AE70]' : 'fill-[#D8AE70]/40'}`}
              />
            ))}
          </div>
          <h2 className="mt-4 font-serif text-4xl font-semibold text-[#F5EFE4] sm:text-5xl tabular-nums">
            {settings.rating} / 5 — {settings.reviewCount} Reviews
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-[#BDB2A3]">
            Recognised by guests in Keshkal for pure vegetarian quality, welcoming family service,
            accessible pricing ({settings.averageSpend}), and relaxed indoor and outdoor seating.
          </p>

          <div className="mt-10 grid grid-cols-1 gap-6 text-left sm:grid-cols-3">
            {[
              {
                label: 'Dining Format',
                value: 'Dine-In · Takeaway · Delivery',
              },
              {
                label: 'Dietary Focus',
                value: 'Pure Vegetarian · Vegan Options',
              },
              {
                label: 'Occasions',
                value: 'Family Meals · Groups · Parties',
              },
            ].map((item) => (
              <div key={item.label} className="border border-[#D8AE70]/20 bg-[#211A15] p-6">
                <p className="text-xs uppercase tracking-[0.16em] text-[#D8AE70]">{item.label}</p>
                <p className="mt-2 font-serif text-xl text-[#F5EFE4]">{item.value}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. RESERVATION CTA */}
      <section className="reveal-section border-t border-[#D8AE70]/25 bg-[#191411] py-20 lg:py-24">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#D8AE70]">
            Table Reservations
          </p>
          <h2 className="mt-3 font-serif text-4xl font-semibold text-[#F5EFE4] sm:text-6xl">
            Gather Around. Good Times Start Here.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base text-[#BDB2A3]">
            Planning a family dinner, group stopover, or celebration at {settings.restaurantName}?
            Submit your preferred time and our team will confirm your table.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <button
              type="button"
              onClick={() => navigate('/reservations')}
              className="inline-flex items-center gap-3 bg-[#D8AE70] px-8 py-4 text-xs font-semibold uppercase tracking-[0.16em] text-[#100D0B] transition-colors hover:bg-[#F2D3A0]"
            >
              <span>Reserve Your Table</span>
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => navigate('/contact')}
              className="border border-[#D8AE70]/40 px-8 py-4 text-xs font-semibold uppercase tracking-[0.16em] text-[#F5EFE4] transition-colors hover:border-[#D8AE70] hover:text-[#F2D3A0]"
            >
              Contact Us
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
