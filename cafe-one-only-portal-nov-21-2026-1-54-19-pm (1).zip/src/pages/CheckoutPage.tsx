import { useMemo, useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  MessageCircle,
  Search,
  ShieldAlert,
  ShoppingBag,
} from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';
import type { OrderRecord, OrderType, PaymentMethod } from '../types';

export function CheckoutPage() {
  const {
    cart,
    cartSubtotal,
    hasUnpricedInCart,
    settings,
    clearCart,
    navigate,
  } = useRestaurant();

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [orderType, setOrderType] = useState<OrderType>(
    settings.dineInEnabled ? 'Dine-in' : settings.takeawayEnabled ? 'Takeaway' : 'Delivery',
  );
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash / Pay at Restaurant');
  const [paymentReference, setPaymentReference] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<OrderRecord | null>(null);

  // Order status tracker
  const [trackOrderNum, setTrackOrderNum] = useState('');
  const [trackPhone4, setTrackPhone4] = useState('');
  const [trackedOrder, setTrackedOrder] = useState<OrderRecord | null>(null);
  const [trackError, setTrackError] = useState<string | null>(null);
  const [tracking, setTracking] = useState(false);

  const taxAmount = useMemo(
    () => Number(((cartSubtotal * (settings.taxRatePercent || 0)) / 100).toFixed(2)),
    [cartSubtotal, settings.taxRatePercent],
  );

  const deliveryCharge = useMemo(() => {
    if (orderType !== 'Delivery' || settings.deliveryFee <= 0) return 0;
    if (settings.freeDeliveryThreshold > 0 && cartSubtotal >= settings.freeDeliveryThreshold) {
      return 0;
    }
    return settings.deliveryFee;
  }, [orderType, settings.deliveryFee, settings.freeDeliveryThreshold, cartSubtotal]);

  const finalTotal = Number((cartSubtotal + taxAmount + deliveryCharge).toFixed(2));

  const buildWhatsAppMessage = (order: OrderRecord | null) => {
    if (order) {
      const lines = [
        `*New Order — ${settings.restaurantName}*`,
        `Order No: ${order.orderNumber}`,
        `Customer: ${order.customerName} (${order.customerPhone})`,
        `Type: ${order.orderType}`,
        order.orderType === 'Delivery' ? `Address: ${order.deliveryAddress}` : null,
        '',
        '*Items:*',
        ...order.items.map(
          (i) =>
            `• ${i.quantity}x ${i.name}${i.customization ? ` (${i.customization})` : ''} — ${
              i.unitPrice !== null ? `₹${(i.unitPrice * i.quantity).toFixed(0)}` : 'Price TBC'
            }`,
        ),
        '',
        `Payment: ${order.paymentMethod} (${order.paymentStatus})`,
        order.totalAmount > 0
          ? `Estimated Total: ₹${order.totalAmount.toFixed(2)}${order.hasUnpricedItems ? ' (+ items TBC)' : ''}`
          : 'Total: To be confirmed by restaurant',
        order.specialInstructions ? `Notes: ${order.specialInstructions}` : null,
      ].filter((l): l is string => l !== null);
      return `https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent(lines.join('\n'))}`;
    }

    const previewLines = [
      `*Order Inquiry — ${settings.restaurantName}*`,
      `Name: ${customerName || 'Guest'}`,
      `Phone: ${customerPhone || 'Not entered'}`,
      `Order Type: ${orderType}`,
      orderType === 'Delivery' && deliveryAddress ? `Address: ${deliveryAddress}` : null,
      '',
      '*Selected Dishes:*',
      ...cart.map(
        (c) =>
          `• ${c.quantity}x ${c.menuItem.name}${c.customization ? ` (${c.customization})` : ''} — ${
            c.menuItem.price !== null
              ? `₹${(c.menuItem.price * c.quantity).toFixed(0)}`
              : 'Price TBC'
          }`,
      ),
      specialInstructions ? `\nNotes: ${specialInstructions}` : null,
    ].filter((l): l is string => l !== null);
    return `https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent(previewLines.join('\n'))}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (cart.length === 0) {
      setFormError('Your cart is empty.');
      return;
    }
    if (customerName.trim().length < 2) {
      setFormError('Please enter your full name.');
      return;
    }
    if (!/^[+\d\s()-]{8,18}$/.test(customerPhone.trim())) {
      setFormError('Please enter a valid 10-digit mobile number.');
      return;
    }
    if (orderType === 'Delivery' && deliveryAddress.trim().length < 6) {
      setFormError('Please enter your full delivery address.');
      return;
    }
    if (paymentMethod === 'Online Gateway' && !settings.paymentGatewayEnabled) {
      setFormError(
        'Online payment gateway is pending configuration by the restaurant. Please select Cash / Pay at Restaurant or UPI.',
      );
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: customerName.trim(),
          customerPhone: customerPhone.trim(),
          orderType,
          deliveryAddress: deliveryAddress.trim(),
          specialInstructions: specialInstructions.trim(),
          paymentMethod,
          paymentReference: paymentReference.trim(),
          items: cart.map((c) => ({
            menuItemId: c.menuItem.id,
            quantity: c.quantity,
            customization: c.customization,
          })),
        }),
      });
      const data = (await res.json()) as { order?: OrderRecord; error?: string };
      if (!res.ok || !data.order) {
        throw new Error(data.error || 'Could not submit your order.');
      }
      setConfirmedOrder(data.order);
      clearCart();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Unable to submit order.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleTrackOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setTrackError(null);
    setTrackedOrder(null);
    if (!trackOrderNum.trim()) {
      setTrackError('Please enter your order number (e.g., ORD-...).');
      return;
    }
    setTracking(true);
    try {
      const res = await fetch(
        `/api/orders/${encodeURIComponent(trackOrderNum.trim())}?phone4=${encodeURIComponent(
          trackPhone4.trim(),
        )}`,
      );
      const data = (await res.json()) as { order?: OrderRecord; error?: string };
      if (!res.ok || !data.order) {
        throw new Error(data.error || 'Order not found.');
      }
      setTrackedOrder(data.order);
    } catch (err) {
      setTrackError(err instanceof Error ? err.message : 'Lookup failed.');
    } finally {
      setTracking(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#100D0B] pb-24 pt-28 text-[#F5EFE4]">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={() => navigate('/menu')}
          className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[#D8AE70] hover:text-[#F2D3A0]"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Menu</span>
        </button>

        {/* Order Confirmation State */}
        {confirmedOrder ? (
          <div className="mt-8 border border-[#D8AE70]/35 bg-[#191411] p-8 sm:p-12">
            <div className="flex flex-col items-start justify-between gap-6 border-b border-[#D8AE70]/20 pb-8 md:flex-row md:items-center">
              <div>
                <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-emerald-400">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Order Received · Status: {confirmedOrder.status}</span>
                </div>
                <h1 className="mt-2 font-serif text-4xl font-semibold text-[#F5EFE4] sm:text-5xl">
                  Thank You, {confirmedOrder.customerName}
                </h1>
                <p className="mt-2 text-sm text-[#BDB2A3]">
                  Your order has been logged with {settings.restaurantName}. Please send the order
                  summary via WhatsApp for immediate kitchen confirmation.
                </p>
              </div>
              <div className="border border-[#D8AE70]/30 bg-[#100D0B] px-5 py-4 text-left md:text-right">
                <p className="text-[11px] uppercase tracking-[0.16em] text-[#BDB2A3]">
                  Order Number
                </p>
                <p className="tabular-nums mt-1 font-mono text-lg font-semibold text-[#F2D3A0]">
                  {confirmedOrder.orderNumber}
                </p>
              </div>
            </div>

            <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-2">
              <div className="space-y-3 text-sm">
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#D8AE70]">
                  Order Details
                </p>
                <p>
                  <span className="text-[#BDB2A3]">Customer:</span> {confirmedOrder.customerName} (
                  {confirmedOrder.customerPhone})
                </p>
                <p>
                  <span className="text-[#BDB2A3]">Order Type:</span> {confirmedOrder.orderType}
                </p>
                {confirmedOrder.deliveryAddress && (
                  <p>
                    <span className="text-[#BDB2A3]">Delivery Address:</span>{' '}
                    {confirmedOrder.deliveryAddress}
                  </p>
                )}
                <p>
                  <span className="text-[#BDB2A3]">Payment:</span> {confirmedOrder.paymentMethod} ·{' '}
                  <span className="text-[#F2D3A0]">{confirmedOrder.paymentStatus}</span>
                </p>
              </div>

              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#D8AE70]">
                  Selected Items
                </p>
                <ul className="mt-3 divide-y divide-[#D8AE70]/15 border-y border-[#D8AE70]/15 text-sm">
                  {confirmedOrder.items.map((item) => (
                    <li key={item.id} className="flex items-center justify-between py-2.5">
                      <span>
                        {item.quantity}x {item.name}
                        {item.customization ? ` (${item.customization})` : ''}
                      </span>
                      <span className="tabular-nums font-mono text-[#F2D3A0]">
                        {item.unitPrice !== null
                          ? `₹${(item.unitPrice * item.quantity).toFixed(0)}`
                          : 'TBC'}
                      </span>
                    </li>
                  ))}
                </ul>
                <div className="mt-4 flex items-center justify-between text-base font-semibold">
                  <span>Total Amount</span>
                  <span className="tabular-nums font-mono text-[#F2D3A0]">
                    {confirmedOrder.totalAmount > 0
                      ? `₹${confirmedOrder.totalAmount.toFixed(2)}`
                      : 'Confirmed by café'}
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-10 flex flex-wrap gap-4">
              <a
                href={buildWhatsAppMessage(confirmedOrder)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 bg-[#D8AE70] px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-[#100D0B] hover:bg-[#F2D3A0]"
              >
                <MessageCircle className="h-4 w-4" />
                <span>Send Order on WhatsApp</span>
              </a>
              <button
                type="button"
                onClick={() => {
                  setConfirmedOrder(null);
                  navigate('/menu');
                }}
                className="border border-[#D8AE70]/40 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-[#F5EFE4] hover:border-[#D8AE70]"
              >
                Order More Dishes
              </button>
            </div>
          </div>
        ) : cart.length === 0 ? (
          /* Empty Cart + Order Tracker */
          <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-12">
            <div className="border border-[#D8AE70]/20 bg-[#191411] p-10 text-center lg:col-span-7">
              <ShoppingBag className="mx-auto h-10 w-10 text-[#D8AE70]/70" />
              <h1 className="mt-4 font-serif text-4xl font-semibold text-[#F5EFE4]">
                Your Order Bag is Empty
              </h1>
              <p className="mx-auto mt-3 max-w-md text-sm text-[#BDB2A3]">
                Browse our pure vegetarian menu to add starters, snacks, dosas, thalis, or
                beverages before checking out.
              </p>
              <button
                type="button"
                onClick={() => navigate('/menu')}
                className="mt-6 bg-[#D8AE70] px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.15em] text-[#100D0B] hover:bg-[#F2D3A0]"
              >
                Browse Menu
              </button>
            </div>

            <div className="border border-[#D8AE70]/20 bg-[#191411] p-8 lg:col-span-5">
              <h2 className="font-serif text-2xl font-semibold text-[#F5EFE4]">
                Track Existing Order
              </h2>
              <p className="mt-2 text-xs text-[#BDB2A3]">
                Check live preparation status using your order reference number.
              </p>
              <form onSubmit={handleTrackOrder} className="mt-5 space-y-4">
                <div>
                  <label className="mb-1 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]">
                    Order Number
                  </label>
                  <input
                    type="text"
                    value={trackOrderNum}
                    onChange={(e) => setTrackOrderNum(e.target.value)}
                    placeholder="ORD-20261121-XXXX"
                    className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 font-mono text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs uppercase tracking-[0.14em] text-[#BDB2A3]">
                    Last 4 Digits of Phone
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    value={trackPhone4}
                    onChange={(e) => setTrackPhone4(e.target.value)}
                    placeholder="5846"
                    className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 font-mono text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                  />
                </div>
                {trackError && <p className="text-xs text-red-400">{trackError}</p>}
                <button
                  type="submit"
                  disabled={tracking}
                  className="inline-flex w-full items-center justify-center gap-2 border border-[#D8AE70] py-2.5 text-xs font-semibold uppercase tracking-[0.15em] text-[#F2D3A0] hover:bg-[#D8AE70] hover:text-[#100D0B]"
                >
                  <Search className="h-3.5 w-3.5" />
                  <span>{tracking ? 'Checking...' : 'Check Status'}</span>
                </button>
              </form>

              {trackedOrder && (
                <div className="mt-5 border-t border-[#D8AE70]/20 pt-4 text-sm">
                  <p className="font-mono text-xs text-[#D8AE70]">{trackedOrder.orderNumber}</p>
                  <p className="mt-1 font-serif text-xl text-[#F5EFE4]">
                    Status: {trackedOrder.status}
                  </p>
                  <p className="mt-1 text-xs text-[#BDB2A3]">
                    {trackedOrder.orderType} · Payment: {trackedOrder.paymentStatus}
                  </p>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Active Checkout Form */
          <div className="mt-8 grid grid-cols-1 gap-10 lg:grid-cols-12">
            <form onSubmit={handleSubmit} className="space-y-8 lg:col-span-7">
              <div className="border-b border-[#D8AE70]/20 pb-6">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#D8AE70]">
                  Online Ordering
                </p>
                <h1 className="mt-2 font-serif text-4xl font-semibold text-[#F5EFE4] sm:text-5xl">
                  Checkout &amp; Order Review
                </h1>
              </div>

              {formError && (
                <div className="flex items-start gap-3 border border-red-500/40 bg-red-950/30 p-4 text-sm text-red-200">
                  <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Order Type */}
              <div>
                <label className="mb-3 block text-xs font-semibold uppercase tracking-[0.16em] text-[#D8AE70]">
                  1. Choose Order Type
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(
                    [
                      { type: 'Dine-in', enabled: settings.dineInEnabled },
                      { type: 'Takeaway', enabled: settings.takeawayEnabled },
                      { type: 'Delivery', enabled: settings.deliveryEnabled },
                    ] as Array<{ type: OrderType; enabled: boolean }>
                  ).map((opt) => (
                    <button
                      key={opt.type}
                      type="button"
                      disabled={!opt.enabled}
                      onClick={() => setOrderType(opt.type)}
                      className={`border py-3 text-xs font-semibold uppercase tracking-[0.14em] transition-colors ${
                        !opt.enabled
                          ? 'cursor-not-allowed border-[#D8AE70]/10 bg-[#191411]/50 text-[#BDB2A3]/40'
                          : orderType === opt.type
                            ? 'border-[#D8AE70] bg-[#D8AE70] text-[#100D0B]'
                            : 'border-[#D8AE70]/25 bg-[#191411] text-[#F5EFE4] hover:border-[#D8AE70]/60'
                      }`}
                    >
                      {opt.type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Customer Information */}
              <div className="space-y-4">
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#D8AE70]">
                  2. Guest Details
                </p>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="checkout-name"
                      className="mb-1.5 block text-xs uppercase tracking-[0.12em] text-[#BDB2A3]"
                    >
                      Full Name *
                    </label>
                    <input
                      id="checkout-name"
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Your name"
                      className="w-full border border-[#D8AE70]/25 bg-[#191411] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="checkout-phone"
                      className="mb-1.5 block text-xs uppercase tracking-[0.12em] text-[#BDB2A3]"
                    >
                      Mobile Number *
                    </label>
                    <input
                      id="checkout-phone"
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="+91 98XXXXXXXX"
                      className="w-full border border-[#D8AE70]/25 bg-[#191411] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                    />
                  </div>
                </div>

                {orderType === 'Delivery' && (
                  <div>
                    <label
                      htmlFor="checkout-address"
                      className="mb-1.5 block text-xs uppercase tracking-[0.12em] text-[#BDB2A3]"
                    >
                      Delivery Address in Keshkal *
                    </label>
                    <textarea
                      id="checkout-address"
                      rows={2}
                      required
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="House / Landmark / Road in Keshkal"
                      className="w-full border border-[#D8AE70]/25 bg-[#191411] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                    />
                  </div>
                )}

                <div>
                  <label
                    htmlFor="checkout-notes"
                    className="mb-1.5 block text-xs uppercase tracking-[0.12em] text-[#BDB2A3]"
                  >
                    Special Instructions (Optional)
                  </label>
                  <textarea
                    id="checkout-notes"
                    rows={2}
                    value={specialInstructions}
                    onChange={(e) => setSpecialInstructions(e.target.value)}
                    placeholder="Spice preference, arrival time, table preference..."
                    className="w-full border border-[#D8AE70]/25 bg-[#191411] px-4 py-3 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                  />
                </div>
              </div>

              {/* Payment Method */}
              <div className="space-y-4">
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#D8AE70]">
                  3. Payment Preference
                </p>
                <div className="space-y-2.5">
                  {(
                    [
                      'Cash / Pay at Restaurant',
                      'UPI',
                      'Online Gateway',
                    ] as PaymentMethod[]
                  ).map((method) => {
                    const isGatewayDisabled =
                      method === 'Online Gateway' && !settings.paymentGatewayEnabled;
                    return (
                      <label
                        key={method}
                        className={`flex cursor-pointer items-start justify-between border p-4 transition-colors ${
                          paymentMethod === method
                            ? 'border-[#D8AE70] bg-[#211A15]'
                            : 'border-[#D8AE70]/20 bg-[#191411]'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <input
                            type="radio"
                            name="paymentMethod"
                            checked={paymentMethod === method}
                            onChange={() => setPaymentMethod(method)}
                            className="mt-1 accent-[#D8AE70]"
                          />
                          <div>
                            <p className="text-sm font-medium text-[#F5EFE4]">{method}</p>
                            {method === 'UPI' && (
                              <p className="mt-1 text-xs text-[#BDB2A3]">
                                {settings.upiId
                                  ? `Restaurant UPI ID: ${settings.upiId} (Verification required by café)`
                                  : 'UPI handle will be shared on confirmation by the café.'}
                              </p>
                            )}
                            {method === 'Online Gateway' && (
                              <p className="mt-1 text-xs text-[#BDB2A3]">
                                {isGatewayDisabled
                                  ? `Provider (${settings.paymentProviderName}) not yet active.`
                                  : `Verified online payment via ${settings.paymentProviderName}.`}
                              </p>
                            )}
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </div>

                {paymentMethod === 'UPI' && (
                  <div>
                    <label
                      htmlFor="upi-ref"
                      className="mb-1.5 block text-xs uppercase tracking-[0.12em] text-[#BDB2A3]"
                    >
                      UPI Transaction Reference (If Paid)
                    </label>
                    <input
                      id="upi-ref"
                      type="text"
                      value={paymentReference}
                      onChange={(e) => setPaymentReference(e.target.value)}
                      placeholder="12-digit UTR / Ref (verified by restaurant staff)"
                      className="w-full border border-[#D8AE70]/25 bg-[#191411] px-4 py-3 font-mono text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                    />
                  </div>
                )}
              </div>

              <div className="flex flex-col gap-3 pt-2 sm:flex-row">
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 bg-[#D8AE70] py-4 text-xs font-semibold uppercase tracking-[0.16em] text-[#100D0B] transition-colors hover:bg-[#F2D3A0] disabled:opacity-60"
                >
                  {submitting ? 'Submitting Order...' : 'Place Order'}
                </button>
                <a
                  href={buildWhatsAppMessage(null)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 border border-[#D8AE70]/40 bg-[#191411] px-6 py-4 text-xs font-semibold uppercase tracking-[0.14em] text-[#F2D3A0] hover:border-[#D8AE70]"
                >
                  <MessageCircle className="h-4 w-4" />
                  <span>Review on WhatsApp</span>
                </a>
              </div>
            </form>

            {/* Right: Order Summary */}
            <aside className="lg:col-span-5">
              <div className="sticky top-28 border border-[#D8AE70]/25 bg-[#191411] p-6 sm:p-8">
                <h2 className="font-serif text-2xl font-semibold text-[#F5EFE4]">
                  Order Summary
                </h2>
                <ul className="mt-5 divide-y divide-[#D8AE70]/15 border-y border-[#D8AE70]/15">
                  {cart.map((entry) => (
                    <li
                      key={`${entry.menuItem.id}::${entry.customization || ''}`}
                      className="flex items-start justify-between gap-4 py-3.5 text-sm"
                    >
                      <div>
                        <p className="font-medium text-[#F5EFE4]">
                          {entry.quantity}x {entry.menuItem.name}
                        </p>
                        {entry.customization && (
                          <p className="text-xs text-[#D8AE70]">{entry.customization}</p>
                        )}
                      </div>
                      <span className="tabular-nums font-mono text-[#F2D3A0]">
                        {entry.menuItem.price !== null
                          ? `₹${(entry.menuItem.price * entry.quantity).toFixed(0)}`
                          : 'TBC'}
                      </span>
                    </li>
                  ))}
                </ul>

                <div className="mt-5 space-y-2.5 text-sm">
                  <div className="flex justify-between text-[#BDB2A3]">
                    <span>Subtotal</span>
                    <span className="tabular-nums font-mono text-[#F5EFE4]">
                      {cartSubtotal > 0 ? `₹${cartSubtotal.toFixed(2)}` : 'TBC'}
                    </span>
                  </div>
                  {settings.taxRatePercent > 0 && cartSubtotal > 0 && (
                    <div className="flex justify-between text-[#BDB2A3]">
                      <span>Taxes ({settings.taxRatePercent}%)</span>
                      <span className="tabular-nums font-mono text-[#F5EFE4]">
                        ₹{taxAmount.toFixed(2)}
                      </span>
                    </div>
                  )}
                  {orderType === 'Delivery' && deliveryCharge > 0 && (
                    <div className="flex justify-between text-[#BDB2A3]">
                      <span>Delivery Charge</span>
                      <span className="tabular-nums font-mono text-[#F5EFE4]">
                        ₹{deliveryCharge.toFixed(2)}
                      </span>
                    </div>
                  )}
                  {hasUnpricedInCart && (
                    <p className="pt-1 text-xs leading-relaxed text-[#D8AE70]">
                      Items marked TBC await admin pricing and will be confirmed by {settings.restaurantName}.
                    </p>
                  )}
                  <div className="flex justify-between border-t border-[#D8AE70]/20 pt-3 text-base font-semibold text-[#F5EFE4]">
                    <span>Final Total</span>
                    <span className="tabular-nums font-mono text-lg text-[#F2D3A0]">
                      {finalTotal > 0 ? `₹${finalTotal.toFixed(2)}` : 'Confirmed by café'}
                    </span>
                  </div>
                </div>
              </div>
            </aside>
          </div>
        )}
      </div>
    </div>
  );
}
