import { useEffect, useState } from 'react';

export function Preloader() {
  const [visible, setVisible] = useState(true);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const fadeDelay = prefersReduced ? 50 : 480;
    const hideDelay = prefersReduced ? 120 : 900;

    const t1 = window.setTimeout(() => setFading(true), fadeDelay);
    const t2 = window.setTimeout(() => setVisible(false), hideDelay);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, []);

  if (!visible) return null;

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#100D0B] transition-opacity duration-500 ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      <div className="relative flex flex-col items-center">
        <svg
          width="72"
          height="72"
          viewBox="0 0 72 72"
          fill="none"
          className="mb-5 text-[#D8AE70]"
        >
          <circle
            cx="36"
            cy="36"
            r="32"
            stroke="currentColor"
            strokeWidth="1"
            strokeOpacity="0.35"
          />
          <circle
            cx="36"
            cy="36"
            r="25"
            stroke="currentColor"
            strokeWidth="1.25"
            strokeDasharray="157"
            strokeDashoffset="24"
          />
          <path
            d="M36 18C36 28 28 34 22 36C28 38 36 44 36 54C36 44 44 38 50 36C44 34 36 28 36 18Z"
            stroke="currentColor"
            strokeWidth="1.25"
            fill="rgba(216,174,112,0.12)"
          />
        </svg>
        <p className="font-serif text-2xl tracking-[0.14em] text-[#F5EFE4] uppercase">
          Cafe One &amp; Only
        </p>
        <div className="mt-4 h-[1px] w-28 overflow-hidden bg-[#D8AE70]/20">
          <div className="h-full w-full origin-left bg-[#D8AE70] transition-transform duration-500" />
        </div>
      </div>
    </div>
  );
}
