import { useState } from 'react';
import { Check, Clock, Plus, Utensils } from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';
import type { MenuItem } from '../types';

interface DishCardProps {
  dish: MenuItem;
}

export function DishCard({ dish }: DishCardProps) {
  const { addToCart } = useRestaurant();
  const [imgError, setImgError] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | undefined>(
    dish.customizations && dish.customizations.length > 0 ? dish.customizations[0] : undefined,
  );
  const [justAdded, setJustAdded] = useState(false);

  const handleAdd = () => {
    if (!dish.isAvailable) return;
    addToCart(dish, 1, selectedOption);
    setJustAdded(true);
    window.setTimeout(() => setJustAdded(false), 1100);
  };

  return (
    <article className="group flex h-full flex-col border border-[#D8AE70]/20 bg-[#211A15] transition-all duration-300 hover:-translate-y-0.5 hover:border-[#D8AE70]/60">
      {/* Image Slot with Zero-Broken-Image Policy fallback */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#191411]">
        {!imgError ? (
          <img
            src={dish.imageUrl}
            alt={`${dish.name} — Pure vegetarian dish at Cafe One & Only`}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#211A15] to-[#100D0B] p-6 text-center">
            <Utensils className="mb-2 h-8 w-8 text-[#D8AE70]/60" />
            <span className="font-serif text-lg text-[#F5EFE4]">{dish.name}</span>
          </div>
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#100D0B]/70 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col justify-between p-5 sm:p-6">
        <div>
          {/* Unboxed Metadata Line (Zero-Pill Discipline) */}
          <div className="mb-2.5 flex items-center justify-between gap-3 text-xs text-[#BDB2A3]">
            <div className="flex items-center gap-2">
              {/* Indian Pure Vegetarian Mark */}
              <span
                title="100% Pure Vegetarian"
                className="inline-flex h-3.5 w-3.5 items-center justify-center border border-emerald-500"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              </span>
              <span className="uppercase tracking-[0.14em]">{dish.categoryName}</span>
              {dish.isVeganFriendly && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>Vegan Option</span>
                </>
              )}
            </div>

            {dish.prepTimeMinutes && (
              <span className="tabular-nums inline-flex items-center gap-1 text-[#BDB2A3]/80">
                <Clock className="h-3 w-3 text-[#D8AE70]" />
                {dish.prepTimeMinutes}m
              </span>
            )}
          </div>

          <h3 className="font-serif text-2xl font-semibold tracking-wide text-[#F5EFE4]">
            {dish.name}
          </h3>

          <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-[#BDB2A3]">
            {dish.description}
          </p>

          {dish.customizations && dish.customizations.length > 0 && (
            <div className="mt-4">
              <label className="mb-1.5 block text-[11px] uppercase tracking-[0.14em] text-[#BDB2A3]">
                Preparation
              </label>
              <div className="flex flex-wrap gap-1.5">
                {dish.customizations.map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setSelectedOption(opt)}
                    className={`border px-2.5 py-1 text-xs transition-colors whitespace-nowrap ${
                      selectedOption === opt
                        ? 'border-[#D8AE70] bg-[#D8AE70]/15 text-[#F2D3A0]'
                        : 'border-[#D8AE70]/20 bg-[#191411] text-[#BDB2A3] hover:border-[#D8AE70]/50'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 flex items-center justify-between gap-4 border-t border-[#D8AE70]/15 pt-4">
          <div>
            {dish.price !== null ? (
              <span className="tabular-nums font-mono text-lg font-medium text-[#F2D3A0]">
                ₹{dish.price.toFixed(0)}
              </span>
            ) : (
              <span className="text-xs font-medium text-[#D8AE70]">
                Price set at café
              </span>
            )}
            <span className="mt-0.5 block text-[11px] text-[#BDB2A3]/80">
              {dish.isAvailable ? 'Available' : 'Currently Unavailable'}
            </span>
          </div>

          <button
            type="button"
            disabled={!dish.isAvailable}
            onClick={handleAdd}
            className={`inline-flex items-center gap-2 border px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] transition-all duration-200 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D8AE70] ${
              !dish.isAvailable
                ? 'cursor-not-allowed border-[#BDB2A3]/20 bg-[#191411] text-[#BDB2A3]/50'
                : justAdded
                  ? 'border-emerald-500/70 bg-emerald-500/20 text-emerald-300'
                  : 'border-[#D8AE70] bg-transparent text-[#F2D3A0] hover:bg-[#D8AE70] hover:text-[#100D0B]'
            }`}
          >
            {justAdded ? (
              <>
                <Check className="h-3.5 w-3.5" />
                <span>Added</span>
              </>
            ) : (
              <>
                <Plus className="h-3.5 w-3.5" />
                <span>Add to Cart</span>
              </>
            )}
          </button>
        </div>
      </div>
    </article>
  );
}
