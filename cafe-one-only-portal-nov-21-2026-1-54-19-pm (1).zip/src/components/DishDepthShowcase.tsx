import { useState } from 'react';
import { ArrowRight, Plus } from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';

export function DishDepthShowcase() {
  const { menuItems, addToCart, navigate } = useRestaurant();
  const featured = menuItems.filter((m) => m.isFeatured).slice(0, 5);
  const [activeIdx, setActiveIdx] = useState(0);
  const [tilt, setTilt] = useState({ rx: 0, ry: 0 });

  if (featured.length === 0) return null;
  const activeDish = featured[activeIdx] || featured[0];

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width - 0.5;
    const ny = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ rx: -ny * 7, ry: nx * 9 });
  };

  const resetTilt = () => setTilt({ rx: 0, ry: 0 });

  return (
    <section className="relative overflow-hidden border-y border-[#D8AE70]/20 bg-[#191411] py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12">
          {/* Left: Interactive 3D Perspective Frame */}
          <div className="lg:col-span-7">
            <div
              onPointerMove={handlePointerMove}
              onPointerLeave={resetTilt}
              className="relative mx-auto max-w-2xl"
              style={{ perspective: '1200px' }}
            >
              <div
                className="relative overflow-hidden border border-[#D8AE70]/35 bg-[#100D0B] shadow-2xl transition-transform duration-300 ease-out"
                style={{
                  transform: `rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)`,
                  transformStyle: 'preserve-3d',
                }}
              >
                <div className="aspect-[4/3] w-full overflow-hidden">
                  <img
                    src={activeDish.imageUrl}
                    alt={activeDish.name}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover transition-transform duration-700 ease-out hover:scale-105"
                  />
                </div>

                {/* Measured scrim for legible overlay */}
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#100D0B]/90 via-[#100D0B]/20 to-transparent" />

                <div
                  className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-6 sm:p-8"
                  style={{ transform: 'translateZ(28px)' }}
                >
                  <div>
                    <p className="text-xs font-medium uppercase tracking-[0.2em] text-[#D8AE70]">
                      Chef&apos;s Spotlight · {activeDish.categoryName}
                    </p>
                    <h3 className="mt-1 font-serif text-3xl font-semibold text-[#F5EFE4] sm:text-4xl">
                      {activeDish.name}
                    </h3>
                  </div>

                  <button
                    type="button"
                    disabled={!activeDish.isAvailable}
                    onClick={() => addToCart(activeDish, 1)}
                    className="inline-flex items-center gap-2 bg-[#D8AE70] px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#100D0B] transition-colors hover:bg-[#F2D3A0] whitespace-nowrap shrink-0"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>Order</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Editorial Dish Selector */}
          <div className="lg:col-span-5">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#D8AE70]">
              Interactive Tasting Table
            </p>
            <h2 className="mt-3 font-serif text-4xl font-semibold leading-tight text-[#F5EFE4] sm:text-5xl">
              Crafted Warm, Served Fresh
            </h2>
            <p className="mt-4 text-base leading-relaxed text-[#BDB2A3]">
              Explore our kitchen&apos;s signature pure vegetarian preparations — from crispy
              starters to comfort-filled plates loved by families and travellers across Keshkal.
            </p>

            <div className="mt-8 divide-y divide-[#D8AE70]/15 border-y border-[#D8AE70]/15">
              {featured.map((dish, idx) => {
                const active = idx === activeIdx;
                return (
                  <button
                    key={dish.id}
                    type="button"
                    onClick={() => setActiveIdx(idx)}
                    className={`flex w-full items-center justify-between py-4 text-left transition-colors ${
                      active ? 'text-[#F2D3A0]' : 'text-[#BDB2A3] hover:text-[#F5EFE4]'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <span className="font-mono text-xs text-[#D8AE70]/80">
                        0{idx + 1}
                      </span>
                      <span className="font-serif text-2xl font-medium">{dish.name}</span>
                    </div>
                    <span className="text-xs uppercase tracking-[0.14em] text-[#D8AE70]">
                      {dish.price !== null ? `₹${dish.price}` : dish.categoryName}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="mt-8">
              <button
                type="button"
                onClick={() => navigate('/menu')}
                className="group inline-flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#D8AE70] transition-colors hover:text-[#F2D3A0]"
              >
                <span>View Complete Menu</span>
                <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
