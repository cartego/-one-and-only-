import { useCallback, useEffect, useState } from 'react';
import {
  ArrowLeft,
  CalendarCheck2,
  ClipboardList,
  ImagePlus,
  LayoutDashboard,
  Lock,
  LogOut,
  MessageCircle,
  Plus,
  Settings,
  ShieldCheck,
  Trash2,
  Upload,
  UtensilsCrossed,
} from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';
import type {
  AdminOverviewPayload,
  GalleryCategory,
  MenuItem,
  OrderStatus,
  PaymentStatus,
  ReservationStatus,
  RestaurantSettings,
} from '../types';

type AdminTab = 'overview' | 'orders' | 'menu' | 'reservations' | 'gallery' | 'settings';

const TOKEN_KEY = 'cafe_one_only_admin_token';

const ORDER_STATUSES: OrderStatus[] = [
  'Pending',
  'Accepted',
  'Preparing',
  'Ready',
  'Completed',
  'Cancelled',
];

const PAYMENT_STATUSES: PaymentStatus[] = [
  'Pending',
  'Verification Required',
  'Verified',
  'Failed',
];

export function AdminPage() {
  const { categories, menuItems, galleryImages, refreshBootstrap, navigate, showToast } =
    useRestaurant();

  const [authStatusLoading, setAuthStatusLoading] = useState(true);
  const [hasAdmin, setHasAdmin] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const [adminEmail, setAdminEmail] = useState<string | null>(null);
  const [token, setToken] = useState<string>(() => localStorage.getItem(TOKEN_KEY) || '');

  // Auth forms
  const [authMode, setAuthMode] = useState<'login' | 'setup' | 'recover'>('login');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [nameInput, setNameInput] = useState('Restaurant Administrator');
  const [recoveryKeyInput, setRecoveryKeyInput] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authMessage, setAuthMessage] = useState<string | null>(null);
  const [authSubmitting, setAuthSubmitting] = useState(false);

  // Dashboard state
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [overview, setOverview] = useState<AdminOverviewPayload | null>(null);
  const [loadingOverview, setLoadingOverview] = useState(false);
  const [orderFilter, setOrderFilter] = useState<'ALL' | OrderStatus>('ALL');

  // Menu Editor state
  const [editingDish, setEditingDish] = useState<MenuItem | null>(null);
  const [dishFormOpen, setDishFormOpen] = useState(false);
  const [dishName, setDishName] = useState('');
  const [dishDesc, setDishDesc] = useState('');
  const [dishPrice, setDishPrice] = useState('');
  const [dishCatId, setDishCatId] = useState('');
  const [dishImageUrl, setDishImageUrl] = useState('');
  const [dishPrepTime, setDishPrepTime] = useState('');
  const [dishVegan, setDishVegan] = useState(false);
  const [dishFeatured, setDishFeatured] = useState(false);
  const [dishAvailable, setDishAvailable] = useState(true);
  const [newCategoryName, setNewCategoryName] = useState('');

  // Gallery upload form
  const [galTitle, setGalTitle] = useState('');
  const [galCaption, setGalCaption] = useState('');
  const [galCategory, setGalCategory] = useState<GalleryCategory>('Food');
  const [galUrl, setGalUrl] = useState('');

  // Settings form
  const [settingsForm, setSettingsForm] = useState<RestaurantSettings | null>(null);
  const [slotsText, setSlotsText] = useState('');

  const authHeaders = useCallback((): Record<string, string> => {
    const h: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) h['Authorization'] = `Bearer ${token}`;
    return h;
  }, [token]);

  const checkStatus = useCallback(async () => {
    setAuthStatusLoading(true);
    try {
      const res = await fetch('/api/admin/status', {
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      });
      const data = (await res.json()) as {
        hasAdmin: boolean;
        authenticated: boolean;
        adminEmail: string | null;
      };
      setHasAdmin(data.hasAdmin);
      setAuthenticated(data.authenticated);
      setAdminEmail(data.adminEmail);
      if (!data.hasAdmin) setAuthMode('setup');
      else if (!data.authenticated) setAuthMode('login');
    } catch {
      setAuthError('Unable to reach server.');
    } finally {
      setAuthStatusLoading(false);
    }
  }, [token]);

  const loadOverview = useCallback(async () => {
    setLoadingOverview(true);
    try {
      const res = await fetch('/api/admin/overview', {
        headers: authHeaders(),
      });
      if (res.status === 401) {
        setAuthenticated(false);
        return;
      }
      if (!res.ok) throw new Error('Failed to load dashboard data.');
      const data = (await res.json()) as AdminOverviewPayload;
      setOverview(data);
      setSettingsForm(data.settings);
      setSlotsText(data.settings.reservationTimeSlots.join(', '));
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Error loading dashboard');
    } finally {
      setLoadingOverview(false);
    }
  }, [authHeaders, showToast]);

  useEffect(() => {
    void checkStatus();
  }, [checkStatus]);

  useEffect(() => {
    if (authenticated) {
      void loadOverview();
    }
  }, [authenticated, loadOverview]);

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthMessage(null);
    setAuthSubmitting(true);

    try {
      if (authMode === 'setup') {
        const res = await fetch('/api/admin/setup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: emailInput.trim(),
            password: passwordInput,
            name: nameInput.trim(),
          }),
        });
        const data = (await res.json()) as { token?: string; email?: string; error?: string };
        if (!res.ok || !data.token) throw new Error(data.error || 'Setup failed.');
        localStorage.setItem(TOKEN_KEY, data.token);
        setToken(data.token);
        setHasAdmin(true);
        setAuthenticated(true);
        setAdminEmail(data.email || emailInput);
        await refreshBootstrap();
      } else if (authMode === 'login') {
        const res = await fetch('/api/admin/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: emailInput.trim(), password: passwordInput }),
        });
        const data = (await res.json()) as { token?: string; email?: string; error?: string };
        if (!res.ok || !data.token) throw new Error(data.error || 'Sign in failed.');
        localStorage.setItem(TOKEN_KEY, data.token);
        setToken(data.token);
        setAuthenticated(true);
        setAdminEmail(data.email || emailInput);
      } else {
        const res = await fetch('/api/admin/recover', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: emailInput.trim(),
            recoveryKey: recoveryKeyInput.trim(),
            newPassword: passwordInput,
          }),
        });
        const data = (await res.json()) as { ok?: boolean; error?: string };
        if (!res.ok || !data.ok) throw new Error(data.error || 'Password recovery failed.');
        setAuthMessage('Password updated. You can now sign in with your new password.');
        setAuthMode('login');
        setPasswordInput('');
      }
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Authentication error.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/admin/logout', { method: 'POST' });
    localStorage.removeItem(TOKEN_KEY);
    setToken('');
    setAuthenticated(false);
    setOverview(null);
  };

  const handleImageFileUpload = async (
    file: File,
    onSuccess: (uploadedUrl: string) => void,
  ) => {
    if (!file) return;
    if (file.size > 3.5 * 1024 * 1024) {
      showToast('Please select an image smaller than 3.5 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const res = await fetch('/api/admin/upload', {
          method: 'POST',
          headers: authHeaders(),
          body: JSON.stringify({ dataUrl: reader.result, filename: file.name }),
        });
        const data = (await res.json()) as { url?: string; error?: string };
        if (!res.ok || !data.url) throw new Error(data.error || 'Upload failed.');
        onSuccess(data.url);
        showToast('Image uploaded successfully');
      } catch (err) {
        showToast(err instanceof Error ? err.message : 'Upload failed');
      }
    };
    reader.readAsDataURL(file);
  };

  const openDishModal = (dish: MenuItem | null) => {
    setEditingDish(dish);
    if (dish) {
      setDishName(dish.name);
      setDishDesc(dish.description);
      setDishPrice(dish.price !== null ? String(dish.price) : '');
      setDishCatId(dish.categoryId);
      setDishImageUrl(dish.imageUrl);
      setDishPrepTime(dish.prepTimeMinutes !== null ? String(dish.prepTimeMinutes) : '');
      setDishVegan(dish.isVeganFriendly);
      setDishFeatured(dish.isFeatured);
      setDishAvailable(dish.isAvailable);
    } else {
      setDishName('');
      setDishDesc('');
      setDishPrice('');
      setDishCatId(categories[0]?.id || '');
      setDishImageUrl('/src/assets/images/dish_veg_thali_1795248973066.jpg');
      setDishPrepTime('');
      setDishVegan(false);
      setDishFeatured(false);
      setDishAvailable(true);
    }
    setDishFormOpen(true);
  };

  const handleSaveDish = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      name: dishName.trim(),
      description: dishDesc.trim(),
      price: dishPrice.trim() === '' ? null : Number(dishPrice),
      categoryId: dishCatId,
      imageUrl: dishImageUrl.trim(),
      prepTimeMinutes: dishPrepTime.trim() === '' ? null : Number(dishPrepTime),
      isVeganFriendly: dishVegan,
      isFeatured: dishFeatured,
      isAvailable: dishAvailable,
    };

    try {
      const url = editingDish ? `/api/admin/menu/${editingDish.id}` : '/api/admin/menu';
      const method = editingDish ? 'PATCH' : 'POST';
      const res = await fetch(url, {
        method,
        headers: authHeaders(),
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Could not save dish.');
      setDishFormOpen(false);
      await refreshBootstrap();
      await loadOverview();
      showToast(editingDish ? 'Dish updated' : 'Dish added to menu');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Save failed');
    }
  };

  const handleQuickToggleDish = async (dish: MenuItem, patch: Partial<MenuItem>) => {
    try {
      const res = await fetch(`/api/admin/menu/${dish.id}`, {
        method: 'PATCH',
        headers: authHeaders(),
        body: JSON.stringify(patch),
      });
      if (!res.ok) throw new Error('Update failed');
      await refreshBootstrap();
      showToast(`${dish.name} updated`);
    } catch {
      showToast('Failed to update dish');
    }
  };

  const handleDeleteDish = async (dish: MenuItem) => {
    try {
      const res = await fetch(`/api/admin/menu/${dish.id}`, {
        method: 'DELETE',
        headers: authHeaders(),
      });
      if (!res.ok) throw new Error('Delete failed');
      await refreshBootstrap();
      showToast(`${dish.name} removed`);
    } catch {
      showToast('Failed to remove dish');
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;
    try {
      const res = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ name: newCategoryName.trim() }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Could not add category');
      setNewCategoryName('');
      await refreshBootstrap();
      showToast('Category added');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed');
    }
  };

  const handleDeleteCategory = async (catId: string) => {
    try {
      const res = await fetch(`/api/admin/categories/${catId}`, {
        method: 'DELETE',
        headers: authHeaders(),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Cannot delete category');
      await refreshBootstrap();
      showToast('Category removed');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Delete failed');
    }
  };

  const handleOrderUpdate = async (
    orderId: string,
    patch: { status?: OrderStatus; paymentStatus?: PaymentStatus },
  ) => {
    try {
      const res = await fetch(`/api/admin/orders/${orderId}`, {
        method: 'PATCH',
        headers: authHeaders(),
        body: JSON.stringify(patch),
      });
      if (!res.ok) throw new Error('Failed to update order');
      await loadOverview();
      showToast('Order updated');
    } catch {
      showToast('Order update failed');
    }
  };

  const handleReservationUpdate = async (
    resId: string,
    patch: { status?: ReservationStatus; guestCount?: number },
  ) => {
    try {
      const res = await fetch(`/api/admin/reservations/${resId}`, {
        method: 'PATCH',
        headers: authHeaders(),
        body: JSON.stringify(patch),
      });
      if (!res.ok) throw new Error('Update failed');
      await loadOverview();
      showToast('Reservation updated');
    } catch {
      showToast('Reservation update failed');
    }
  };

  const handleAddGalleryItem = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/gallery', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({
          title: galTitle.trim(),
          caption: galCaption.trim(),
          category: galCategory,
          imageUrl: galUrl.trim(),
        }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Could not add photo');
      setGalTitle('');
      setGalCaption('');
      setGalUrl('');
      await refreshBootstrap();
      showToast('Photograph added to gallery');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Failed');
    }
  };

  const handleDeleteGalleryItem = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/gallery/${id}`, {
        method: 'DELETE',
        headers: authHeaders(),
      });
      if (!res.ok) throw new Error('Delete failed');
      await refreshBootstrap();
      showToast('Photo removed');
    } catch {
      showToast('Failed to remove photo');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settingsForm) return;
    const parsedSlots = slotsText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: authHeaders(),
        body: JSON.stringify({
          ...settingsForm,
          reservationTimeSlots: parsedSlots,
        }),
      });
      if (!res.ok) throw new Error('Failed to save settings');
      await refreshBootstrap();
      await loadOverview();
      showToast('Restaurant settings saved');
    } catch {
      showToast('Error saving settings');
    }
  };

  if (authStatusLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#100D0B] text-[#BDB2A3]">
        <p className="text-sm uppercase tracking-[0.18em]">Verifying Administration Access...</p>
      </div>
    );
  }

  // Protected Auth Gate
  if (!authenticated) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-[#100D0B] px-4 py-12 text-[#F5EFE4]">
        <div className="w-full max-w-md border border-[#D8AE70]/30 bg-[#191411] p-8 sm:p-10">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="mb-6 inline-flex items-center gap-2 text-xs uppercase tracking-[0.14em] text-[#D8AE70] hover:text-[#F2D3A0]"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Back to Website</span>
          </button>

          <div className="flex items-center gap-3">
            <Lock className="h-5 w-5 text-[#D8AE70]" />
            <h1 className="font-serif text-3xl font-semibold text-[#F5EFE4]">
              {authMode === 'setup'
                ? 'Initial Admin Setup'
                : authMode === 'recover'
                  ? 'Password Recovery'
                  : 'Admin Sign In'}
            </h1>
          </div>

          <p className="mt-2 text-xs leading-relaxed text-[#BDB2A3]">
            {authMode === 'setup'
              ? 'Create the primary administrator account for Cafe One & Only. This one-time setup locks automatically once created.'
              : authMode === 'recover'
                ? 'Reset administrator password using your server ADMIN_RECOVERY_KEY.'
                : 'Sign in with your administrator credentials to manage menu, prices, orders, reservations, and settings.'}
          </p>

          {authError && (
            <div className="mt-4 border border-red-500/40 bg-red-950/30 p-3 text-xs text-red-200">
              {authError}
            </div>
          )}
          {authMessage && (
            <div className="mt-4 border border-emerald-500/40 bg-emerald-950/30 p-3 text-xs text-emerald-200">
              {authMessage}
            </div>
          )}

          <form onSubmit={handleAuthSubmit} className="mt-6 space-y-4">
            {authMode === 'setup' && (
              <div>
                <label className="mb-1 block text-xs uppercase tracking-[0.12em] text-[#BDB2A3]">
                  Administrator Name
                </label>
                <input
                  type="text"
                  required
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                />
              </div>
            )}

            <div>
              <label className="mb-1 block text-xs uppercase tracking-[0.12em] text-[#BDB2A3]">
                Email Address
              </label>
              <input
                type="email"
                required
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                placeholder="admin@cafeoneandonly.in"
                className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
              />
            </div>

            {authMode === 'recover' && (
              <div>
                <label className="mb-1 block text-xs uppercase tracking-[0.12em] text-[#BDB2A3]">
                  Server Recovery Key
                </label>
                <input
                  type="password"
                  required
                  value={recoveryKeyInput}
                  onChange={(e) => setRecoveryKeyInput(e.target.value)}
                  className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
                />
              </div>
            )}

            <div>
              <label className="mb-1 block text-xs uppercase tracking-[0.12em] text-[#BDB2A3]">
                {authMode === 'recover' ? 'New Password (min 8 chars)' : 'Password'}
              </label>
              <input
                type="password"
                required
                minLength={authMode === 'login' ? 1 : 8}
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4] focus:border-[#D8AE70] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={authSubmitting}
              className="w-full bg-[#D8AE70] py-3 text-xs font-semibold uppercase tracking-[0.16em] text-[#100D0B] hover:bg-[#F2D3A0] disabled:opacity-60"
            >
              {authSubmitting
                ? 'Please wait...'
                : authMode === 'setup'
                  ? 'Create Admin Account'
                  : authMode === 'recover'
                    ? 'Reset Password'
                    : 'Sign In'}
            </button>
          </form>

          {hasAdmin && (
            <div className="mt-5 flex justify-between border-t border-[#D8AE70]/15 pt-4 text-xs text-[#BDB2A3]">
              {authMode === 'login' ? (
                <button
                  type="button"
                  onClick={() => setAuthMode('recover')}
                  className="hover:text-[#D8AE70]"
                >
                  Forgot password?
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setAuthMode('login')}
                  className="hover:text-[#D8AE70]"
                >
                  Return to Sign In
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  const filteredOrders = (overview?.orders || []).filter((o) =>
    orderFilter === 'ALL' ? true : o.status === orderFilter,
  );

  // Order status chart metrics
  const statusCounts = ORDER_STATUSES.map((s) => ({
    label: s,
    value: (overview?.orders || []).filter((o) => o.status === s).length,
  }));
  const maxChartVal = Math.max(1, ...statusCounts.map((s) => s.value));

  return (
    <div className="min-h-screen bg-[#100D0B] text-[#F5EFE4] lg:flex">
      {/* Sidebar */}
      <aside className="border-b border-[#D8AE70]/20 bg-[#14100E] lg:min-h-screen lg:w-64 lg:shrink-0 lg:border-b-0 lg:border-r">
        <div className="flex items-center justify-between border-b border-[#D8AE70]/15 px-6 py-5">
          <div>
            <p className="font-serif text-xl font-semibold text-[#F5EFE4]">Cafe One &amp; Only</p>
            <p className="mt-0.5 text-[11px] uppercase tracking-[0.14em] text-[#D8AE70]">
              Admin Console
            </p>
          </div>
        </div>

        <nav className="flex flex-wrap gap-1 p-3 lg:flex-col">
          {(
            [
              { id: 'overview', label: 'Overview', icon: LayoutDashboard },
              { id: 'orders', label: 'Orders', icon: ClipboardList },
              { id: 'menu', label: 'Menu & Prices', icon: UtensilsCrossed },
              { id: 'reservations', label: 'Reservations', icon: CalendarCheck2 },
              { id: 'gallery', label: 'Gallery & Inbox', icon: ImagePlus },
              { id: 'settings', label: 'Settings', icon: Settings },
            ] as Array<{ id: AdminTab; label: string; icon: typeof LayoutDashboard }>
          ).map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-3 px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.12em] transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-[#D8AE70] text-[#100D0B]'
                    : 'text-[#BDB2A3] hover:bg-[#191411] hover:text-[#F5EFE4]'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-[#D8AE70]/15 p-4 text-xs">
          <p className="truncate text-[#BDB2A3]">{adminEmail}</p>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              onClick={() => navigate('/')}
              className="flex-1 border border-[#D8AE70]/30 py-2 text-[11px] uppercase tracking-wider text-[#F5EFE4] hover:border-[#D8AE70]"
            >
              View Site
            </button>
            <button
              type="button"
              onClick={handleLogout}
              aria-label="Logout"
              className="inline-flex items-center justify-center border border-red-500/30 px-3 py-2 text-red-300 hover:bg-red-950/40"
            >
              <LogOut className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-5 sm:p-8 lg:p-10">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4 border-b border-[#D8AE70]/20 pb-5">
          <div>
            <p className="text-xs uppercase tracking-[0.16em] text-[#BDB2A3]">
              Dashboard / <span className="text-[#D8AE70]">{activeTab}</span>
            </p>
            <h1 className="mt-1 font-serif text-3xl font-semibold capitalize text-[#F5EFE4]">
              {activeTab === 'menu'
                ? 'Menu & Category Management'
                : activeTab === 'gallery'
                  ? 'Gallery & Guest Messages'
                  : activeTab}
            </h1>
          </div>
          <div className="flex items-center gap-2 text-xs text-[#BDB2A3]">
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
            <span>
              Backend:{' '}
              {overview?.settings.backendMode === 'supabase-configured'
                ? 'Supabase Connected'
                : 'Persistent Server Storage'}
            </span>
          </div>
        </div>

        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
              {[
                { label: 'Total Orders', value: overview?.stats.totalOrders ?? 0 },
                { label: "Today's Orders", value: overview?.stats.todayOrders ?? 0 },
                { label: 'Pending Orders', value: overview?.stats.pendingOrders ?? 0 },
                { label: 'Completed Orders', value: overview?.stats.completedOrders ?? 0 },
                { label: 'Pending Tables', value: overview?.stats.pendingReservations ?? 0 },
                {
                  label: 'Verified Revenue',
                  value: `₹${(overview?.stats.verifiedRevenue ?? 0).toFixed(0)}`,
                },
              ].map((kpi) => (
                <div key={kpi.label} className="border border-[#D8AE70]/20 bg-[#191411] p-4">
                  <p className="text-[11px] uppercase tracking-[0.14em] text-[#BDB2A3]">
                    {kpi.label}
                  </p>
                  <p className="tabular-nums mt-2 font-mono text-2xl font-semibold text-[#F2D3A0]">
                    {loadingOverview ? '—' : kpi.value}
                  </p>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              {/* Order Status Bar Chart */}
              <div className="border border-[#D8AE70]/20 bg-[#191411] p-6 lg:col-span-7">
                <h2 className="font-serif text-2xl font-semibold text-[#F5EFE4]">
                  Orders by Status
                </h2>
                <div className="mt-6 space-y-3">
                  {statusCounts.map((row) => (
                    <div key={row.label} className="grid grid-cols-12 items-center gap-3 text-xs">
                      <span className="col-span-3 text-[#BDB2A3]">{row.label}</span>
                      <div className="col-span-7 h-3 bg-[#100D0B]">
                        <div
                          className="h-full bg-[#D8AE70] transition-all duration-500"
                          style={{ width: `${(row.value / maxChartVal) * 100}%` }}
                        />
                      </div>
                      <span className="tabular-nums col-span-2 text-right font-mono text-[#F5EFE4]">
                        {row.value}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Popular Ordered Dishes */}
              <div className="border border-[#D8AE70]/20 bg-[#191411] p-6 lg:col-span-5">
                <h2 className="font-serif text-2xl font-semibold text-[#F5EFE4]">
                  Top Ordered Dishes
                </h2>
                {!overview || overview.popularDishes.length === 0 ? (
                  <p className="mt-6 text-sm text-[#BDB2A3]">
                    Order volume insights will populate as customers place orders.
                  </p>
                ) : (
                  <ul className="mt-5 divide-y divide-[#D8AE70]/15 text-sm">
                    {overview.popularDishes.map((d) => (
                      <li key={d.name} className="flex items-center justify-between py-2.5">
                        <span className="text-[#F5EFE4]">{d.name}</span>
                        <span className="tabular-nums font-mono text-xs text-[#D8AE70]">
                          {d.count} sold
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ORDERS TAB */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            <div className="flex flex-wrap gap-2">
              {(['ALL', ...ORDER_STATUSES] as const).map((status) => (
                <button
                  key={status}
                  type="button"
                  onClick={() => setOrderFilter(status)}
                  className={`border px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider ${
                    orderFilter === status
                      ? 'border-[#D8AE70] bg-[#D8AE70] text-[#100D0B]'
                      : 'border-[#D8AE70]/20 bg-[#191411] text-[#BDB2A3]'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>

            {filteredOrders.length === 0 ? (
              <div className="border border-[#D8AE70]/20 bg-[#191411] p-12 text-center text-sm text-[#BDB2A3]">
                No orders found for this filter.
              </div>
            ) : (
              <div className="space-y-4">
                {filteredOrders.map((order) => (
                  <div key={order.id} className="border border-[#D8AE70]/25 bg-[#191411] p-5">
                    <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#D8AE70]/15 pb-4">
                      <div>
                        <p className="font-mono text-sm font-semibold text-[#F2D3A0]">
                          {order.orderNumber} · {order.orderType}
                        </p>
                        <p className="mt-1 text-sm text-[#F5EFE4]">
                          {order.customerName} ({order.customerPhone})
                        </p>
                        {order.deliveryAddress && (
                          <p className="mt-0.5 text-xs text-[#BDB2A3]">
                            Address: {order.deliveryAddress}
                          </p>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-3">
                        <div>
                          <label className="mb-1 block text-[10px] uppercase tracking-wider text-[#BDB2A3]">
                            Order Status
                          </label>
                          <select
                            value={order.status}
                            onChange={(e) =>
                              void handleOrderUpdate(order.id, {
                                status: e.target.value as OrderStatus,
                              })
                            }
                            className="border border-[#D8AE70]/30 bg-[#100D0B] px-3 py-1.5 text-xs text-[#F5EFE4]"
                          >
                            {ORDER_STATUSES.map((s) => (
                              <option key={s} value={s}>
                                {s}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="mb-1 block text-[10px] uppercase tracking-wider text-[#BDB2A3]">
                            Payment ({order.paymentMethod})
                          </label>
                          <select
                            value={order.paymentStatus}
                            onChange={(e) =>
                              void handleOrderUpdate(order.id, {
                                paymentStatus: e.target.value as PaymentStatus,
                              })
                            }
                            className="border border-[#D8AE70]/30 bg-[#100D0B] px-3 py-1.5 text-xs text-[#F5EFE4]"
                          >
                            {PAYMENT_STATUSES.map((p) => (
                              <option key={p} value={p}>
                                {p}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 flex flex-wrap items-end justify-between gap-4 text-xs">
                      <ul className="space-y-1 text-[#BDB2A3]">
                        {order.items.map((item) => (
                          <li key={item.id}>
                            <span className="font-mono text-[#F5EFE4]">{item.quantity}x</span>{' '}
                            {item.name}
                            {item.customization ? ` (${item.customization})` : ''}
                          </li>
                        ))}
                        {order.specialInstructions && (
                          <li className="pt-1 text-[#D8AE70]">
                            Note: {order.specialInstructions}
                          </li>
                        )}
                        {order.paymentReference && (
                          <li className="font-mono text-[#D8AE70]">
                            Ref: {order.paymentReference}
                          </li>
                        )}
                      </ul>

                      <div className="text-right">
                        <p className="text-[#BDB2A3]">Total</p>
                        <p className="tabular-nums font-mono text-base font-semibold text-[#F2D3A0]">
                          {order.totalAmount > 0
                            ? `₹${order.totalAmount.toFixed(2)}`
                            : 'Confirm manually'}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* MENU & CATEGORIES TAB */}
        {activeTab === 'menu' && (
          <div className="space-y-8">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <p className="text-sm text-[#BDB2A3]">
                Set INR prices, upload dish photos, and toggle live availability. Changes update the
                customer menu immediately.
              </p>
              <button
                type="button"
                onClick={() => openDishModal(null)}
                className="inline-flex items-center gap-2 bg-[#D8AE70] px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#100D0B] hover:bg-[#F2D3A0]"
              >
                <Plus className="h-4 w-4" />
                <span>Add Dish</span>
              </button>
            </div>

            {/* Dish Editor Drawer/Form */}
            {dishFormOpen && (
              <form
                onSubmit={handleSaveDish}
                className="space-y-4 border border-[#D8AE70]/40 bg-[#191411] p-6"
              >
                <h2 className="font-serif text-2xl font-semibold text-[#F5EFE4]">
                  {editingDish ? `Edit ${editingDish.name}` : 'Add New Pure Vegetarian Dish'}
                </h2>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                      Dish Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={dishName}
                      onChange={(e) => setDishName(e.target.value)}
                      className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3 py-2 text-sm text-[#F5EFE4]"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                      Category *
                    </label>
                    <select
                      value={dishCatId}
                      onChange={(e) => setDishCatId(e.target.value)}
                      className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3 py-2 text-sm text-[#F5EFE4]"
                    >
                      {categories.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                      Price in INR (blank = TBC)
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="1"
                      value={dishPrice}
                      onChange={(e) => setDishPrice(e.target.value)}
                      placeholder="e.g. 160"
                      className="tabular-nums w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3 py-2 font-mono text-sm text-[#F5EFE4]"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                    Description
                  </label>
                  <textarea
                    rows={2}
                    value={dishDesc}
                    onChange={(e) => setDishDesc(e.target.value)}
                    className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3 py-2 text-sm text-[#F5EFE4]"
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                      Image URL or Upload File
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={dishImageUrl}
                        onChange={(e) => setDishImageUrl(e.target.value)}
                        className="flex-1 border border-[#D8AE70]/25 bg-[#100D0B] px-3 py-2 text-xs text-[#F5EFE4]"
                      />
                      <label className="inline-flex cursor-pointer items-center gap-1.5 border border-[#D8AE70]/40 bg-[#100D0B] px-3 py-2 text-xs text-[#F2D3A0] hover:border-[#D8AE70]">
                        <Upload className="h-3.5 w-3.5" />
                        <span>Upload</span>
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          className="hidden"
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (f) void handleImageFileUpload(f, setDishImageUrl);
                          }}
                        />
                      </label>
                    </div>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                      Prep Time (mins)
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={dishPrepTime}
                      onChange={(e) => setDishPrepTime(e.target.value)}
                      placeholder="Optional"
                      className="tabular-nums w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3 py-2 font-mono text-sm text-[#F5EFE4]"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap gap-6 pt-1 text-xs">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={dishAvailable}
                      onChange={(e) => setDishAvailable(e.target.checked)}
                      className="accent-[#D8AE70]"
                    />
                    <span>Available</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={dishFeatured}
                      onChange={(e) => setDishFeatured(e.target.checked)}
                      className="accent-[#D8AE70]"
                    />
                    <span>Featured Dish</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={dishVegan}
                      onChange={(e) => setDishVegan(e.target.checked)}
                      className="accent-[#D8AE70]"
                    />
                    <span>Vegan-Friendly</span>
                  </label>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="submit"
                    className="bg-[#D8AE70] px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#100D0B]"
                  >
                    Save Dish
                  </button>
                  <button
                    type="button"
                    onClick={() => setDishFormOpen(false)}
                    className="border border-[#D8AE70]/30 px-6 py-2.5 text-xs uppercase tracking-wider text-[#BDB2A3]"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}

            {/* Menu Table */}
            <div className="overflow-x-auto border border-[#D8AE70]/20 bg-[#191411]">
              <table className="w-full text-left text-sm">
                <thead className="border-b border-[#D8AE70]/20 bg-[#14100E] text-xs uppercase tracking-wider text-[#BDB2A3]">
                  <tr>
                    <th className="px-4 py-3">Dish</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Price (INR)</th>
                    <th className="px-4 py-3">Availability</th>
                    <th className="px-4 py-3">Featured</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D8AE70]/10">
                  {menuItems.map((dish) => (
                    <tr key={dish.id} className="hover:bg-[#211A15]/60">
                      <td className="px-4 py-3 font-medium text-[#F5EFE4]">{dish.name}</td>
                      <td className="px-4 py-3 text-xs text-[#BDB2A3]">{dish.categoryName}</td>
                      <td className="tabular-nums px-4 py-3 font-mono text-xs text-[#F2D3A0]">
                        {dish.price !== null ? `₹${dish.price}` : 'Not set'}
                      </td>
                      <td className="px-4 py-3">
                        <button
                          type="button"
                          onClick={() =>
                            void handleQuickToggleDish(dish, { isAvailable: !dish.isAvailable })
                          }
                          className={`border px-2.5 py-1 text-xs ${
                            dish.isAvailable
                              ? 'border-emerald-500/40 text-emerald-300'
                              : 'border-red-500/40 text-red-300'
                          }`}
                        >
                          {dish.isAvailable ? 'Available' : 'Paused'}
                        </button>
                      </td>
                      <td className="px-4 py-3">
                        <button
                          type="button"
                          onClick={() =>
                            void handleQuickToggleDish(dish, { isFeatured: !dish.isFeatured })
                          }
                          className={`border px-2.5 py-1 text-xs ${
                            dish.isFeatured
                              ? 'border-[#D8AE70] text-[#F2D3A0]'
                              : 'border-[#D8AE70]/20 text-[#BDB2A3]'
                          }`}
                        >
                          {dish.isFeatured ? 'Featured' : 'Standard'}
                        </button>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex gap-2">
                          <button
                            type="button"
                            onClick={() => openDishModal(dish)}
                            className="border border-[#D8AE70]/30 px-2.5 py-1 text-xs text-[#F5EFE4] hover:border-[#D8AE70]"
                          >
                            Edit
                          </button>
                          <button
                            type="button"
                            onClick={() => void handleDeleteDish(dish)}
                            aria-label={`Delete ${dish.name}`}
                            className="border border-red-500/30 p-1.5 text-red-300 hover:bg-red-950/30"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Categories Manager */}
            <div className="border border-[#D8AE70]/20 bg-[#191411] p-6">
              <h2 className="font-serif text-2xl font-semibold text-[#F5EFE4]">
                Manage Categories
              </h2>
              <form onSubmit={handleAddCategory} className="mt-4 flex max-w-md gap-2">
                <input
                  type="text"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  placeholder="New category name"
                  className="flex-1 border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2 text-sm text-[#F5EFE4]"
                />
                <button
                  type="submit"
                  className="bg-[#D8AE70] px-5 py-2 text-xs font-semibold uppercase tracking-wider text-[#100D0B]"
                >
                  Add
                </button>
              </form>
              <div className="mt-4 flex flex-wrap gap-2">
                {categories.map((cat) => (
                  <div
                    key={cat.id}
                    className="inline-flex items-center gap-2 border border-[#D8AE70]/25 bg-[#100D0B] px-3 py-1.5 text-xs"
                  >
                    <span>{cat.name}</span>
                    <button
                      type="button"
                      onClick={() => void handleDeleteCategory(cat.id)}
                      aria-label={`Delete category ${cat.name}`}
                      className="text-[#BDB2A3] hover:text-red-400"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* RESERVATIONS TAB */}
        {activeTab === 'reservations' && (
          <div className="space-y-4">
            {!overview || overview.reservations.length === 0 ? (
              <div className="border border-[#D8AE70]/20 bg-[#191411] p-12 text-center text-sm text-[#BDB2A3]">
                No table reservation requests yet.
              </div>
            ) : (
              overview.reservations.map((resItem) => {
                const digits = resItem.customerPhone.replace(/\D/g, '');
                const waConfirmUrl = `https://wa.me/${digits}?text=${encodeURIComponent(
                  `Hello ${resItem.customerName}, your table reservation (${resItem.referenceCode}) at ${overview.settings.restaurantName} for ${resItem.reservationDate} at ${resItem.reservationTime} (${resItem.guestCount} guests) is ${resItem.status}. We look forward to hosting you!`,
                )}`;
                return (
                  <div
                    key={resItem.id}
                    className="flex flex-wrap items-center justify-between gap-4 border border-[#D8AE70]/25 bg-[#191411] p-5"
                  >
                    <div className="space-y-1 text-sm">
                      <p className="font-mono text-xs text-[#D8AE70]">
                        {resItem.referenceCode} · Status: {resItem.status}
                      </p>
                      <p className="font-serif text-xl font-semibold text-[#F5EFE4]">
                        {resItem.customerName} — {resItem.guestCount} Guests
                      </p>
                      <p className="tabular-nums text-xs text-[#BDB2A3]">
                        {resItem.reservationDate} at {resItem.reservationTime} ·{' '}
                        {resItem.customerPhone}
                      </p>
                      {resItem.specialRequests && (
                        <p className="text-xs text-[#D8AE70]">
                          Request: {resItem.specialRequests}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          void handleReservationUpdate(resItem.id, { status: 'Approved' })
                        }
                        className={`border px-3.5 py-2 text-xs font-semibold uppercase tracking-wider ${
                          resItem.status === 'Approved'
                            ? 'border-emerald-500 bg-emerald-500/20 text-emerald-300'
                            : 'border-[#D8AE70]/30 text-[#F5EFE4] hover:border-emerald-500'
                        }`}
                      >
                        Approve
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          void handleReservationUpdate(resItem.id, { status: 'Rejected' })
                        }
                        className={`border px-3.5 py-2 text-xs font-semibold uppercase tracking-wider ${
                          resItem.status === 'Rejected'
                            ? 'border-red-500 bg-red-500/20 text-red-300'
                            : 'border-[#D8AE70]/30 text-[#F5EFE4] hover:border-red-500'
                        }`}
                      >
                        Reject
                      </button>
                      <a
                        href={waConfirmUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 border border-[#D8AE70] px-3.5 py-2 text-xs font-semibold uppercase tracking-wider text-[#F2D3A0]"
                      >
                        <MessageCircle className="h-3.5 w-3.5" />
                        <span>WhatsApp</span>
                      </a>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* GALLERY & MESSAGES TAB */}
        {activeTab === 'gallery' && (
          <div className="space-y-10">
            <form
              onSubmit={handleAddGalleryItem}
              className="space-y-4 border border-[#D8AE70]/25 bg-[#191411] p-6"
            >
              <h2 className="font-serif text-2xl font-semibold text-[#F5EFE4]">
                Add Restaurant Photograph
              </h2>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <input
                  type="text"
                  required
                  value={galTitle}
                  onChange={(e) => setGalTitle(e.target.value)}
                  placeholder="Photo title *"
                  className="border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4]"
                />
                <select
                  value={galCategory}
                  onChange={(e) => setGalCategory(e.target.value as GalleryCategory)}
                  className="border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4]"
                >
                  {['Food', 'Restaurant', 'Interior', 'Outdoor Seating', 'Special Moments'].map(
                    (c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ),
                  )}
                </select>
                <input
                  type="text"
                  value={galCaption}
                  onChange={(e) => setGalCaption(e.target.value)}
                  placeholder="Caption (optional)"
                  className="border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4]"
                />
              </div>

              <div className="flex flex-wrap gap-2">
                <input
                  type="text"
                  required
                  value={galUrl}
                  onChange={(e) => setGalUrl(e.target.value)}
                  placeholder="Image URL or upload file *"
                  className="min-w-[240px] flex-1 border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4]"
                />
                <label className="inline-flex cursor-pointer items-center gap-2 border border-[#D8AE70]/40 bg-[#100D0B] px-4 py-2.5 text-xs text-[#F2D3A0]">
                  <Upload className="h-4 w-4" />
                  <span>Upload Image</span>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) void handleImageFileUpload(f, setGalUrl);
                    }}
                  />
                </label>
                <button
                  type="submit"
                  className="bg-[#D8AE70] px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#100D0B]"
                >
                  Publish to Gallery
                </button>
              </div>
            </form>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {galleryImages.map((g) => (
                <div key={g.id} className="border border-[#D8AE70]/20 bg-[#191411]">
                  <img
                    src={g.imageUrl}
                    alt={g.title}
                    className="aspect-[4/3] w-full object-cover"
                  />
                  <div className="flex items-center justify-between gap-2 p-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-[#F5EFE4]">{g.title}</p>
                      <p className="text-[11px] text-[#D8AE70]">{g.category}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => void handleDeleteGalleryItem(g.id)}
                      aria-label={`Remove ${g.title}`}
                      className="p-1.5 text-red-300 hover:bg-red-950/40"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Contact Form Inbox */}
            <div className="border border-[#D8AE70]/20 bg-[#191411] p-6">
              <h2 className="font-serif text-2xl font-semibold text-[#F5EFE4]">
                Contact Form Messages
              </h2>
              {!overview || overview.messages.length === 0 ? (
                <p className="mt-4 text-sm text-[#BDB2A3]">No customer messages received yet.</p>
              ) : (
                <ul className="mt-4 divide-y divide-[#D8AE70]/15">
                  {overview.messages.map((m) => (
                    <li key={m.id} className="py-4 text-sm">
                      <div className="flex flex-wrap justify-between gap-2">
                        <span className="font-semibold text-[#F5EFE4]">
                          {m.name} ({m.phone}) — {m.subject}
                        </span>
                        <span className="font-mono text-xs text-[#BDB2A3]">
                          {new Date(m.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="mt-1 text-[#BDB2A3]">{m.message}</p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        )}

        {/* SETTINGS TAB */}
        {activeTab === 'settings' && settingsForm && (
          <form
            onSubmit={handleSaveSettings}
            className="max-w-4xl space-y-6 border border-[#D8AE70]/25 bg-[#191411] p-6 sm:p-8"
          >
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                  Restaurant Name
                </label>
                <input
                  type="text"
                  value={settingsForm.restaurantName}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, restaurantName: e.target.value })
                  }
                  className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4]"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                  Opening Hours
                </label>
                <input
                  type="text"
                  value={settingsForm.openingHours}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, openingHours: e.target.value })
                  }
                  placeholder="e.g. 11:00 AM – 10:30 PM"
                  className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4]"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                  Contact Phone
                </label>
                <input
                  type="text"
                  value={settingsForm.phone}
                  onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                  className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4]"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                  WhatsApp Ordering Number (digits with country code)
                </label>
                <input
                  type="text"
                  value={settingsForm.whatsappNumber}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })
                  }
                  className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 font-mono text-sm text-[#F5EFE4]"
                />
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">Address</label>
              <input
                type="text"
                value={settingsForm.address}
                onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4]"
              />
            </div>

            <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                  Tax Rate (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="28"
                  step="0.5"
                  value={settingsForm.taxRatePercent}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, taxRatePercent: Number(e.target.value) })
                  }
                  className="tabular-nums w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 font-mono text-sm text-[#F5EFE4]"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                  Delivery Fee (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  value={settingsForm.deliveryFee}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, deliveryFee: Number(e.target.value) })
                  }
                  className="tabular-nums w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 font-mono text-sm text-[#F5EFE4]"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                  Free Delivery Above (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  value={settingsForm.freeDeliveryThreshold}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      freeDeliveryThreshold: Number(e.target.value),
                    })
                  }
                  className="tabular-nums w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 font-mono text-sm text-[#F5EFE4]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                  UPI ID (Shown at Checkout)
                </label>
                <input
                  type="text"
                  value={settingsForm.upiId}
                  onChange={(e) => setSettingsForm({ ...settingsForm, upiId: e.target.value })}
                  placeholder="merchant@upi"
                  className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 font-mono text-sm text-[#F5EFE4]"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                  Payment Provider Name
                </label>
                <input
                  type="text"
                  value={settingsForm.paymentProviderName}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, paymentProviderName: e.target.value })
                  }
                  placeholder="e.g. Razorpay / Cashfree"
                  className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4]"
                />
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs uppercase text-[#BDB2A3]">
                Reservation Time Slots (comma-separated)
              </label>
              <input
                type="text"
                value={slotsText}
                onChange={(e) => setSlotsText(e.target.value)}
                className="w-full border border-[#D8AE70]/25 bg-[#100D0B] px-3.5 py-2.5 text-sm text-[#F5EFE4]"
              />
            </div>

            <div className="flex flex-wrap gap-6 text-xs">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={settingsForm.dineInEnabled}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, dineInEnabled: e.target.checked })
                  }
                  className="accent-[#D8AE70]"
                />
                <span>Dine-In Enabled</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={settingsForm.takeawayEnabled}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, takeawayEnabled: e.target.checked })
                  }
                  className="accent-[#D8AE70]"
                />
                <span>Takeaway Enabled</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={settingsForm.deliveryEnabled}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, deliveryEnabled: e.target.checked })
                  }
                  className="accent-[#D8AE70]"
                />
                <span>Delivery Enabled</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={settingsForm.paymentGatewayEnabled}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      paymentGatewayEnabled: e.target.checked,
                    })
                  }
                  className="accent-[#D8AE70]"
                />
                <span>Online Payment Gateway Active</span>
              </label>
            </div>

            <button
              type="submit"
              className="bg-[#D8AE70] px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#100D0B] hover:bg-[#F2D3A0]"
            >
              Save Restaurant Settings
            </button>
          </form>
        )}
      </main>
    </div>
  );
}
