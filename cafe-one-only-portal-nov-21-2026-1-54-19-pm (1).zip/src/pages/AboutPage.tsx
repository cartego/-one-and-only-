import { ArrowRight, Leaf, MapPin, Users } from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';

export function AboutPage() {
  const { settings, navigate } = useRestaurant();

  return (
    <div className="min-h-screen bg-[#100D0B] pb-24 pt-28 text-[#F5EFE4]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Editorial Header */}
        <div className="max-w-3xl border-b border-[#D8AE70]/20 pb-10">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#D8AE70]">
            Our Identity &amp; Philosophy
          </p>
          <h1 className="mt-3 font-serif text-5xl font-semibold leading-tight text-[#F5EFE4] sm:text-6xl">
            Pure Vegetarian Hospitality in the Heart of Keshkal
          </h1>
          <p className="mt-5 text-base leading-relaxed text-[#BDB2A3] sm:text-lg">
            {settings.restaurantName} brings together the warmth of an Indian family café and the
            comfort of freshly cooked vegetarian cuisine — welcoming neighbours, celebrations, and
            travellers exploring Chhattisgarh.
          </p>
        </div>

        {/* Editorial Split 1 */}
        <div className="mt-14 grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12">
          <div className="overflow-hidden border border-[#D8AE70]/25 bg-[#191411] lg:col-span-7">
            <img
              src="/src/assets/images/cafe_interior_ambiance_1795248972739.jpg"
              alt="Interior dining room of Cafe One & Only in Keshkal"
              referrerPolicy="no-referrer"
              className="h-full min-h-[340px] w-full object-cover"
            />
          </div>

          <div className="flex flex-col justify-center space-y-6 border border-[#D8AE70]/20 bg-[#191411] p-8 lg:col-span-5">
            <Leaf className="h-6 w-6 text-[#D8AE70]" />
            <h2 className="font-serif text-3xl font-semibold text-[#F5EFE4]">
              100% Pure Vegetarian Kitchen
            </h2>
            <p className="text-sm leading-relaxed text-[#BDB2A3]">
              Every dish prepared at {settings.restaurantName} is strictly vegetarian, with
              vegan-friendly choices available across starters, snacks, and beverages. From
              crunchy Crispy Corn and hot Pav Bhaji to traditional Thalis and Jini Dosa, our focus
              remains clean preparation and welcoming flavour.
            </p>
            <div className="border-t border-[#D8AE70]/15 pt-4 text-xs text-[#D8AE70]">
              Average Reported Spend: {settings.averageSpend}
            </div>
          </div>
        </div>

        {/* Editorial Split 2 */}
        <div className="mt-12 grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12">
          <div className="flex flex-col justify-center space-y-6 border border-[#D8AE70]/20 bg-[#191411] p-8 lg:order-1 lg:col-span-5">
            <Users className="h-6 w-6 text-[#D8AE70]" />
            <h2 className="font-serif text-3xl font-semibold text-[#F5EFE4]">
              Family Dining, Outdoor Seating &amp; Events
            </h2>
            <p className="text-sm leading-relaxed text-[#BDB2A3]">
              Designed as a comfortable gathering space, our restaurant offers both relaxed indoor
              seating and breezy outdoor courtyard tables. Whether you are visiting for an evening
              chai, a family meal, group dining, or a special party arrangement, our team is ready
              to host you.
            </p>
            <div className="flex items-start gap-2.5 border-t border-[#D8AE70]/15 pt-4 text-xs text-[#BDB2A3]">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#D8AE70]" />
              <span>{settings.address}</span>
            </div>
          </div>

          <div className="overflow-hidden border border-[#D8AE70]/25 bg-[#191411] lg:order-2 lg:col-span-7">
            <img
              src="/src/assets/images/outdoor_garden_dining_1795248993021.jpg"
              alt="Outdoor evening seating at Cafe One & Only"
              referrerPolicy="no-referrer"
              className="h-full min-h-[340px] w-full object-cover"
            />
          </div>
        </div>

        {/* Bottom CTA Strip */}
        <div className="mt-16 flex flex-col items-start justify-between gap-6 border border-[#D8AE70]/25 bg-[#211A15] p-8 sm:flex-row sm:items-center sm:p-10">
          <div>
            <h2 className="font-serif text-3xl font-semibold text-[#F5EFE4]">
              Ready to Visit {settings.restaurantName}?
            </h2>
            <p className="mt-2 text-sm text-[#BDB2A3]">
              Browse our vegetarian menu or request a table reservation ahead of your arrival.
            </p>
          </div>
          <div className="flex flex-wrap gap-3 shrink-0">
            <button
              type="button"
              onClick={() => navigate('/menu')}
              className="inline-flex items-center gap-2 bg-[#D8AE70] px-6 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-[#100D0B] hover:bg-[#F2D3A0]"
            >
              <span>Explore Menu</span>
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => navigate('/reservations')}
              className="border border-[#D8AE70]/40 px-6 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-[#F5EFE4] hover:border-[#D8AE70]"
            >
              Reserve Table
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
