import { useMemo, useState } from 'react';
import { Search, ShoppingBag, SlidersHorizontal, X } from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';
import { DishCard } from '../components/DishCard';

export function MenuPage() {
  const { categories, menuItems, loading, cartCount, setIsCartOpen, settings } = useRestaurant();
  const [activeCategoryId, setActiveCategoryId] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [veganOnly, setVeganOnly] = useState<boolean>(false);

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return menuItems.filter((item) => {
      if (activeCategoryId !== 'ALL' && item.categoryId !== activeCategoryId) return false;
      if (veganOnly && !item.isVeganFriendly) return false;
      if (
        q &&
        !item.name.toLowerCase().includes(q) &&
        !item.description.toLowerCase().includes(q) &&
        !item.categoryName.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [menuItems, activeCategoryId, veganOnly, searchQuery]);

  return (
    <div className="min-h-screen bg-[#100D0B] pb-24 pt-28 text-[#F5EFE4]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="border-b border-[#D8AE70]/20 pb-10">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#D8AE70]">
            {settings.restaurantType}
          </p>
          <div className="mt-3 flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div>
              <h1 className="font-serif text-5xl font-semibold text-[#F5EFE4] sm:text-6xl">
                Our Culinary Menu
              </h1>
              <p className="mt-3 max-w-2xl text-base text-[#BDB2A3]">
                Pure vegetarian dishes freshly prepared for dine-in, takeaway, and delivery in
                Keshkal. Dish pricing and live availability are managed directly by our kitchen.
              </p>
            </div>

            {cartCount > 0 && (
              <button
                type="button"
                onClick={() => setIsCartOpen(true)}
                className="inline-flex items-center gap-3 bg-[#D8AE70] px-6 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-[#100D0B] transition-colors hover:bg-[#F2D3A0] whitespace-nowrap shrink-0"
              >
                <ShoppingBag className="h-4 w-4" />
                <span>View Order ({cartCount})</span>
              </button>
            )}
          </div>
        </div>

        {/* Search & Filter Controls */}
        <div className="mt-8 flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          {/* Search Input */}
          <div className="relative w-full lg:max-w-sm">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#D8AE70]" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search dishes, noodles, dosa, chai..."
              aria-label="Search menu items"
              className="w-full border border-[#D8AE70]/25 bg-[#191411] py-3 pl-10 pr-10 text-sm text-[#F5EFE4] placeholder-[#BDB2A3]/60 focus:border-[#D8AE70] focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="Clear search"
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#BDB2A3] hover:text-[#F5EFE4]"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Dietary Filter */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setVeganOnly((v) => !v)}
              className={`inline-flex items-center gap-2 border px-4 py-2.5 text-xs font-medium uppercase tracking-[0.14em] transition-colors whitespace-nowrap ${
                veganOnly
                  ? 'border-[#D8AE70] bg-[#D8AE70]/15 text-[#F2D3A0]'
                  : 'border-[#D8AE70]/25 bg-[#191411] text-[#BDB2A3] hover:border-[#D8AE70]/50'
              }`}
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              <span>Vegan-Friendly Options</span>
            </button>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div
          role="tablist"
          aria-label="Menu Categories"
          className="mt-6 flex flex-wrap gap-2 border-b border-[#D8AE70]/15 pb-6"
        >
          <button
            type="button"
            role="tab"
            aria-selected={activeCategoryId === 'ALL'}
            onClick={() => setActiveCategoryId('ALL')}
            className={`border px-4 py-2 text-xs font-semibold uppercase tracking-[0.14em] transition-colors whitespace-nowrap ${
              activeCategoryId === 'ALL'
                ? 'border-[#D8AE70] bg-[#D8AE70] text-[#100D0B]'
                : 'border-[#D8AE70]/20 bg-[#191411] text-[#BDB2A3] hover:border-[#D8AE70]/50 hover:text-[#F5EFE4]'
            }`}
          >
            All Items
          </button>
          {categories.map((cat) => {
            const active = activeCategoryId === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setActiveCategoryId(cat.id)}
                className={`border px-4 py-2 text-xs font-semibold uppercase tracking-[0.14em] transition-colors whitespace-nowrap ${
                  active
                    ? 'border-[#D8AE70] bg-[#D8AE70] text-[#100D0B]'
                    : 'border-[#D8AE70]/20 bg-[#191411] text-[#BDB2A3] hover:border-[#D8AE70]/50 hover:text-[#F5EFE4]'
                }`}
              >
                {cat.name}
              </button>
            );
          })}
        </div>

        {/* Menu Grid */}
        {loading ? (
          <div className="mt-12 grid grid-cols-1 gap-7 md:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2, 3, 4, 5].map((n) => (
              <div key={n} className="h-96 animate-pulse border border-[#D8AE70]/15 bg-[#191411]" />
            ))}
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="mt-16 border border-[#D8AE70]/20 bg-[#191411] px-6 py-16 text-center">
            <h2 className="font-serif text-3xl text-[#F5EFE4]">No dishes match your filter</h2>
            <p className="mt-2 text-sm text-[#BDB2A3]">
              Try clearing your search or switching back to All Items to explore the full menu.
            </p>
            <button
              type="button"
              onClick={() => {
                setActiveCategoryId('ALL');
                setSearchQuery('');
                setVeganOnly(false);
              }}
              className="mt-6 border border-[#D8AE70] px-6 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#F2D3A0] hover:bg-[#D8AE70] hover:text-[#100D0B]"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="mt-10 grid grid-cols-1 gap-7 md:grid-cols-2 lg:grid-cols-3">
            {filteredItems.map((dish) => (
              <DishCard key={dish.id} dish={dish} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
