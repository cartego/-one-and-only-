import { ArrowRight, Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import { useRestaurant } from '../context/RestaurantContext';

export function CartDrawer() {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    updateCartQuantity,
    removeFromCart,
    cartSubtotal,
    hasUnpricedInCart,
    settings,
    navigate,
  } = useRestaurant();

  if (!isCartOpen) return null;

  const taxAmount = Number(((cartSubtotal * (settings.taxRatePercent || 0)) / 100).toFixed(2));
  const totalWithTax = Number((cartSubtotal + taxAmount).toFixed(2));

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Your Order Cart"
      className="fixed inset-0 z-50 flex justify-end"
    >
      <div
        onClick={() => setIsCartOpen(false)}
        className="fixed inset-0 bg-black/75 backdrop-blur-xs transition-opacity"
      />

      <aside className="relative z-10 flex h-full w-full max-w-md flex-col border-l border-[#D8AE70]/25 bg-[#14100E] text-[#F5EFE4] shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#D8AE70]/20 px-6 py-5">
          <div className="flex items-center gap-3">
            <ShoppingBag className="h-5 w-5 text-[#D8AE70]" />
            <h2 className="font-serif text-2xl font-semibold tracking-wide">Your Order</h2>
          </div>
          <button
            type="button"
            onClick={() => setIsCartOpen(false)}
            aria-label="Close cart drawer"
            className="inline-flex h-10 w-10 items-center justify-center border border-[#D8AE70]/25 text-[#BDB2A3] transition-colors hover:border-[#D8AE70] hover:text-[#F5EFE4]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto px-6 py-5">
          {cart.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center border border-[#D8AE70]/25 bg-[#191411]">
                <ShoppingBag className="h-7 w-7 text-[#D8AE70]/70" />
              </div>
              <p className="font-serif text-2xl text-[#F5EFE4]">Your order bag is empty</p>
              <p className="mt-2 max-w-xs text-sm text-[#BDB2A3]">
                Explore our pure vegetarian dishes and add your favourites to begin.
              </p>
              <button
                type="button"
                onClick={() => {
                  setIsCartOpen(false);
                  navigate('/menu');
                }}
                className="mt-6 bg-[#D8AE70] px-6 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-[#100D0B] transition-colors hover:bg-[#F2D3A0]"
              >
                Explore Menu
              </button>
            </div>
          ) : (
            <ul className="divide-y divide-[#D8AE70]/15">
              {cart.map((entry) => {
                const key = `${entry.menuItem.id}::${entry.customization || ''}`;
                return (
                  <li key={key} className="flex gap-4 py-4">
                    <img
                      src={entry.menuItem.imageUrl}
                      alt={entry.menuItem.name}
                      referrerPolicy="no-referrer"
                      className="h-20 w-20 shrink-0 border border-[#D8AE70]/20 object-cover"
                    />
                    <div className="flex flex-1 flex-col justify-between">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-serif text-lg font-semibold text-[#F5EFE4]">
                            {entry.menuItem.name}
                          </h3>
                          {entry.customization && (
                            <p className="text-xs text-[#D8AE70]">{entry.customization}</p>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => removeFromCart(entry.menuItem.id, entry.customization)}
                          aria-label={`Remove ${entry.menuItem.name}`}
                          className="p-1 text-[#BDB2A3] transition-colors hover:text-red-400"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>

                      <div className="mt-3 flex items-center justify-between">
                        <div className="inline-flex items-center border border-[#D8AE70]/30 bg-[#191411]">
                          <button
                            type="button"
                            onClick={() =>
                              updateCartQuantity(entry.menuItem.id, entry.customization, -1)
                            }
                            aria-label={`Decrease quantity of ${entry.menuItem.name}`}
                            className="flex h-8 w-8 items-center justify-center text-[#F5EFE4] hover:bg-[#D8AE70]/15"
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="tabular-nums w-8 text-center font-mono text-xs font-medium">
                            {entry.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              updateCartQuantity(entry.menuItem.id, entry.customization, 1)
                            }
                            aria-label={`Increase quantity of ${entry.menuItem.name}`}
                            className="flex h-8 w-8 items-center justify-center text-[#F5EFE4] hover:bg-[#D8AE70]/15"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>

                        <span className="tabular-nums font-mono text-sm text-[#F2D3A0]">
                          {entry.menuItem.price !== null
                            ? `₹${(entry.menuItem.price * entry.quantity).toFixed(0)}`
                            : 'Price on confirmation'}
                        </span>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {/* Summary Footer */}
        {cart.length > 0 && (
          <div className="border-t border-[#D8AE70]/25 bg-[#191411] px-6 py-5">
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between text-[#BDB2A3]">
                <span>Subtotal</span>
                <span className="tabular-nums font-mono text-[#F5EFE4]">
                  {cartSubtotal > 0 ? `₹${cartSubtotal.toFixed(2)}` : 'Confirmed by café'}
                </span>
              </div>
              {settings.taxRatePercent > 0 && cartSubtotal > 0 && (
                <div className="flex items-center justify-between text-[#BDB2A3]">
                  <span>Taxes ({settings.taxRatePercent}%)</span>
                  <span className="tabular-nums font-mono text-[#F5EFE4]">
                    ₹{taxAmount.toFixed(2)}
                  </span>
                </div>
              )}
              {hasUnpricedInCart && (
                <p className="text-xs leading-relaxed text-[#D8AE70]">
                  Some items await menu pricing by the café; final total will be confirmed on order
                  acceptance or via WhatsApp.
                </p>
              )}
              <div className="flex items-center justify-between border-t border-[#D8AE70]/15 pt-2.5 text-base font-semibold text-[#F5EFE4]">
                <span>Estimated Total</span>
                <span className="tabular-nums font-mono text-[#F2D3A0]">
                  {totalWithTax > 0 ? `₹${totalWithTax.toFixed(2)}` : 'To be confirmed'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setIsCartOpen(false);
                navigate('/checkout');
              }}
              className="mt-4 flex w-full items-center justify-center gap-2 bg-[#D8AE70] py-3.5 text-xs font-semibold uppercase tracking-[0.16em] text-[#100D0B] transition-colors hover:bg-[#F2D3A0]"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}
